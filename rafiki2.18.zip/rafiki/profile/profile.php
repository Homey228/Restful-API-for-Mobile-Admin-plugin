<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

//Get data for dashboard
add_action('rest_api_init', 'rafiki_user_profile');

function rafiki_user_profile()
{
    register_rest_route(
        'wp/v2',
        'user/profile/update',
        array(
            'methods'  => 'POST',
            'callback' => 'user_profile',
        )
    );
}
error_log('Before profile update function');
function user_profile($request)
{
    error_log('Inside profile update function');
    $user_id = $request["user_id"];
    $image = $_FILES["image"];
    $email = $request["email"];
    $full_name = $request["full_name"];
    $zip_code = $request["location"];
    $notifications = $request["notifications"];
    $location_services = $request["location_services"];
    $do_not_have_mail_box = $request["do_not_have_mail_box"];
    $city_live_in = $request["city_live_in"];
    $headers = apache_request_headers();
	error_log('header: ' . print_r($headers, true));

	$token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }

    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    error_log('Before try catch profile update endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
 		//return $token;
        error_log('Profile update endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $user_obj = get_user_by('id', $user_id);
            $display_name = $user_obj->display_name;
            $user_email = $user_obj->user_email;
            $first_name = get_user_meta($user_id,  'first_name');
            $last_name = get_user_meta($user_id,  'last_name');
            $zipcode = get_user_meta($user_id,  'zip_code');
            $old_notifications = get_user_meta($user_id,  'notifications');
            $old_location_services = get_user_meta($user_id,  'location_services');
            if ($display_name != $full_name) {
                wp_update_user(array('ID' => $user_id, 'display_name' => $full_name));
            }
            //upload image

            if (!$_FILES['image']['name'] == "") {
                if (!function_exists('wp_handle_upload'))
                    require_once(ABSPATH . 'wp-admin/includes/file.php');
                $uploadedfile = $image;
                $upload_overrides = array('test_form' => false);
                $upload  = wp_handle_upload($uploadedfile, $upload_overrides);
                $attachment_id = wp_insert_attachment(
                    array(
                        'guid'           => $upload['url'],
                        'post_mime_type' => $upload['type'],
                        'post_title'     => basename($upload['file']),
                        'post_content'   => '',
                        'post_status'    => 'inherit',
                    ),
                    $upload['file']
                );

                if (is_wp_error($attachment_id) || !$attachment_id) {
                    wp_die('Upload error.');
                }
                require_once(ABSPATH . 'wp-admin/includes/image.php');

                wp_update_attachment_metadata(
                    $attachment_id,
                    wp_generate_attachment_metadata($attachment_id, $upload['file'])
                );

                update_user_meta($user_id, 'user_avatar', $attachment_id);
                update_user_meta($user_id, 'user_avatar_url', $upload['url']);
            }
            //upload image
            $parts = explode(" ", $full_name);
            if (count($parts) > 1) {
                $lastname = array_pop($parts);
                $firstname = implode(" ", $parts);
            } else {
                $firstname = $full_name;
                $lastname = " ";
            }
            if ($first_name != $lastname) {
                update_user_meta($user_id, 'first_name',  $firstname);
            }
            if ($last_name != $lastname) {
                update_user_meta($user_id, 'last_name',  $lastname);
            }
            if ($zipcode != $zip_code) {
                update_user_meta($user_id, 'zip_code',  $zip_code);
            }
            if ($old_notifications != $notifications) {
                update_user_meta($user_id, 'notifications',  $notifications);
            }
            if ($old_location_services != $location_services) {
                update_user_meta($user_id, 'location_services',  $location_services);
            }
            if ($user_email != $email) {
                wp_update_user(array('ID' => $user_id, 'user_email' => $email));
            }
            if ($do_not_have_mail_box) {
                update_user_meta($user_id, 'city_live_in', $city_live_in);
            }
            $response['success'] = true;
            $response['message'] = __("Profile updated successfully.");
            return $response;
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
