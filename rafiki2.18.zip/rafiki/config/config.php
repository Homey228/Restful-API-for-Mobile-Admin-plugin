<?php

return [
    'accountId' => 'Uk43IDXcQ6SDUVM02TNynQ',    // Zoom Account ID
    'clientId' => 'sS8eqfd8R_uIcCiuCADqjw',      // Zoom Client ID
    'clientSecret' => 'Tfyg1aCgGW77LTaerUmH8AU7v0zj4I5l', // Zoom Client Secret
];
