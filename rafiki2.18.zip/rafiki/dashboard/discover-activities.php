<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

//Get data for dashboard
add_action('rest_api_init', 'rafiki_discover_activities_event');

function rafiki_discover_activities_event()
{
    register_rest_route(
        'wp/v2',
        'user/dashboard/discover-activities',
        array(
            'methods'  => 'POST',
            'callback' => 'discover_activities_event',
        )
    );
}

error_log('Before dashboard discover-activities function');
function discover_activities_event($request)
{
    error_log('Inside dashboard discover-activities function');
    $user_id = $request["user_id"];
    $event_id = $request["id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $google_api_key = defined('GOOGLE_MAP_API_KEY') ? GOOGLE_MAP_API_KEY : false;
    $like_event_list_limit = defined('DISCOVER_ACTIVITIES_EVENT_LIKE_LIST_LIMIT') ? DISCOVER_ACTIVITIES_EVENT_LIKE_LIST_LIMIT : false;
    $nearby_event_list_limit = defined('NEARBY_EVENT_LIST_LIMIT') ? NEARBY_EVENT_LIST_LIMIT : false;
    $distance_coverage = defined('DISTANCE_COVERAGE') ? DISTANCE_COVERAGE : false;
    error_log('Before try catch dashboard discover-activities endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Dashboard discover-activities endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $order_event_id_ar = array($event_id);
            $single_event_ar = get_posts([
                'include' => $order_event_id_ar,
                'post_type' => 'tribe_events',
            ]);

            if ($single_event_ar) {
                $event_venu_id = array();
                $venu_zip = '';
                foreach ($single_event_ar as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $event_venu_id = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip = get_post_meta(implode($event_venu_id),  '_VenueZip');
                        }
                    }
                }

                // geo location
                $result_obj = array();
                foreach ($venu_zip as $key => $address) {
                    $geo_location = file_get_contents("https://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$google_api_key");
                    $result = json_decode($geo_location, true);
                    $result_obj[$key] = $result;
                }
                $post_id_location = array();
                foreach ($result_obj as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        foreach ($svalue as $s_key => $s_value) {
                            $post_id_location[$key] = $s_value['geometry']['location'];
                        }
                    }
                }
                // $user_ip = '47.29.169.238';
                $user_ip = do_shortcode('[show_ip]');
                $geo_location = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
                $lat2 = $geo_location["geoplugin_latitude"];
                $lon2 = $geo_location["geoplugin_longitude"];
                $lat1 = '';
                $lon1 = '';
                $distance = array();
                foreach ($post_id_location as $key => $value) {
                    foreach ($value as $s_key => $s_value) {
                        if ($s_key == 'lat') {
                            $lat1 = $s_value;
                        } else {
                            $lon1 = $s_value;
                        }
                    }
                    $theta = $lon1 - $lon2;
                    $dist = sin(deg2rad((float)$lat1)) * sin(deg2rad((float)$lat2)) +
                        cos(deg2rad((float)$lat1)) * cos(deg2rad((float)$lat2)) * cos(deg2rad((float)$theta));
                    $dist = acos($dist);
                    $dist = rad2deg($dist);
                    $distance[$key] = number_format((float)$dist * 60 * 1.1515 * 1.609344 * 0.62137119, 1, '.', ''); //miles
                }

                //Enrolled post - Start
                $get_completed_order_id = get_posts([
                    'author'        =>  $user_id,
                    'fields' => 'ids',
                    'post_type' => 'tec_tc_order',
                    'post_status' => 'tec-tc-completed',
                    'numberposts' => -1
                    // 'order'    => 'ASC'
                ]);
                $order_event_id = array();
                foreach ($get_completed_order_id as $value) {
                    $order_event_id[] = get_post_meta($value,  '_tec_tc_order_events_in_order');
                }
                $order_event_id_ar = array();
                $subscribe_status = false;
                foreach ($order_event_id as $value) {
                    foreach ($value as $s_event_id) {
                        if ($event_id == $s_event_id) {
                            $subscribe_status = true;
                        }
                    }
                }

                $user_type_events_distance = array();
                $user_type_events_single_distance = array();
                $user_type_events_ar_distance = array();
                $event_venu_id_distance = array();
                $venu_zip_id_ar_distance = array();
                $venu_zip_id_single_ar_distance = array();
                $venu_zip_distance = '';
                $event_start_distance = '';
                $event_end_distance = '';
                $_venueAddress_distance = '';
                $_venueCity_distance = '';
                $_venueCountry_distance = '';
                $_venueProvince_distance = '';
                $_Thumbnail = '';
                $_Featured = '';
                foreach ($single_event_ar as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $categories_activity = get_the_terms($svalue, 'tribe_events_cat');
                            $cat_ar_activity = [];
                            foreach ($categories_activity  as $cat_value) {
                                $cat_ar_activity[] = $cat_value->name;
                            }
                            $cat_activity = implode(", ", $cat_ar_activity);
                            $event_start_distance = get_post_meta($svalue,  '_EventStartDate');
                            $event_start_distance = array(date('Y-m-d h:i:s', strtotime($event_start_distance[0])));
                            $event_end_distance = get_post_meta($svalue,  '_EventEndDate');
                            $event_end_distance = array(date('Y-m-d h:i:s', strtotime($event_end_distance[0])));
                            $event_time_zone_distance = get_post_meta($svalue,  '_EventTimezone');
                            $event_venu_id_distance = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueZip');
                            $_venueAddress_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueAddress');
                            $_venueCity_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueCity');
                            $_venueCountry_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueCountry');
                            $_venueProvince_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueProvince');
                            $image = wp_get_attachment_image_src(get_post_thumbnail_id($svalue), 'single-post-thumbnail');
                            $_Thumbnail = $image[0];
                            $featured_event = get_post_meta($svalue,  '_tribe_featured');
                            if ($featured_event) {
                                $_Featured = true;
                            } else {
                                $_Featured = false;
                            }
                            $venu_zip_id_single_ar_distance[$svalue] = $venu_zip_distance;
                        }
                        unset($user_type_events_single_distance['post_excerpt']);
                        unset($user_type_events_single_distance['post_status']);
                        unset($user_type_events_single_distance['comment_status']);
                        unset($user_type_events_single_distance['ping_status']);
                        unset($user_type_events_single_distance['post_password']);
                        unset($user_type_events_single_distance['post_name']);
                        unset($user_type_events_single_distance['to_ping']);
                        unset($user_type_events_single_distance['pinged']);
                        unset($user_type_events_single_distance['post_content_filtered']);
                        unset($user_type_events_single_distance['post_parent']);
                        unset($user_type_events_single_distance['guid']);
                        unset($user_type_events_single_distance['menu_order']);
                        unset($user_type_events_single_distance['post_mime_type']);
                        unset($user_type_events_single_distance['comment_count']);
                        unset($user_type_events_single_distance['filter']);
                        $venu_zip_id_ar_distance[] = $venu_zip_id_single_ar_distance;
                        $user_type_events_ar_distance['categories'] = $cat_activity;
                        $user_type_events_ar_distance['_EventStartDate'] = $event_start_distance;
                        $user_type_events_ar_distance['_EventEndDate'] = $event_end_distance;
                        $user_type_events_ar_distance['_EventTimezone'] = $event_time_zone_distance;
                        $user_type_events_ar_distance['_VenueAddress'] = $_venueAddress_distance;
                        $user_type_events_ar_distance['_VenueCity'] = $_venueCity_distance;
                        $user_type_events_ar_distance['_VenueProvince'] = $_venueProvince_distance;
                        $user_type_events_ar_distance['_VenueCountry'] = $_venueCountry_distance;
                        $user_type_events_ar_distance['_VenueZip'] = $venu_zip_distance;
                        $user_type_events_ar_distance['_Distance'] = $distance;
                        $user_type_events_ar_distance['_Subscribe'] = $subscribe_status;
                        $user_type_events_ar_distance['_Attachment'] = $_Thumbnail;
                        $user_type_events_ar_distance['_Featured'] = $_Featured;
                        $user_type_events_single_distance[$skey] = $svalue;
                    }

                    $user_type_events_distance[] = array_merge($user_type_events_single_distance, $user_type_events_ar_distance);
                }
                //like events
                $single_event_like = get_posts([
                    'post_type' => 'tribe_events',
                    'numberposts' => $like_event_list_limit
                    // 'order'    => 'ASC'
                ]);
                $user_type_events_like = array();
                $user_type_events_single_like = array();
                $user_type_events_ar_like = array();
                $event_venu_id_like = array();
                $venu_zip_id_ar_like = array();
                $venu_zip_id_single_ar_like = array();
                $venu_zip_like = '';
                $event_start_like = '';
                $event_end_like = '';
                $_venueAddress_like = '';
                $_venueCity_like = '';
                $_venueCountry_like = '';
                $_venueProvince_like = '';
                foreach ($single_event_like as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $categories_like = get_the_terms($svalue, 'tribe_events_cat');
                            $cat_ar_like = [];
                            foreach ($categories_like  as $cat_value) {
                                $cat_ar_like[] = $cat_value->name;
                            }
                            $cat_like = implode(", ", $cat_ar_like);
                            $event_start_like = get_post_meta($svalue,  '_EventStartDate');
                            $event_start_like = array(date('Y-m-d h:i:s', strtotime($event_start_like[0])));
                            $event_end_like = get_post_meta($svalue,  '_EventEndDate');
                            $event_end_like = array(date('Y-m-d h:i:s', strtotime($event_end_like[0])));
                            $event_time_zone_like = get_post_meta($svalue,  '_EventTimezone');
                            $event_venu_id_like = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip_like = get_post_meta(implode($event_venu_id_like),  '_VenueZip');
                            $_venueAddress_like = get_post_meta(implode($event_venu_id_like),  '_VenueAddress');
                            $_venueCity_like = get_post_meta(implode($event_venu_id_like),  '_VenueCity');
                            $_venueCountry_like = get_post_meta(implode($event_venu_id_like),  '_VenueCountry');
                            $_venueProvince_like = get_post_meta(implode($event_venu_id_like),  '_VenueProvince');
                            $venu_zip_id_single_ar_like[$svalue] = $venu_zip_like;
                        }
                        unset($user_type_events_single_like['post_excerpt']);
                        unset($user_type_events_single_like['post_status']);
                        unset($user_type_events_single_like['comment_status']);
                        unset($user_type_events_single_like['ping_status']);
                        unset($user_type_events_single_like['post_password']);
                        unset($user_type_events_single_like['post_name']);
                        unset($user_type_events_single_like['to_ping']);
                        unset($user_type_events_single_like['pinged']);
                        unset($user_type_events_single_like['post_content_filtered']);
                        unset($user_type_events_single_like['post_parent']);
                        unset($user_type_events_single_like['guid']);
                        unset($user_type_events_single_like['menu_order']);
                        unset($user_type_events_single_like['post_mime_type']);
                        unset($user_type_events_single_like['comment_count']);
                        unset($user_type_events_single_like['filter']);
                        $venu_zip_id_ar_like[] = $venu_zip_id_single_ar_like;
                        $user_type_events_ar_like['categories'] = $cat_like;
                        $user_type_events_ar_like['_EventStartDate'] = $event_start_like;
                        $user_type_events_ar_like['_EventEndDate'] = $event_end_like;
                        $user_type_events_ar_like['_EventTimezone'] = $event_time_zone_like;
                        $user_type_events_ar_like['_VenueAddress'] = $_venueAddress_like;
                        $user_type_events_ar_like['_VenueCity'] = $_venueCity_like;
                        $user_type_events_ar_like['_VenueProvince'] = $_venueProvince_like;
                        $user_type_events_ar_like['_VenueCountry'] = $_venueCountry_like;
                        $user_type_events_ar_like['_VenueZip'] = $venu_zip_like;
                        $user_type_events_single_like[$skey] = $svalue;
                    }

                    $user_type_events_like[] = array_merge($user_type_events_single_like, $user_type_events_ar_like);
                }
                //like events

                //Geo location list - Start
                $args_geo = array(
                    'orderby'       =>  'post_date',
                    'order'         =>  'ASC',
                    'post_type' => 'tribe_events',
                    'numberposts' => -1
                );

                $current_user_posts_geo = get_posts($args_geo);
                $user_type_events_geo = array();
                $user_type_events_single_geo = array();
                $user_type_events_ar_geo = array();
                $event_venu_id_geo = array();
                $venu_zip_id_ar_geo = array();
                $venu_zip_id_single_ar_geo = array();
                $venu_zip_geo = '';
                $event_start_geo = '';
                $event_end_geo = '';
                $_venueAddress_geo = '';
                $_venueCity_geo = '';
                $_venueCountry_geo = '';
                $_venueProvince_geo = '';
                foreach ($current_user_posts_geo as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $categories_geo = get_the_terms($svalue, 'tribe_events_cat');
                            $cat_ar_geo = [];
                            foreach ($categories_geo  as $cat_value) {
                                $cat_ar_geo[] = $cat_value->name;
                            }
                            $cat_geo = implode(", ", $cat_ar_geo);
                            $event_start_geo = get_post_meta($svalue,  '_EventStartDate');
                            $event_start_geo = array(date('Y-m-d h:i:s', strtotime($event_start_geo[0])));
                            $event_end_geo = get_post_meta($svalue,  '_EventEndDate');
                            $event_end_geo = array(date('Y-m-d h:i:s', strtotime($event_end_geo[0])));
                            $event_time_zone_geo = get_post_meta($svalue,  '_EventTimezone');
                            $event_venu_id_geo = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueZip');
                            $_venueAddress_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueAddress');
                            $_venueCity_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueCity');
                            $_venueCountry_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueCountry');
                            $_venueProvince_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueProvince');
                            $venu_zip_id_single_ar_geo[$svalue] = $venu_zip_geo;
                        }
                        unset($user_type_events_single_geo['post_excerpt']);
                        unset($user_type_events_single_geo['post_status']);
                        unset($user_type_events_single_geo['comment_status']);
                        unset($user_type_events_single_geo['ping_status']);
                        unset($user_type_events_single_geo['post_password']);
                        unset($user_type_events_single_geo['post_name']);
                        unset($user_type_events_single_geo['to_ping']);
                        unset($user_type_events_single_geo['pinged']);
                        unset($user_type_events_single_geo['post_content_filtered']);
                        unset($user_type_events_single_geo['post_parent']);
                        unset($user_type_events_single_geo['guid']);
                        unset($user_type_events_single_geo['menu_order']);
                        unset($user_type_events_single_geo['post_mime_type']);
                        unset($user_type_events_single_geo['comment_count']);
                        unset($user_type_events_single_geo['filter']);
                        $venu_zip_id_ar_geo[] = $venu_zip_id_single_ar_geo;
                        $user_type_events_ar_geo['categories'] = $cat_geo;
                        $user_type_events_ar_geo['_EventStartDate'] = $event_start_geo;
                        $user_type_events_ar_geo['_EventEndDate'] = $event_end_geo;
                        $user_type_events_ar_geo['_EventTimezone'] = $event_time_zone_geo;
                        $user_type_events_ar_geo['_VenueAddress'] = $_venueAddress_geo;
                        $user_type_events_ar_geo['_VenueCity'] = $_venueCity_geo;
                        $user_type_events_ar_geo['_VenueProvince'] = $_venueProvince_geo;
                        $user_type_events_ar_geo['_VenueCountry'] = $_venueCountry_geo;
                        $user_type_events_ar_geo['_VenueZip'] = $venu_zip_geo;
                        $user_type_events_single_geo[$skey] = $svalue;
                    }

                    $user_type_events_geo[] = array_merge($user_type_events_single_geo, $user_type_events_ar_geo);
                }
                //Geo location list - End
                $unique_venu_zip_id_ar_geo_nearby = array();
                foreach ($venu_zip_id_ar_geo as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        $unique_venu_zip_id_ar_geo_nearby[$skey] = $svalue;
                    }
                }

                $result_obj_nearby = array();
                foreach ($unique_venu_zip_id_ar_geo_nearby as $key => $value) {
                    foreach ($value as $s_key => $address) {
                        $geo_location = file_get_contents("https://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$google_api_key");
                        $result = json_decode($geo_location, true);
                        $result_obj_nearby[$key] = $result;
                    }
                }
                $post_id_location = array();
                foreach ($result_obj_nearby as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        foreach ($svalue as $s_key => $s_value) {
                            $post_id_location_nearby[$key] = $s_value['geometry']['location'];
                        }
                    }
                }

                // $user_ip_nearby = '47.29.169.238';
                $user_ip_nearby = do_shortcode('[show_ip]');
                $geo_location_nearby = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip_nearby"));

                $lat2_nearby = $geo_location_nearby["geoplugin_latitude"];
                $lon2_nearby = $geo_location_nearby["geoplugin_longitude"];
                $lat1_nearby = '';
                $lon1_nearby = '';
                $distance_nearby = array();
                foreach ($post_id_location_nearby as $key => $value) {
                    foreach ($value as $s_key => $s_value) {
                        if ($s_key == 'lat') {
                            $lat1_nearby = $s_value;
                        } else {
                            $lon1_nearby = $s_value;
                        }
                    }
                    $theta_nearby = $lon1_nearby - $lon2_nearby;

                    $dist = sin(deg2rad((float)$lat1_nearby)) * sin(deg2rad((float)$lat2_nearby)) +
                        cos(deg2rad((float)$lat1_nearby)) * cos(deg2rad((float)$lat2_nearby)) * cos(deg2rad((float)$theta_nearby));
                    $dist = acos($dist);
                    $dist = rad2deg($dist);
                    $distance_nearby[$key] = number_format((float)$dist * 60 * 1.1515 * 1.609344 * 0.62137119, 1, '.', ''); //miles
                }

                $nearby_post_list = array();
                foreach ($distance_nearby as $key => $value) {
                    if ($value <= $distance_coverage) {
                        $nearby_post_list[] = get_post($key);
                    }
                }
                // Nearby post - Start
                $user_type_events_nearby = array();
                $user_type_events_single_nearby = array();
                $user_type_events_ar_nearby = array();
                $event_venu_id_nearby = array();
                $venu_zip_id_ar_nearby = array();
                $venu_zip_id_single_ar_nearby = array();
                $venu_zip_nearby = '';
                $event_start_nearby = '';
                $event_end_nearby = '';
                $_venueAddress_nearby = '';
                $_venueCity_nearby = '';
                $_venueCountry_nearby = '';
                $_venueProvince_nearby = '';
                $limit = 1;
                $nearby_limit = $nearby_event_list_limit;
                foreach ($nearby_post_list as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $categories_nearby = get_the_terms($svalue, 'tribe_events_cat');
                            $cat_ar_nearby = [];
                            foreach ($categories_nearby  as $cat_value) {
                                $cat_ar_nearby[] = $cat_value->name;
                            }
                            $cat_nearby = implode(", ", $cat_ar_nearby);
                            $event_start_nearby = get_post_meta($svalue,  '_EventStartDate');
                            $event_start_nearby = array(date('Y-m-d h:i:s', strtotime($event_start_nearby[0])));
                            $event_end_nearby = get_post_meta($svalue,  '_EventEndDate');
                            $event_end_nearby = array(date('Y-m-d h:i:s', strtotime($event_end_nearby[0])));
                            $event_time_zone_nearby = get_post_meta($svalue,  '_EventTimezone');
                            $event_venu_id_nearby = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueZip');
                            $_venueAddress_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueAddress');
                            $_venueCity_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueCity');
                            $_venueCountry_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueCountry');
                            $_venueProvince_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueProvince');
                            $venu_zip_id_single_ar_nearby[$svalue] = $venu_zip_nearby;
                        }
                        unset($user_type_events_single_nearby['post_excerpt']);
                        unset($user_type_events_single_nearby['post_status']);
                        unset($user_type_events_single_nearby['comment_status']);
                        unset($user_type_events_single_nearby['ping_status']);
                        unset($user_type_events_single_nearby['post_password']);
                        unset($user_type_events_single_nearby['post_name']);
                        unset($user_type_events_single_nearby['to_ping']);
                        unset($user_type_events_single_nearby['pinged']);
                        unset($user_type_events_single_nearby['post_content_filtered']);
                        unset($user_type_events_single_nearby['post_parent']);
                        unset($user_type_events_single_nearby['guid']);
                        unset($user_type_events_single_nearby['menu_order']);
                        unset($user_type_events_single_nearby['post_mime_type']);
                        unset($user_type_events_single_nearby['comment_count']);
                        unset($user_type_events_single_nearby['filter']);
                        $venu_zip_id_ar_nearby[] = $venu_zip_id_single_ar_nearby;
                        $user_type_events_ar_nearby['categories'] = $cat_nearby;
                        $user_type_events_ar_nearby['_EventStartDate'] = $event_start_nearby;
                        $user_type_events_ar_nearby['_EventEndDate'] = $event_end_nearby;
                        $user_type_events_ar_nearby['_EventTimezone'] = $event_time_zone_nearby;
                        $user_type_events_ar_nearby['_VenueAddress'] = $_venueAddress_nearby;
                        $user_type_events_ar_nearby['_VenueCity'] = $_venueCity_nearby;
                        $user_type_events_ar_nearby['_VenueProvince'] = $_venueProvince_nearby;
                        $user_type_events_ar_nearby['_VenueCountry'] = $_venueCountry_nearby;
                        $user_type_events_ar_nearby['_VenueZip'] = $venu_zip_nearby;
                        $user_type_events_single_nearby[$skey] = $svalue;
                    }

                    $user_type_events_nearby[] = array_merge($user_type_events_single_nearby, $user_type_events_ar_nearby);
                    $limit++;
                    if ($limit > $nearby_limit) {
                        break;
                    }
                }
                $total_event_list = array();
                foreach ($user_type_events_distance as $key => $value) {
                    $total_event_list = $value;
                    $total_event_list['like_event'] = $user_type_events_like;
                    $total_event_list['nearby_event'] = $user_type_events_nearby;
                }
                $response['success'] = true;
                $response['message'] = __("Discover activities event.");
                $response['data'] = $total_event_list;
                return $response;
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid event id.";
                return $response;
            }
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}