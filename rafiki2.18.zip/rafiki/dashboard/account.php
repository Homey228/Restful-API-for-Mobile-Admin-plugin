<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

//Get data for dashboard
add_action('rest_api_init', 'rafiki_user_account');

function rafiki_user_account()
{
    register_rest_route(
        'wp/v2',
        'user/account',
        array(
            'methods'  => 'POST',
            'callback' => 'user_account',
        )
    );
}
error_log('Before user account function');
function user_account($request)
{
    error_log('inside user account function');
    $user_id = $request["user_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $google_api_key = defined('GOOGLE_MAP_API_KEY') ? GOOGLE_MAP_API_KEY : false;
    error_log('Before try catch user account endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('User account endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $user_obj = get_user_by('id', $user_id);
            $user_name = $user_obj->user_login;
            $user_email = $user_obj->user_email;
            $first_name = get_user_meta($user_id,  'first_name');
            $last_name = get_user_meta($user_id,  'last_name');
            $zip_code = get_user_meta($user_id,  'zip_code');
            $custom_profile_pic = get_user_meta($user_id,  'user_avatar_url');
            $default_profile_pic = get_avatar_url($user_id);
            $full_name = implode(" ", $first_name) . ' ' . implode(" ", $last_name);
            $address = implode(" ", $zip_code);
            $notification = get_user_meta($user_id,  'notifications');
            $convert_string_notification = implode('', $notification);
            $remove_slash_notification = str_replace(array('"', "'"), '', stripslashes($convert_string_notification));
            $location_services = get_user_meta($user_id,  'location_services');
            $convert_string_location_services = implode('', $location_services);
            $timezone = get_user_meta($user_id,  'timezone');
            $convert_string_timezone = implode('', $timezone);
            $remove_slash_location_services = str_replace(array('"', "'"), '', stripslashes($convert_string_location_services));
//             $geo_location = file_get_contents("https://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$google_api_key");
//             $location_result = json_decode($geo_location, true);
//             $user_location = array();
//             foreach ($location_result as $key => $value) {
//                 foreach ($value as $skey => $svalue) {
//                     foreach ($svalue as $s_key => $s_value) {
//                         if ($s_key == 'formatted_address') {
//                             $user_location = $s_value;
//                         }
//                     }
//                 }
//             }
            $profile_pic = '';
            if ($custom_profile_pic) {
                $profile_pic = implode(' ', $custom_profile_pic);
            } else {
                $profile_pic = $default_profile_pic;
            }
            $user_profile = array([
                'profile_picture' => $profile_pic,
                'full_name' => $full_name,
                'username' => $user_name,
                'email' => $user_email,
                'location' => 'United States',
                'notifications' => $remove_slash_notification,
                'location_services' => $remove_slash_location_services,

            ]);
            $user_data = array();
            foreach ($user_profile as $key => $value) {
                $user_data = $value;
            }

            $response['success'] = true;
            $response['message'] = __("Account details.");
            $response['data'] = $user_data;
            return $response;
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
