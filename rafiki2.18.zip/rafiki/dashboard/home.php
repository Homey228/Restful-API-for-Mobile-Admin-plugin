<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

//Get user ip address
function get_the_user_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        //check ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        //to check ip is pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return apply_filters('wpb_get_ip', $ip);
}

add_shortcode('show_ip', 'get_the_user_ip');

function get_bearer_token($request)
{
    // If using WordPress REST API
    if ($request instanceof WP_REST_Request) {
        $auth_header = $request->get_header('Authorization');
    }
    // Fallback to server headers
    else {
        $headers = function_exists('apache_request_headers') ? apache_request_headers() : [];
        $auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');
    }

    // Validate Bearer token format
    if (!$auth_header || strpos($auth_header, 'Bearer ') !== 0) {
        return new WP_Error(
            'invalid_token',
            'Bearer token is missing or invalid',
            array('status' => 401)
        );
    }

    try {
        $token = trim(str_replace('Bearer ', '', $auth_header));
        if (empty($token)) {
            throw new Exception('Empty token');
        }
        return $token;
    } catch (Exception $e) {
        return new WP_Error(
            'token_extraction_failed',
            'Failed to extract token: ' . $e->getMessage(),
            array('status' => 401)
        );
    }
}


//Get data for dashboard
add_action('rest_api_init', 'rafiki_dashboard_home');

function rafiki_dashboard_home()
{
    register_rest_route(
        'wp/v2',
        'user/dashboard/home',
        array(
            'methods'  => 'POST',
            'callback' => 'dashboard_home',
        )
    );
}

error_log('Before dashboard home function');
function dashboard_home($request)
{
    error_log('Inside dashboard home function');
    $user_id = $request["user_id"];

    $token = get_bearer_token($request);

    if (is_wp_error($token)) {
        return $token;
    }

    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $google_api_key = defined('GOOGLE_MAP_API_KEY') ? GOOGLE_MAP_API_KEY : false;
    $event_list_limit = defined('EVENT_LIST_LIMIT') ? EVENT_LIST_LIMIT : false;
    $my_calender_limit = defined('MY_CALENDER_LIST_LIMIT') ? MY_CALENDER_LIST_LIMIT : false;
    $nearby_event_list_limit = defined('NEARBY_EVENT_LIST_LIMIT') ? NEARBY_EVENT_LIST_LIMIT : false;
    $distance_coverage = defined('DISTANCE_COVERAGE') ? DISTANCE_COVERAGE : false;
    error_log('Before try catch dashboard home endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));

        error_log('Dashboard home endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $user_obj = get_user_by('id', $user_id);
            $user_name = $user_obj->user_login;
            $args = array(
                'orderby'       =>  'post_date',
                'order'         =>  'ASC',
                'post_type' => 'tribe_events',
                'numberposts' => $event_list_limit,
                'post_status'   => array('publish', 'draft')
            );
            $current_user_posts = get_posts($args);
            $user_type_events = array();
            $user_type_events_single = array();
            $user_type_events_ar = array();
            $event_venu_id = array();
            $venu_zip_id_ar = array();
            $venu_zip_id_single_ar = array();
            $event_questions = array();
            $venu_zip = '';
            $event_start = '';
            $event_end = '';
            $event_featured = false;
            $event_popup = false;
            $_venueAddress = '';
            $_venueCity = '';
            $_venueCountry = '';
            $_venueProvince = '';
            $event_categories = '';
            foreach ($current_user_posts as $key => $value) {
                error_log($key . '    ' . print_r($value, true));
            }
            foreach ($current_user_posts as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_list = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_list = [];
                        foreach ($categories_list  as $cat_value) {
                            $cat_ar_list[] = $cat_value->name;
                        }

                        $event_categories = get_post_meta($svalue + 1,  'event_category_slugs');

                        $event_start = get_post_meta($svalue,  '_EventStartDate');
                        // First, get the raw meta value
                        $event_questions = get_post_meta($svalue, 'event_questions', true);
                        $event_start = array(date('Y-m-d h:i:s', strtotime($event_start[0])));
                        $event_end = get_post_meta($svalue,  '_EventEndDate');

                        $event_featured = get_post_meta($svalue,  'event_featured');
                        $event_featured = !empty($event_featured[0]) && $event_featured[0] === '1';

                        $event_popup = get_post_meta($svalue,  'event_popup');
                        $event_popup = !empty($event_popup[0]) && $event_popup[0] === '1';

                        $event_end = array(date('Y-m-d h:i:s', strtotime($event_end[0])));
                        $event_time_zone = get_post_meta($svalue,  '_EventTimezone');
                        $event_venu_id = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip = get_post_meta(implode($event_venu_id),  '_VenueZip');
                        $_venueAddress = get_post_meta(implode($event_venu_id),  '_VenueAddress');
                        $_venueCity = get_post_meta(implode($event_venu_id),  '_VenueCity');
                        $_venueCountry = get_post_meta(implode($event_venu_id),  '_VenueCountry');
                        $_venueProvince = get_post_meta(implode($event_venu_id),  '_VenueProvince');
                        $venu_zip_id_single_ar[$svalue] = $venu_zip;
                    }
                    unset($user_type_events_single['post_excerpt']);
                    unset($user_type_events_single['comment_status']);
                    unset($user_type_events_single['ping_status']);
                    unset($user_type_events_single['post_password']);
                    unset($user_type_events_single['post_name']);
                    unset($user_type_events_single['to_ping']);
                    unset($user_type_events_single['pinged']);
                    unset($user_type_events_single['post_content_filtered']);
                    unset($user_type_events_single['post_parent']);
                    unset($user_type_events_single['guid']);
                    unset($user_type_events_single['menu_order']);
                    unset($user_type_events_single['post_mime_type']);
                    unset($user_type_events_single['comment_count']);
                    unset($user_type_events_single['filter']);
                    $venu_zip_id_ar[] = $venu_zip_id_single_ar;
                    $user_type_events_ar['_EventStartDate'] = $event_start;
                    $user_type_events_ar['_EventEndDate'] = $event_end;
                    $user_type_events_ar['_EventTimezone'] = $event_time_zone;
                    $user_type_events_ar['_VenueAddress'] = $_venueAddress;
                    $user_type_events_ar['_VenueCity'] = $_venueCity;
                    $user_type_events_ar['_VenueProvince'] = $_venueProvince;
                    $user_type_events_ar['_VenueCountry'] = $_venueCountry;
                    $user_type_events_ar['_VenueZip'] = $venu_zip;
                    $user_type_events_ar['event_questions'] = $event_questions;
                    $user_type_events_single[$skey] = $svalue;
                    $user_type_events_single['event_featured'] = $event_featured;
                    $user_type_events_single['event_popup'] = $event_popup;
                    $user_type_events_single['event_categories'] = 'Therapy';
                }

                $user_type_events[] = array_merge($user_type_events_single, $user_type_events_ar);
            }

            //Geo location list - Start
            $args_geo = array(
                'orderby'       =>  'post_date',
                'order'         =>  'ASC',
                'post_type' => 'tribe_events',
                'numberposts' => -1,
                'post_status'   => array('publish', 'draft')
            );

            $current_user_posts_geo = get_posts($args_geo);
            $user_type_events_geo = array();
            $user_type_events_single_geo = array();
            $user_type_events_ar_geo = array();
            $event_venu_id_geo = array();
            $venu_zip_id_ar_geo = array();
            $venu_zip_id_single_ar_geo = array();
            $venu_zip_geo = '';
            $event_start_geo = '';
            $event_end_geo = '';
            $_venueAddress_geo = '';
            $_venueCity_geo = '';
            $event_questions_geo = array();
            $_venueCountry_geo = '';
            $_venueProvince_geo = '';
            $event_featured_geo = false;
            $event_popup_geo = false;
            foreach ($current_user_posts_geo as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_geo = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_geo = [];
                        foreach ($categories_geo  as $cat_value) {
                            $cat_ar_geo[] = $cat_value->name;
                        }
                        $cat_geo = implode(", ", $cat_ar_geo);
                        $event_start_geo = get_post_meta($svalue,  '_EventStartDate');
                        $event_start_geo = array(date('Y-m-d h:i:s', strtotime($event_start_geo[0])));
                        $event_end_geo = get_post_meta($svalue,  '_EventEndDate');

                        $event_featured_geo = get_post_meta($svalue,  'event_featured');
                        $event_featured_geo = !empty($event_featured_geo[0]) && $event_featured_geo[0] === '1';

                        $event_popup = get_post_meta($svalue,  'event_popup');
                        $event_popup = !empty($event_popup[0]) && $event_popup[0] === '1';


                        $event_end_geo = array(date('Y-m-d h:i:s', strtotime($event_end_geo[0])));
                        $event_time_zone_geo = get_post_meta($svalue,  '_EventTimezone');
                        $event_questions_geo = get_post_meta($svalue,  'event_questions');
                        $event_venu_id_geo = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueZip');
                        $_venueAddress_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueAddress');
                        $_venueCity_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueCity');
                        $_venueCountry_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueCountry');
                        $_venueProvince_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueProvince');
                        $venu_zip_id_single_ar_geo[$svalue] = $venu_zip_geo;
                    }
                    unset($user_type_events_single_geo['post_excerpt']);
                    unset($user_type_events_single_geo['comment_status']);
                    unset($user_type_events_single_geo['ping_status']);
                    unset($user_type_events_single_geo['post_password']);
                    unset($user_type_events_single_geo['post_name']);
                    unset($user_type_events_single_geo['to_ping']);
                    unset($user_type_events_single_geo['pinged']);
                    unset($user_type_events_single_geo['post_content_filtered']);
                    unset($user_type_events_single_geo['post_parent']);
                    unset($user_type_events_single_geo['guid']);
                    unset($user_type_events_single_geo['menu_order']);
                    unset($user_type_events_single_geo['post_mime_type']);
                    unset($user_type_events_single_geo['comment_count']);
                    unset($user_type_events_single_geo['filter']);
                    $venu_zip_id_ar_geo[] = $venu_zip_id_single_ar_geo;
                    $user_type_events_ar_geo['categories'] = $cat_geo;
                    $user_type_events_ar_geo['_EventStartDate'] = $event_start_geo;
                    $user_type_events_ar_geo['_EventEndDate'] = $event_end_geo;
                    $user_type_events_ar_geo['_EventTimezone'] = $event_time_zone_geo;
                    $user_type_events_ar_geo['_VenueAddress'] = $_venueAddress_geo;
                    $user_type_events_ar_geo['_VenueCity'] = $_venueCity_geo;
                    $user_type_events_ar_geo['event_questions'] = $event_questions_geo;
                    $user_type_events_ar_geo['_VenueProvince'] = $_venueProvince_geo;
                    $user_type_events_ar_geo['_VenueCountry'] = $_venueCountry_geo;
                    $user_type_events_ar_geo['_VenueZip'] = $venu_zip_geo;
                    $user_type_events_single_geo[$skey] = $svalue;
                    $user_type_events_single_geo['event_featured'] = $event_featured_geo;
                    $user_type_events_single_geo['event_popup'] = $event_popup_geo;
                    $user_type_events_single_geo['event_categories'] = 'Health Screening';

                }
                $user_type_events_geo[] = array_merge($user_type_events_single_geo, $user_type_events_ar_geo);
            }
            //Geo location list - End
            $unique_venu_zip_id_ar_geo = array();
            foreach ($venu_zip_id_ar_geo as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    $unique_venu_zip_id_ar_geo[$skey] = $svalue;
                }
            }
            $result_obj = array();
            foreach ($unique_venu_zip_id_ar_geo as $key => $value) {
                foreach ($value as $s_key => $address) {
                    $geo_location = file_get_contents("https://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$google_api_key");
                    $result = json_decode($geo_location, true);
                    $result_obj[$key] = $result;
                }
            }
            $post_id_location = array();
            foreach ($result_obj as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    foreach ($svalue as $s_key => $s_value) {
                        $post_id_location[$key] = $s_value['geometry']['location'];
                    }
                }
            }
            // $user_ip = '47.29.174.167';
            $user_ip = do_shortcode('[show_ip]');
            $geo_location = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
            $lat2 = $geo_location["geoplugin_latitude"];
            $lon2 = $geo_location["geoplugin_longitude"];
            $lat1 = '';
            $lon1 = '';
            $distance = array();
            foreach ($post_id_location as $key => $value) {
                foreach ($value as $s_key => $s_value) {
                    if ($s_key == 'lat') {
                        $lat1 = $s_value;
                    } else {
                        $lon1 = $s_value;
                    }
                }
                $theta = $lon1 - $lon2;
                $dist = sin(deg2rad((float)$lat1)) * sin(deg2rad((float)$lat2)) +
                    cos(deg2rad((float)$lat1)) * cos(deg2rad((float)$lat2)) * cos(deg2rad((float)$theta));
                $dist = acos($dist);
                $dist = rad2deg($dist);
                $distance[$key] = number_format((float)$dist * 60 * 1.1515 * 1.609344 * 0.62137119, 1, '.', ''); //miles
            }
            $nearby_post_list = array();
            foreach ($distance as $key => $value) {
                if ($value <= $distance_coverage) {
                    $nearby_post_list[] = get_post($key);
                }
            }
            //Enrolled post - Start
            $get_completed_order_id = get_posts([
                'author'        =>  $user_id,
                'fields' => 'ids',
                'post_type' => 'tec_tc_order',
                'post_status' => 'tec-tc-completed',
                'numberposts' => $my_calender_limit
            ]);
            $order_event_id = array();
            foreach ($get_completed_order_id as $value) {
                $order_event_id[] = get_post_meta($value,  '_tec_tc_order_events_in_order');
            }
            $order_event_id_ar = array();
            foreach ($order_event_id as $event_id) {
                foreach ($event_id as $s_event_id) {
                    $order_event_id_ar[] = $s_event_id;
                }
            }
            if ($order_event_id_ar) {
                $ordered_events = get_posts([
                    'include' => $order_event_id_ar,
                    'post_type' => 'tribe_events',
                    'numberposts' => -1,
                    'post_status'   => array('publish', 'draft')
                ]);
            }
            $user_type_events_order = array();
            $user_type_events_single_order = array();
            $user_type_events_ar_order = array();
            $event_venu_id_order = array();
            $venu_zip_id_ar_order = array();
            $venu_zip_id_single_ar_order = array();
            $venu_zip_order = '';
            $event_start_order = '';
            $event_end_order = '';
            $_venueAddress_order = '';
            $_venueCity_order = '';
            $event_questions_order = array();
            $_venueCountry_order = '';
            $_venueProvince_order = '';
            $event_featured_order = false;
            $event_popup_order = false;
            foreach ($ordered_events as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_calender = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_calender = [];
                        foreach ($categories_calender  as $cat_value) {
                            $cat_ar_calender[] = $cat_value->name;
                        }
                        $cat_calender = implode(", ", $cat_ar_calender);
                        $event_start_order = get_post_meta($svalue,  '_EventStartDate');
                        $event_start_order = array(date('Y-m-d h:i:s', strtotime($event_start_order[0])));
                        $event_end_order = get_post_meta($svalue,  '_EventEndDate');

                        $event_featured_order = get_post_meta($svalue,  'event_featured');
                        $event_featured_order = !empty($event_featured_order[0]) && $event_featured_order[0] === '1';

                        $event_popup = get_post_meta($svalue,  'event_popup');
                        $event_popup = !empty($event_popup[0]) && $event_popup[0] === '1';


                        $event_questions_order = get_post_meta($svalue,  'event_questions');
                        $event_end_order = array(date('Y-m-d h:i:s', strtotime($event_end_order[0])));
                        $event_time_zone_order = get_post_meta($svalue,  '_EventTimezone');
                        $event_venu_id_order = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip_order = get_post_meta(implode($event_venu_id_order),  '_VenueZip');
                        $_venueAddress_order = get_post_meta(implode($event_venu_id_order),  '_VenueAddress');
                        $_venueCity_order = get_post_meta(implode($event_venu_id_order),  '_VenueCity');
                        $_venueCountry_order = get_post_meta(implode($event_venu_id_order),  '_VenueCountry');
                        $_venueProvince_order = get_post_meta(implode($event_venu_id_order),  '_VenueProvince');
                        $venu_zip_id_single_ar_order[$svalue] = $venu_zip_order;
                    }
                    unset($user_type_events_single_order['post_excerpt']);
                    unset($user_type_events_single_order['comment_status']);
                    unset($user_type_events_single_order['ping_status']);
                    unset($user_type_events_single_order['post_password']);
                    unset($user_type_events_single_order['post_name']);
                    unset($user_type_events_single_order['to_ping']);
                    unset($user_type_events_single_order['pinged']);
                    unset($user_type_events_single_order['post_content_filtered']);
                    unset($user_type_events_single_order['post_parent']);
                    unset($user_type_events_single_order['guid']);
                    unset($user_type_events_single_order['menu_order']);
                    unset($user_type_events_single_order['post_mime_type']);
                    unset($user_type_events_single_order['comment_count']);
                    unset($user_type_events_single_order['filter']);
                    $venu_zip_id_ar_order[] = $venu_zip_id_single_ar_order;
                    $user_type_events_ar_order['categories'] = $cat_calender;
                    $user_type_events_ar_order['_EventStartDate'] = $event_start_order;
                    $user_type_events_ar_order['_EventEndDate'] = $event_end_order;
                    $user_type_events_ar_order['_EventTimezone'] = $event_time_zone_order;
                    $user_type_events_ar_order['_VenueAddress'] = $_venueAddress_order;
                    $user_type_events_ar_order['_VenueCity'] = $_venueCity_order;
                    $user_type_events_ar_order['event_questions'] = $event_questions_order;
                    $user_type_events_ar_order['_VenueProvince'] = $_venueProvince_order;
                    $user_type_events_ar_order['_VenueCountry'] = $_venueCountry_order;
                    $user_type_events_ar_order['_VenueZip'] = $venu_zip_order;
                    $user_type_events_single_order[$skey] = $svalue;
                    $user_type_events_single_order['event_featured'] = $event_featured_order;
                    $user_type_events_single_order['event_popup'] = $event_popup_order;
                    $user_type_events_single_order['event_categories'] = 'CAM Clinic';

                }
                $user_type_events_order[] = array_merge($user_type_events_single_order, $user_type_events_ar_order);
            }

            //Enrolled post - End

            // Nearby post - Start
            $user_type_events_nearby = array();
            $user_type_events_single_nearby = array();
            $user_type_events_ar_nearby = array();
            $event_venu_id_nearby = array();
            $venu_zip_id_ar_nearby = array();
            $venu_zip_id_single_ar_nearby = array();
            $event_questions_nearby = array();
            $venu_zip_nearby = '';
            $event_start_nearby = '';
            $event_end_nearby = '';
            $_venueAddress_nearby = '';
            $_venueCity_nearby = '';
            $_venueCountry_nearby = '';
            $_venueProvince_nearby = '';
            $limit = 1;
            $nearby_limit = $nearby_event_list_limit;
            $event_featured_nearby = false;
            $event_popup_nearby = false;

            foreach ($nearby_post_list as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_nearby = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_nearby = [];
                        foreach ($categories_nearby  as $cat_value) {
                            $cat_ar_nearby[] = $cat_value->name;
                        }
                        $cat_nearby = implode(", ", $cat_ar_nearby);
                        $event_start_nearby = get_post_meta($svalue,  '_EventStartDate');
                        $event_start_nearby = array(date('Y-m-d h:i:s', strtotime($event_start_nearby[0])));
                        $event_end_nearby = get_post_meta($svalue,  '_EventEndDate');
                        $event_questions_nearby = get_post_meta($svalue,  'event_questions');
                        $event_end_nearby = array(date('Y-m-d h:i:s', strtotime($event_end_nearby[0])));
                        $event_featured_nearby = get_post_meta($svalue,  'event_featured');
                        $event_featured_nearby = !empty($event_featured_nearby[0]) && $event_featured_nearby[0] === '1';

                        $event_popup = get_post_meta($svalue,  'event_popup');
                        $event_popup = !empty($event_popup[0]) && $event_popup[0] === '1';


                        $event_time_zone_nearby = get_post_meta($svalue,  '_EventTimezone');
                        $event_venu_id_nearby = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueZip');
                        $_venueAddress_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueAddress');
                        $_venueCity_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueCity');
                        $_venueCountry_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueCountry');
                        $_venueProvince_nearby = get_post_meta(implode($event_venu_id_nearby),  '_VenueProvince');
                        $venu_zip_id_single_ar_nearby[$svalue] = $venu_zip_nearby;
                    }
                    unset($user_type_events_single_nearby['post_excerpt']);
                    unset($user_type_events_single_nearby['comment_status']);
                    unset($user_type_events_single_nearby['ping_status']);
                    unset($user_type_events_single_nearby['post_password']);
                    unset($user_type_events_single_nearby['post_name']);
                    unset($user_type_events_single_nearby['to_ping']);
                    unset($user_type_events_single_nearby['pinged']);
                    unset($user_type_events_single_nearby['post_content_filtered']);
                    unset($user_type_events_single_nearby['post_parent']);
                    unset($user_type_events_single_nearby['guid']);
                    unset($user_type_events_single_nearby['menu_order']);
                    unset($user_type_events_single_nearby['post_mime_type']);
                    unset($user_type_events_single_nearby['comment_count']);
                    unset($user_type_events_single_nearby['filter']);
                    $venu_zip_id_ar_nearby[] = $venu_zip_id_single_ar_nearby;
                    $user_type_events_ar_nearby['categories'] = $cat_nearby;
                    $user_type_events_ar_nearby['_EventStartDate'] = $event_start_nearby;
                    $user_type_events_ar_nearby['_EventEndDate'] = $event_end_nearby;
                    $user_type_events_ar_nearby['_EventTimezone'] = $event_time_zone_nearby;
                    $user_type_events_ar_nearby['_VenueAddress'] = $_venueAddress_nearby;
                    $user_type_events_ar_nearby['_VenueCity'] = $_venueCity_nearby;
                    $user_type_events_ar_nearby['event_questions'] = $event_questions_nearby;
                    $user_type_events_ar_nearby['_VenueProvince'] = $_venueProvince_nearby;
                    $user_type_events_ar_nearby['_VenueCountry'] = $_venueCountry_nearby;
                    $user_type_events_ar_nearby['_VenueZip'] = $venu_zip_nearby;
                    $user_type_events_single_nearby[$skey] = $svalue;
                    $user_type_events_single_nearby['event_featured'] = $event_featured_nearby;
                    $user_type_events_single_nearby['event_popup'] = $event_popup_nearby;
                    $user_type_events_single_nearby['event_categories'] = 'Therapy';

                }
                $user_type_events_nearby[] = array_merge($user_type_events_single_nearby, $user_type_events_ar_nearby);
                $limit++;
                if ($limit > $nearby_limit) {
                    break;
                }
            }
            // Nearby post - end

            //recommended post - start
            $args_recommended_id = array(
                'orderby'       =>  'post_date',
                'order'         =>  'ASC',
                'post_type' => 'tribe_events',
                'numberposts' => -1,
                'post_status'   => array('publish', 'draft')
            );
            $recommend_post_id = get_posts($args_recommended_id);
            $open_event_ar_id = [];
            foreach ($recommend_post_id as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $event_end_nearby = get_post_meta($svalue,  '_EventEndDate');
                        $timestamp = strtotime($event_end_nearby[0]);
                        $datetime = date("Y-m", $timestamp);
                        $now = time();
                        $now_date = date("Y-m-d", $now);
                        $newDate = date('Y-m', strtotime($now_date . ' first day of +1 month'));
                        if ($datetime >= $newDate) {
                            $open_event_ar_id[] = $svalue;
                        }
                    }
                }
            }
            shuffle($open_event_ar_id);
            $two_recommend_ar = array_slice($open_event_ar_id, 0, 2);
            $args_recommended = array(
                'include' => $two_recommend_ar,
                'orderby'       =>  'post_date',
                'order'         =>  'ASC',
                'post_type' => 'tribe_events',
                'post_status'   => array('publish', 'draft')
            );
            $recommend_post = get_posts($args_recommended);
            $user_type_events_rec = array();
            $user_type_events_single_rec = array();
            $user_type_events_ar_rec = array();
            $event_venu_id_rec = array();
            $venu_zip_id_ar_rec = array();
            $venu_zip_id_single_ar_rec = array();
            $event_questions = array();
            $venu_zip_rec = '';
            $event_start_rec = '';
            $event_end_rec = '';
            $_venueAddress_rec = '';
            $_venueCity_rec = '';
            $_venueCountry_rec = '';
            $_venueProvince_rec = '';
            $event_featured_rec = false;
            $event_popup_rec = false;
            foreach ($recommend_post as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_rec = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_rec = [];
                        foreach ($categories_rec  as $cat_value) {
                            $cat_ar_rec[] = $cat_value->name;
                        }
                        $cat_rec = implode(", ", $cat_ar_rec);
                        $event_start_rec = get_post_meta($svalue,  '_EventStartDate');
                        $event_start_rec = array(date('Y-m-d h:i:s', strtotime($event_start_rec[0])));
                        $event_end_rec = get_post_meta($svalue,  '_EventEndDate');
                        $event_end_rec = array(date('Y-m-d h:i:s', strtotime($event_end_rec[0])));
                        $event_time_zone_rec = get_post_meta($svalue,  '_EventTimezone');
                        $event_venu_id_rec = get_post_meta($svalue,  '_EventVenueID');
                        $event_questions_rec = get_post_meta($svalue,  'event_questions');

                        $event_featured_rec = get_post_meta($svalue,  'event_featured');
                        $event_featured_rec = !empty($event_featured_rec[0]) && $event_featured_rec[0] === '1';

                        $event_popup_rec = get_post_meta($svalue,  'event_popup');
                        $event_popup_rec = !empty($event_popup_rec[0]) && $event_popup_rec[0] === '1';

                        $venu_zip_rec = get_post_meta(implode($event_venu_id_rec),  '_VenueZip');
                        $_venueAddress_rec = get_post_meta(implode($event_venu_id_rec),  '_VenueAddress');
                        $_venueCity_rec = get_post_meta(implode($event_venu_id_rec),  '_VenueCity');
                        $_venueCountry_rec = get_post_meta(implode($event_venu_id_rec),  '_VenueCountry');
                        $_venueProvince_rec = get_post_meta(implode($event_venu_id_rec),  '_VenueProvince');
                        $venu_zip_id_single_ar_rec[$svalue] = $venu_zip_rec;
                    }
                    unset($user_type_events_single_rec['post_excerpt']);
                    unset($user_type_events_single_rec['comment_status']);
                    unset($user_type_events_single_rec['ping_status']);
                    unset($user_type_events_single_rec['post_password']);
                    unset($user_type_events_single_rec['post_name']);
                    unset($user_type_events_single_rec['to_ping']);
                    unset($user_type_events_single_rec['pinged']);
                    unset($user_type_events_single_rec['post_content_filtered']);
                    unset($user_type_events_single_rec['post_parent']);
                    unset($user_type_events_single_rec['guid']);
                    unset($user_type_events_single_rec['menu_order']);
                    unset($user_type_events_single_rec['post_mime_type']);
                    unset($user_type_events_single_rec['comment_count']);
                    unset($user_type_events_single_rec['filter']);
                    $venu_zip_id_ar_rec[] = $venu_zip_id_single_ar_rec;
                    $user_type_events_ar_rec['categories'] = $cat_rec;
                    $user_type_events_ar_rec['_EventStartDate'] = $event_start_rec;
                    $user_type_events_ar_rec['_EventEndDate'] = $event_end_rec;
                    $user_type_events_ar_rec['_EventTimezone'] = $event_time_zone_rec;
                    $user_type_events_ar_rec['_VenueAddress'] = $_venueAddress_rec;
                    $user_type_events_ar_rec['_VenueCity'] = $_venueCity_rec;
                    $user_type_events_ar_rec['event_questions'] = $event_questions_rec;
                    $user_type_events_ar_rec['_VenueProvince'] = $_venueProvince_rec;
                    $user_type_events_ar_rec['_VenueCountry'] = $_venueCountry_rec;
                    $user_type_events_ar_rec['_VenueZip'] = $venu_zip_rec;
                    $user_type_events_single_rec['event_featured'] = $event_featured_rec;
                    $user_type_events_single_rec['event_popup'] = $event_popup_rec;
                    $user_type_events_single_rec['event_categories'] = 'Therapy';

                    $user_type_events_single_rec[$skey] = $svalue;
                }
                $user_type_events_rec[] = array_merge($user_type_events_single_rec, $user_type_events_ar_rec);
            }
            //recommended post - End
            //Upcoming post - Start
            $args_upcoming_id = array(
                'orderby'       =>  'post_date',
                'order'         =>  'ASC',
                'post_type' => 'tribe_events',
                'numberposts' => -1,
                'post_status'   => array('publish', 'draft')
            );
            $upcoming_post_id = get_posts($args_upcoming_id);
            $open_event_ar_id_up = [];
            foreach ($upcoming_post_id as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $event_end_nearby_up = get_post_meta($svalue,  '_EventEndDate');
                        $timestamp_up = strtotime($event_end_nearby_up[0]);
                        $datetime_up = date("Y-m", $timestamp);
                        $now_up = time();
                        $now_date_up = date("Y-m-d", $now_up);
                        $newDate_up = date('Y-m', strtotime($now_date_up . ' first day of +1 month'));
                        if ($datetime_up >= $newDate_up) {
                            $open_event_ar_id_up[] = $svalue;
                        }
                    }
                }
            }
            shuffle($open_event_ar_id_up);
            $two_upcoming_ar = array_slice($open_event_ar_id_up, 0, 2);
            $args_upcoming = array(
                'include' => $two_upcoming_ar,
                'orderby'       =>  'post_date',
                'order'         =>  'ASC',
                'post_type' => 'tribe_events',
                'post_status'   => array('publish', 'draft')
            );
            $upcoming_post = get_posts($args_upcoming);
            $user_type_events_up = array();
            $user_type_events_single_up = array();
            $user_type_events_ar_up = array();
            $event_venu_id_up = array();
            $venu_zip_id_ar_up = array();
            $venu_zip_id_single_ar_up = array();
            $event_questions_up = array();
            $venu_zip_up = '';
            $event_start_up = '';
            $event_end_up = '';
            $_venueAddress_up = '';
            $_venueCity_up = '';
            $_venueCountry_up = '';
            $_venueProvince_up = '';
            $event_featured_up = false;
            $event_popup_up = false;
            foreach ($upcoming_post as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_up = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_up = [];
                        foreach ($categories_up  as $cat_value) {
                            $cat_ar_up[] = $cat_value->name;
                        }
                        $cat_up = implode(", ", $cat_ar_up);
                        $event_start_up = get_post_meta($svalue,  '_EventStartDate');
                        $event_start_up = array(date('Y-m-d h:i:s', strtotime($event_start_up[0])));
                        $event_end_up = get_post_meta($svalue,  '_EventEndDate');
                        $event_end_up = array(date('Y-m-d h:i:s', strtotime($event_end_up[0])));
                        $event_time_zone_up = get_post_meta($svalue,  '_EventTimezone');
                        $event_questions_up = get_post_meta($svalue,  'event_questions');

                        $event_featured_up = get_post_meta($svalue,  'event_featured');
                        $event_featured_up = !empty($event_featured_up[0]) && $event_featured_up[0] === '1';

                        $event_popup = get_post_meta($svalue,  'event_popup');
                        $event_popup = !empty($event_popup[0]) && $event_popup[0] === '1';

                        $event_venu_id_up = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip_up = get_post_meta(implode($event_venu_id_up),  '_VenueZip');
                        $_venueAddress_up = get_post_meta(implode($event_venu_id_up),  '_VenueAddress');
                        $_venueCity_up = get_post_meta(implode($event_venu_id_up),  '_VenueCity');
                        $_venueCountry_up = get_post_meta(implode($event_venu_id_up),  '_VenueCountry');
                        $_venueProvince_up = get_post_meta(implode($event_venu_id_up),  '_VenueProvince');
                        $venu_zip_id_single_ar_up[$svalue] = $venu_zip_up;
                    }
                    unset($user_type_events_single_up['post_excerpt']);
                    unset($user_type_events_single_up['comment_status']);
                    unset($user_type_events_single_up['ping_status']);
                    unset($user_type_events_single_up['post_password']);
                    unset($user_type_events_single_up['post_name']);
                    unset($user_type_events_single_up['to_ping']);
                    unset($user_type_events_single_up['pinged']);
                    unset($user_type_events_single_up['post_content_filtered']);
                    unset($user_type_events_single_up['post_parent']);
                    unset($user_type_events_single_up['guid']);
                    unset($user_type_events_single_up['menu_order']);
                    unset($user_type_events_single_up['post_mime_type']);
                    unset($user_type_events_single_up['comment_count']);
                    unset($user_type_events_single_up['filter']);
                    $venu_zip_id_ar_up[] = $venu_zip_id_single_ar_up;
                    $user_type_events_ar_up['categories'] = $cat_up;
                    $user_type_events_ar_up['_EventStartDate'] = $event_start_up;
                    $user_type_events_ar_up['_EventEndDate'] = $event_end_up;
                    $user_type_events_ar_up['_EventTimezone'] = $event_time_zone_up;
                    $user_type_events_ar_up['_VenueAddress'] = $_venueAddress_up;
                    $user_type_events_ar_up['_VenueCity'] = $_venueCity_up;
                    $user_type_events_ar_up['event_questions'] = $event_questions_up;
                    $user_type_events_ar_up['_VenueProvince'] = $_venueProvince_up;
                    $user_type_events_ar_up['_VenueCountry'] = $_venueCountry_up;
                    $user_type_events_ar_up['_VenueZip'] = $venu_zip_up;
                    $user_type_events_single_up[$skey] = $svalue;
                    $user_type_events_single_up['event_featured'] = $event_featured_up;
                    $user_type_events_single_up['event_popup'] = $event_popup_up;
                    $user_type_events_single_up['event_categories'] = 'CAM Clinic';

                }
                $user_type_events_up[] = array_merge($user_type_events_single_up, $user_type_events_ar_up);
            }
            //Upcoming post - End
            $data_list = array([
                "username" => $user_name,
                "event_list" => $user_type_events,
                "my_calender" => $user_type_events_order,
                "recommended_event" => $user_type_events_rec,
                "nearby_event" => $user_type_events_nearby,
                "upcoming_event" => $user_type_events_up,
            ]);
            $total_event_list = array();
            foreach ($data_list as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    $total_event_list[$skey] = $svalue;
                }
            }
            $response['success'] = true;
            $response['message'] = __("Dashboard.");
            $response['data'] = $total_event_list;
            return $response;
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
