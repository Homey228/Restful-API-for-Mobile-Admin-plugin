<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;


//Update settings
add_action('rest_api_init', 'rafiki_user_account_settings');

function rafiki_user_account_settings()
{
    register_rest_route(
        'wp/v2',
        'user/account/settings/update',
        array(
            'methods'  => 'POST',
            'callback' => 'user_account_settings',
        )
    );
}
error_log('Before account seetings function');
function user_account_settings($request)
{
    error_log('Inside account seetings function');
    $user_id = $request["user_id"];
    $notifications = $request["notifications"];
    $location_services = $request["location_services"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    error_log('Before try catch account seetings endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Account seetings endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $old_notification = get_user_meta($user_id,  'notifications');
            $old_convert_string_notification = implode('', $old_notification);
            $remove_slash_notification = str_replace(array('"', "'"), '', stripslashes($old_convert_string_notification));
            $old_location_services = get_user_meta($user_id,  'location_services');
            $old_convert_string_location_services = implode('', $old_location_services);
            $remove_slash_location_services = str_replace(array('"', "'"), '', stripslashes($old_convert_string_location_services));

            if ($remove_slash_notification != $notifications) {
                update_user_meta($user_id, 'notifications', sprintf('"%s"', $notifications));
            }
            if ($remove_slash_location_services != $location_services) {
                update_user_meta($user_id, 'location_services',  sprintf('"%s"', $location_services));
            }
            $response['success'] = true;
            $response['message'] = __("Account settings save successfully.");
            return $response;
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
