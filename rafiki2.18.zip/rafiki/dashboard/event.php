<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

//Get data for event
add_action('rest_api_init', 'rafiki_single_event');

function rafiki_single_event()
{
    register_rest_route(
        'wp/v2',
        'user/dashboard/event',
        array(
            'methods'  => 'POST',
            'callback' => 'single_event',
        )
    );
}

error_log('Before single event function');
function single_event($request)
{
    error_log('Inside single event function');
    $user_id = $request["user_id"];
    $event_id = $request["id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $google_api_key = defined('GOOGLE_MAP_API_KEY') ? GOOGLE_MAP_API_KEY : false;
    $more_event_list_limit = defined('SINGLE_MORE_EVENT_LIST_LIMIT') ? SINGLE_MORE_EVENT_LIST_LIMIT : false;
    error_log('Before try catch single event endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Single event endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $order_event_id_ar = array($event_id);
            $single_event_ar = get_posts([
                'include' => $order_event_id_ar,
                'post_type' => 'tribe_events',
            ]);

            if ($single_event_ar) {
                $event_venu_id = array();
                $venu_zip = '';
                foreach ($single_event_ar as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $event_venu_id = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip = get_post_meta(implode($event_venu_id),  '_VenueZip');
                        }
                    }
                }

                // geo location
                $result_obj = array();
                foreach ($venu_zip as $key => $address) {
                    $geo_location = file_get_contents("https://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$google_api_key");
                    $result = json_decode($geo_location, true);
                    $result_obj[$key] = $result;
                }
                $post_id_location = array();
                foreach ($result_obj as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        foreach ($svalue as $s_key => $s_value) {
                            $post_id_location[$key] = $s_value['geometry']['location'];
                        }
                    }
                }
                // $user_ip = '47.29.169.238';
                $user_ip = do_shortcode('[show_ip]');
                $geo_location = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));

                $lat2 = $geo_location["geoplugin_latitude"];
                $lon2 = $geo_location["geoplugin_longitude"];
                $lat1 = '';
                $lon1 = '';
                $distance = '';
                foreach ($post_id_location as $key => $value) {

                    foreach ($value as $s_key => $s_value) {
                        if ($s_key == 'lat') {
                            $lat1 = $s_value;
                        } else {
                            $lon1 = $s_value;
                        }
                    }
                    $theta = $lon1 - $lon2;

                    $dist = sin(deg2rad((float)$lat1)) * sin(deg2rad((float)$lat2)) +
                        cos(deg2rad((float)$lat1)) * cos(deg2rad((float)$lat2)) * cos(deg2rad((float)$theta));
                    $dist = acos($dist);
                    $dist = rad2deg($dist);
                    $distance[$key] = number_format((float)$dist * 60 * 1.1515 * 1.609344 * 0.62137119, 1, '.', ''); //miles
                }

                //Enrolled post - Start
                $get_completed_order_id = get_posts([
                    'author'        =>  $user_id,
                    'fields' => 'ids',
                    'post_type' => 'tec_tc_order',
                    'post_status' => 'tec-tc-completed',
                    'numberposts' => -1
                    // 'order'    => 'ASC'
                ]);
                $order_event_id = array();
                foreach ($get_completed_order_id as $value) {
                    $order_event_id[] = get_post_meta($value,  '_tec_tc_order_events_in_order');
                }
                $order_event_id_ar = array();
                $subscribe_status = false;
                foreach ($order_event_id as $value) {
                    foreach ($value as $s_event_id) {
                        if ($event_id == $s_event_id) {
                            $subscribe_status = true;
                        }
                    }
                }

                $user_type_events_distance = array();
                $user_type_events_single_distance = array();
                $user_type_events_ar_distance = array();
                $event_venu_id_distance = array();
                $venu_zip_id_ar_distance = array();
                $venu_zip_id_single_ar_distance = array();
                $venu_zip_distance = '';
                $event_start_distance = '';
                $event_end_distance = '';
                $_venueAddress_distance = '';
                $_venueCity_distance = '';
                $_venueCountry_distance = '';
                $_venueProvince_distance = '';
                $_Thumbnail = '';
                $_Featured = '';
				$_eventorganizer_distance = '';
                foreach ($single_event_ar as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $categories_list = get_the_terms($svalue, 'tribe_events_cat');
                            $cat_ar_list = [];
                            foreach ($categories_list  as $cat_value) {
                                $cat_ar_list[] = $cat_value->name;
                            }
                            $cat_list = implode(", ", $cat_ar_list);
                            $event_start_distance = get_post_meta($svalue,  '_EventStartDate');
                            $event_start_distance = date('Y-m-d h:i:s', strtotime($event_start_distance[0]));
                            $event_end_distance = get_post_meta($svalue,  '_EventEndDate');
                            $event_end_distance = date('Y-m-d h:i:s', strtotime($event_end_distance[0]));
                            $event_time_zone_distance = get_post_meta($svalue,  '_EventTimezone',true);
                            $event_venu_id_distance = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueZip', true);
                            $_venueAddress_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueAddress', true);
                            $_venueCity_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueCity', true);
                            $_venueCountry_distance = get_post_meta($event_venu_id_distance,  '_VenueCountry', true);
                            $_venueProvince_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueProvince', true);
							$_eventorganizer_distance = get_post_meta($svalue, 'event_organizer', true);
							
                            $attach_id = get_post_meta($svalue, 'event_image', true);

                            $image = wp_get_attachment_url($attach_id);

                            $featured_event = get_post_meta($svalue,  'event_featured');
                            if ($featured_event) {
                                $_Featured = true;
                            } else {
                                $_Featured = false;
                            }
                            $popup_event = get_post_meta($svalue,  'event_popup');
                            if ($popup_event) {
                                $_Popup = true;
                            } else {
                                $_Popup = false;
                            }
                            $venu_zip_id_single_ar_distance[$svalue] = $venu_zip_distance;
                        }
                        unset($user_type_events_single_distance['post_excerpt']);
                        unset($user_type_events_single_distance['post_status']);
                        unset($user_type_events_single_distance['comment_status']);
                        unset($user_type_events_single_distance['ping_status']);
                        unset($user_type_events_single_distance['post_password']);
                        unset($user_type_events_single_distance['post_name']);
                        unset($user_type_events_single_distance['to_ping']);
                        unset($user_type_events_single_distance['pinged']);
                        unset($user_type_events_single_distance['post_content_filtered']);
                        unset($user_type_events_single_distance['post_parent']);
                        unset($user_type_events_single_distance['guid']);
                        unset($user_type_events_single_distance['menu_order']);
                        unset($user_type_events_single_distance['post_mime_type']);
                        unset($user_type_events_single_distance['comment_count']);
                        unset($user_type_events_single_distance['filter']);
                        $venu_zip_id_ar_distance[] = $venu_zip_id_single_ar_distance;
                        $user_type_events_ar_distance['categories'] = $cat_list;
                        $user_type_events_ar_distance['_EventStartDate'] = $event_start_distance;
                        $user_type_events_ar_distance['_EventEndDate'] = $event_end_distance;
                        $user_type_events_ar_distance['_EventTimezone'] = $event_time_zone_distance;
                        $user_type_events_ar_distance['_VenueAddress'] = $_venueAddress_distance;
                        $user_type_events_ar_distance['_VenueCity'] = $_venueCity_distance;
                        $user_type_events_ar_distance['_VenueProvince'] = $_venueProvince_distance;
                        $user_type_events_ar_distance['_VenueCountry'] = $_venueCountry_distance;
                        $user_type_events_ar_distance['_VenueZip'] = $venu_zip_distance;
                        $user_type_events_ar_distance['_Distance'] = $distance;
                        $user_type_events_ar_distance['_Subscribe'] = $subscribe_status;
                        $user_type_events_ar_distance['_Attachment'] = $image;
                        $user_type_events_ar_distance['event_featured'] = $_Featured;
                        $user_type_events_ar_distance['event_popup'] = $_Popup;
						$user_type_events_ar_distance['event_organizer'] = $_eventorganizer_distance;
						
                        $user_type_events_single_distance[$skey] = $svalue;
                    }

                    $user_type_events_distance[] = array_merge($user_type_events_single_distance, $user_type_events_ar_distance);
                }


                //More events - Start
                $single_event_more = get_posts([
                    'post_type' => 'tribe_events',
                    'numberposts' => $more_event_list_limit
                    // 'order'    => 'ASC'
                ]);
                $user_type_events_more = array();
                $user_type_events_single_more = array();
                $user_type_events_ar_more = array();
                $event_venu_id_more = array();
                $venu_zip_id_ar_more = array();
                $venu_zip_id_single_ar_more = array();
                $venu_zip_more = '';
                $event_start_more = '';
                $event_end_more = '';
                $_venueAddress_more = '';
                $_venueCity_more = '';
                $_venueCountry_more = '';
                $_venueProvince_more = '';
                foreach ($single_event_more as $key => $value) {
                    foreach ($value as $skey => $svalue) {
                        if ($skey == 'ID') {
                            $categories_more = get_the_terms($svalue, 'tribe_events_cat');
                            $cat_ar_more = [];
                            foreach ($categories_more  as $cat_value) {
                                $cat_ar_more[] = $cat_value->name;
                            }
                            $cat_more = implode(", ", $cat_ar_more);
                            $event_start_more = get_post_meta($svalue,  '_EventStartDate');
                            $event_start_more = date('Y-m-d h:i:s', strtotime($event_start_more[0]));
                            $event_end_more = get_post_meta($svalue,  '_EventEndDate');
                            $event_end_more = date('Y-m-d h:i:s', strtotime($event_end_more[0]));
                            $event_time_zone_more = get_post_meta($svalue,  '_EventTimezone',true);
                            $event_venu_id_more = get_post_meta($svalue,  '_EventVenueID');
                            $venu_zip_more = get_post_meta(implode($event_venu_id_more),  '_VenueZip',true);
                            $_venueAddress_more = get_post_meta(implode($event_venu_id_more),  '_VenueAddress',true);
                            $_venueCity_more = get_post_meta(implode($event_venu_id_more),  '_VenueCity',true);
                            $_venueCountry_more = get_post_meta(implode($event_venu_id_more),  '_VenueCountry',true);
                            $_venueProvince_more = get_post_meta(implode($event_venu_id_more),  '_VenueProvince',true);
                            $venu_zip_id_single_ar_more[$svalue] = $venu_zip_more;
                        }
                        unset($user_type_events_single_more['post_excerpt']);
                        unset($user_type_events_single_more['post_status']);
                        unset($user_type_events_single_more['comment_status']);
                        unset($user_type_events_single_more['ping_status']);
                        unset($user_type_events_single_more['post_password']);
                        unset($user_type_events_single_more['post_name']);
                        unset($user_type_events_single_more['to_ping']);
                        unset($user_type_events_single_more['pinged']);
                        unset($user_type_events_single_more['post_content_filtered']);
                        unset($user_type_events_single_more['post_parent']);
                        unset($user_type_events_single_more['guid']);
                        unset($user_type_events_single_more['menu_order']);
                        unset($user_type_events_single_more['post_mime_type']);
                        unset($user_type_events_single_more['comment_count']);
                        unset($user_type_events_single_more['filter']);
                        $venu_zip_id_ar_more[] = $venu_zip_id_single_ar_more;
                        $user_type_events_ar_more['categories'] = $cat_more;
                        $user_type_events_ar_more['_EventStartDate'] = $event_start_more;
                        $user_type_events_ar_more['_EventEndDate'] = $event_end_more;
                        $user_type_events_ar_more['_EventTimezone'] = $event_time_zone_more;
                        $user_type_events_ar_more['_VenueAddress'] = $_venueAddress_more;
                        $user_type_events_ar_more['_VenueCity'] = $_venueCity_more;
                        $user_type_events_ar_more['_VenueProvince'] = $_venueProvince_more;
                        $user_type_events_ar_more['_VenueCountry'] = $_venueCountry_more;
                        $user_type_events_ar_more['_VenueZip'] = $venu_zip_more;
                        $user_type_events_single_more[$skey] = $svalue;
                    }

                    $user_type_events_more[] = array_merge($user_type_events_single_more, $user_type_events_ar_more);
                }

                $single_event_detail = array();
                foreach ($user_type_events_distance as $key => $value) {
                    $single_event_detail = $value;
                    $single_event_detail['more_event'] = $user_type_events_more;
                }
                //More events - End

                $response['success'] = true;
                $response['message'] = __("Single event details.");
                $response['data'] = $single_event_detail;
                return $response;
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid event id.";
                return $response;
            }
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
