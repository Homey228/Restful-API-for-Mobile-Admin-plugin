<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;


//Get data for dashboard
add_action('rest_api_init', 'rafiki_search_event');

function rafiki_search_event()
{
    register_rest_route(
        'wp/v2',
        'user/dashboard/search',
        array(
            'methods'  => 'POST',
            'callback' => 'search_event',
        )
    );
}

error_log('Before dashboard search event function');
function search_event($request)
{
    error_log('Inside dashboard search event function');
    $user_id = $request["user_id"];
    $search_meta_value = $request["search"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $search_limit = defined('SEARCH_EVENT_LIST_LIMIT') ? SEARCH_EVENT_LIST_LIMIT : false;
    $google_api_key = defined('GOOGLE_MAP_API_KEY') ? GOOGLE_MAP_API_KEY : false;
    error_log('Before try catch dashboard search event endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('dashboard search event endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $search_event_ar = get_posts([
                's' => $search_meta_value,
                'post_type' => 'tribe_events',
                'numberposts' => $search_limit
                // 'order'    => 'ASC'
            ]);
            $total_count = count($search_event_ar);
            $event_venu_id_geo = array();
            $venu_zip_id_ar_geo = array();
            $venu_zip_id_single_ar_geo = array();
            $venu_zip_geo = '';
            foreach ($search_event_ar as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $event_venu_id_geo = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip_geo = get_post_meta(implode($event_venu_id_geo),  '_VenueZip');
                        $venu_zip_id_single_ar_geo[$svalue] = $venu_zip_geo;
                    }
                    $venu_zip_id_ar_geo[] = $venu_zip_id_single_ar_geo;
                }
            }
            //distance
            $unique_venu_zip_id_ar_geo = array();
            foreach ($venu_zip_id_ar_geo as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    $unique_venu_zip_id_ar_geo[$skey] = $svalue;
                }
            }
            $result_obj = array();
            foreach ($unique_venu_zip_id_ar_geo as $key => $value) {
                foreach ($value as $s_key => $address) {
                    $geo_location = file_get_contents("https://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$google_api_key");
                    $result = json_decode($geo_location, true);
                    $result_obj[$key] = $result;
                }
            }
            $post_id_location = array();
            foreach ($result_obj as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    foreach ($svalue as $s_key => $s_value) {
                        $post_id_location[$key] = $s_value['geometry']['location'];
                    }
                }
            }
            // $user_ip = '47.29.169.238';
            $user_ip = do_shortcode('[show_ip]');
            $geo_location = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));

            $lat2 = $geo_location["geoplugin_latitude"];
            $lon2 = $geo_location["geoplugin_longitude"];
            $lat1 = '';
            $lon1 = '';
            $distance = array();
            foreach ($post_id_location as $key => $value) {
                foreach ($value as $s_key => $s_value) {
                    if ($s_key == 'lat') {
                        $lat1 = $s_value;
                    } else {
                        $lon1 = $s_value;
                    }
                }
                $theta = $lon1 - $lon2;

                $dist = sin(deg2rad((float)$lat1)) * sin(deg2rad((float)$lat2)) +
                    cos(deg2rad((float)$lat1)) * cos(deg2rad((float)$lat2)) * cos(deg2rad((float)$theta));
                $dist = acos($dist);
                $dist = rad2deg($dist);
                $distance[$key] = number_format((float)$dist * 60 * 1.1515 * 1.609344 * 0.62137119, 1, '.', ''); //miles
            }
            //event
            $user_type_events = array();
            $user_type_events_single = array();
            $user_type_events_ar = array();
            $event_venu_id = array();
            $venu_zip_id_ar = array();
            $venu_zip_id_single_ar = array();
            $venu_zip = '';
            $event_start = '';
            $event_end = '';
            $_venueAddress = '';
            $_venueCity = '';
            $_venueCountry = '';
            $_venueProvince = '';
            foreach ($search_event_ar as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_search = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_search = [];
                        foreach ($categories_search  as $cat_value) {
                            $cat_ar_search[] = $cat_value->name;
                        }
                        $cat_search = implode(", ", $cat_ar_search);
                        $event_start = get_post_meta($svalue,  '_EventStartDate');
                        $event_start = array(date('Y-m-d h:i:s', strtotime($event_start[0])));
                        $event_end = get_post_meta($svalue,  '_EventEndDate');
                        $event_end = array(date('Y-m-d h:i:s', strtotime($event_end[0])));
                        $event_time_zone = get_post_meta($svalue,  '_EventTimezone');
                        $event_venu_id = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip = get_post_meta(implode($event_venu_id),  '_VenueZip');
                        $_venueAddress = get_post_meta(implode($event_venu_id),  '_VenueAddress');
                        $_venueCity = get_post_meta(implode($event_venu_id),  '_VenueCity');
                        $_venueCountry = get_post_meta(implode($event_venu_id),  '_VenueCountry');
                        $_venueProvince = get_post_meta(implode($event_venu_id),  '_VenueProvince');
                        $venu_zip_id_single_ar[$svalue] = $venu_zip;
                    }
                    unset($user_type_events_single['post_excerpt']);
                    unset($user_type_events_single['post_status']);
                    unset($user_type_events_single['comment_status']);
                    unset($user_type_events_single['ping_status']);
                    unset($user_type_events_single['post_password']);
                    unset($user_type_events_single['post_name']);
                    unset($user_type_events_single['to_ping']);
                    unset($user_type_events_single['pinged']);
                    unset($user_type_events_single['post_content_filtered']);
                    unset($user_type_events_single['post_parent']);
                    unset($user_type_events_single['guid']);
                    unset($user_type_events_single['menu_order']);
                    unset($user_type_events_single['post_mime_type']);
                    unset($user_type_events_single['comment_count']);
                    unset($user_type_events_single['filter']);
                    $venu_zip_id_ar[] = $venu_zip_id_single_ar;
                    $user_type_events_ar['categories'] = $cat_search;
                    $user_type_events_ar['_EventStartDate'] = $event_start;
                    $user_type_events_ar['_EventEndDate'] = $event_end;
                    $user_type_events_ar['_EventTimezone'] = $event_time_zone;
                    $user_type_events_ar['_VenueAddress'] = $_venueAddress;
                    $user_type_events_ar['_VenueCity'] = $_venueCity;
                    $user_type_events_ar['_VenueProvince'] = $_venueProvince;
                    $user_type_events_ar['_VenueCountry'] = $_venueCountry;
                    $user_type_events_ar['_VenueZip'] = $venu_zip;
                    $user_type_events_single[$skey] = $svalue;
                }

                $user_type_events[] = array_merge($user_type_events_single, $user_type_events_ar);
            }

            $search_event = array();
            foreach ($user_type_events as $key => $value) {
                foreach ($distance as $skey => $svalue) {
                    if ($value['ID'] == $skey) {
                        $value['_Distance'] = $svalue;
                    }
                }
                $search_event[] = $value;
            }
            $data_list = array([
                "total_count" => $total_count,
                "search_list" => $search_event,
            ]);
            $total_event_list = array();
            foreach ($data_list as $key => $value) {
                $total_event_list = $value;
            }
            $response['success'] = true;
            $response['message'] = __("Search event list.");
            $response['data'] = $total_event_list;
            return $response;
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
