<?php
//Intake-form table
function intake_client_form_tb()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    $table_name = $rafiki_prefix . 'intake_form';
    $sql = "CREATE TABLE $table_name (
    id INTEGER NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    first_name TEXT NULL,
    last_name TEXT NULL,
    dob DATE NULL,
    address TEXT NULL,
    city TEXT NULL,
    state TEXT NULL,
    country TEXT NULL,
    zip_code TEXT NULL,
    phone_number TEXT NULL,
    email TEXT NULL,
    emergency_contact_name TEXT NULL,
    emergency_phone_number TEXT NULL,
    contact_method TEXT NULL,
    gender TEXT NULL,
    sexual_orientation TEXT NULL,
    marital_status TEXT NULL,
    housing_status TEXT NULL,
    household_income TEXT NULL,
    number_in_household TEXT NULL,
    source_of_income TEXT NULL,
    health_insurance TEXT NULL,
    diagnosed_or_risk_1 json NULL,
    diagnosed_or_risk_2 json NULL,
    diagnosed_or_risk_3 json NULL,
    experienced json NULL,
    current_mental_health_provider TEXT NULL,
    physician_name TEXT NULL,
    physician_phone_number TEXT NULL,
    essential_medications_list TEXT NULL,
    weight TEXT NULL,
    blood_pressure TEXT NULL,
    cholesterol TEXT NULL,
    height TEXT NULL,
    glucose TEXT NULL,
    cigarette_smoking TEXT NULL,
    alcohol_use TEXT NULL,
    exercise TEXT NULL,
    substances_used_in_12_months json NULL,
    sought_services TEXT NULL,
    health_and_wellness_services json NULL,
    date DATE NULL,
    created TEXT NOT NULL,
    updated TEXT NOT NULL,
    PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
}
add_action('init', 'intake_client_form_tb');
