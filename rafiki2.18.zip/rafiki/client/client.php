<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

// Save Client Informations
add_action('rest_api_init', 'rafiki_site_client_contact_intake_form');
function rafiki_site_client_contact_intake_form()
{
    register_rest_route(
        'wp/v2',
        'intake-form/client-information/save',
        array(
            'methods'  => 'POST',
            'callback' => 'site_client_contact_intake_form',
        )
    );
}
error_log('Before intake-form therapy function');
function site_client_contact_intake_form($request)
{
    error_log('Inside intake-form therapy function');
    global $wpdb;
    $user_id = $request["user_id"];
    $first_name = $request["first_name"];
    $last_name = $request["last_name"];
    $dob = $request["dob"];
    $address = $request["address"];
    $city = $request["city"];
    $state = $request["state"];
    $country = $request["country"];
    $zip_code = $request["zip_code"];
    $phone_number = $request["phone_number"];
    $email = $request["email"];
    $emergency_contact_name = $request["emergency_contact_name"];
    $emergency_phone_number = $request["emergency_phone_number"];
    $contact_method = $request["contact_method"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch intake-form therapy endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Intake-form therapy endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name = $rafiki_prefix . "intake_form";
            $date = DateTime::createFromFormat('Y-m-d', $dob);
            if ($date) {
                $final_date = $date->format('Y-m-d');
            } else {
                $response['success'] = false;
                $response['message'] = "DOB format must be year-month-day, example 2012-12-30.";
                return $response;
            }
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_created = utc_time_zone($current_time, wp_timezone_string());
            $utc_created = $date_time_utc_created . ' UTC';
            $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated . ' UTC';
            $intake_form_id_db = $wpdb->get_row("SELECT id FROM $table_name WHERE user_id = $user_id");
            if (!is_null($intake_form_id_db)) {
                $wpdb->query("UPDATE $table_name SET `first_name` = '$first_name' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `last_name` = '$last_name' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `dob` = '$dob' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `address` = '$address' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `city` = '$city' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `state` = '$state' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `country` = '$country' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `zip_code` = '$zip_code' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `phone_number` = '$phone_number' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `email` = '$email' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `emergency_contact_name` = '$emergency_contact_name' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `emergency_phone_number` = '$emergency_phone_number' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `contact_method` = '$contact_method' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `updated` = '$utc_updated' WHERE  user_id = $user_id");
                $response['success'] = true;
                $response['message'] = "Client Contact information saved successfully.";
                return $response;
            } else {
                $wpdb->insert(
                    $table_name,
                    array(
                        'user_id' => $user_id,
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'dob' => $dob,
                        'address' => $address,
                        'city' => $city,
                        'state' => $state,
                        'country' => $country,
                        'zip_code' => $zip_code,
                        'phone_number' => $phone_number,
                        'email' => $email,
                        'emergency_contact_name' => $emergency_contact_name,
                        'emergency_phone_number' => $emergency_phone_number,
                        'contact_method' => $contact_method,
                        'created' => $utc_created,
                        'updated' => $utc_updated,
                    )
                );
                $response['success'] = true;
                $response['message'] = "Client Contact information saved successfully.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Get Client Informations
add_action('rest_api_init', 'rafiki_site_client_contact_intake_form_view');

function rafiki_site_client_contact_intake_form_view()
{
    register_rest_route(
        'wp/v2',
        'intake-form/client-information',
        array(
            'methods'  => 'POST',
            'callback' => 'site_get_last_client_contact_intake_form',
        )
    );
}
error_log('Before get client contact intake form function');
function site_get_last_client_contact_intake_form($request)
{
    error_log('Inside last client contact function');
    global $wpdb;
    $user_id = $request["user_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch last client contact endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Last client contact endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name = $rafiki_prefix . "intake_form";
            $intake_last_record = $wpdb->get_row("SELECT id,coalesce(first_name, '') as first_name,coalesce(last_name, '') as last_name,coalesce(dob, '') as dob,coalesce(address, '') as address,coalesce(city, '') as city,coalesce(state, '') as state,coalesce(country, '') as country,coalesce(zip_code, '') as zip_code,coalesce(phone_number, '') as phone_number,coalesce(email, '') as email,coalesce(emergency_contact_name, '') as emergency_contact_name,coalesce(emergency_phone_number, '') as emergency_phone_number,coalesce(contact_method, '') as contact_method,created,updated FROM $table_name where user_id=$user_id ORDER BY id DESC limit 1");
            if (is_null($intake_last_record)) {
                $response['success'] = false;
                $response['message'] = "Client contact information record not found.";
                return $response;
            } else {
                $response['success'] = true;
                $response['message'] = "Client contact information.";
                $response['data'] = $intake_last_record;
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Save Demographics
add_action('rest_api_init', 'rafiki_site_client_demographic_intake_form');
function rafiki_site_client_demographic_intake_form()
{
    register_rest_route(
        'wp/v2',
        'intake-form/client-demographic/save',
        array(
            'methods'  => 'POST',
            'callback' => 'site_client_demographic_intake_form',
        )
    );
}
error_log('Before intake-form demographic function');
function site_client_demographic_intake_form($request)
{
    error_log('Inside intake-form demographic function');
    global $wpdb;
    $user_id = $request["user_id"];
    $gender = $request["gender"];
    $sexual_orientation = $request["sexual_orientation"];
    $marital_status = $request["marital_status"];
    $housing_status = $request["housing_status"];
    $household_income = $request["household_income"];
    $number_in_household = $request["number_in_household"];
    $source_of_income = $request["source_of_income"];
    $health_insurance = $request["health_insurance"];
    $diagnosed_or_risk_1 = $request["diagnosed_or_risk_1"];
    $diagnosed_or_risk_2 = $request["diagnosed_or_risk_2"];
    $diagnosed_or_risk_3 = $request["diagnosed_or_risk_3"];
    $experienced = $request["experienced"];
    $current_mental_health_provider = $request["current_mental_health_provider"];
    $physician_name = $request["physician_name"];
    $physician_phone_number = $request["physician_phone_number"];
    $essential_medications_list = $request["essential_medications_list"];
    $weight = $request["weight"];
    $blood_pressure = $request["blood_pressure"];
    $cholesterol = $request["cholesterol"];
    $height = $request["height"];
    $glucose = $request["glucose"];
    $cigarette_smoking = $request["cigarette_smoking"];
    $alcohol_use = $request["alcohol_use"];
    $exercise = $request["exercise"];
    $substances_used_in_12_months = $request["substances_used_in_12_months"];
    $sought_services = $request["sought_services"];
    $health_and_wellness_services = $request["health_and_wellness_services"];
    $create_date = $request["date"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch intake-form demographic endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Intake-form demographic endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name = $rafiki_prefix . "intake_form";
            $date = DateTime::createFromFormat('Y-m-d', $create_date);
            if ($date) {
                $final_date = $date->format('Y-m-d');
            } else {
                $response['success'] = false;
                $response['message'] = "Date format must be year-month-day, example 2012-12-30.";
                return $response;
            }
            $diagnosed_or_risk_1 = json_encode($diagnosed_or_risk_1);
            $diagnosed_or_risk_2 = json_encode($diagnosed_or_risk_2);
            $diagnosed_or_risk_3 = json_encode($diagnosed_or_risk_3);
            $health_and_wellness_services = json_encode($health_and_wellness_services);
            $experienced = json_encode($experienced);
            $substances_used_in_12_months = json_encode($substances_used_in_12_months);
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_created = utc_time_zone($current_time, wp_timezone_string());
            $utc_created = $date_time_utc_created . ' UTC';
            $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated . ' UTC';
            $intake_form_id_db = $wpdb->get_row("SELECT id FROM $table_name WHERE user_id = $user_id");
            if (!is_null($intake_form_id_db)) {
                $wpdb->query("UPDATE $table_name SET `gender` = '$gender' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `sexual_orientation` = '$sexual_orientation' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `marital_status` = '$marital_status' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `housing_status` = '$housing_status' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `household_income` = '$household_income' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `number_in_household` = '$number_in_household' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `source_of_income` = '$source_of_income' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `health_insurance` = '$health_insurance' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `diagnosed_or_risk_1` = '$diagnosed_or_risk_1' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `diagnosed_or_risk_2` = '$diagnosed_or_risk_2' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `diagnosed_or_risk_3` = '$diagnosed_or_risk_3' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `experienced` = '$experienced' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `current_mental_health_provider` = '$current_mental_health_provider' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `physician_name` = '$physician_name' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `physician_phone_number` = '$physician_phone_number' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `essential_medications_list` = '$essential_medications_list' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `weight` = '$weight' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `blood_pressure` = '$blood_pressure' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `cholesterol` = '$cholesterol' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `height` = '$height' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `glucose` = '$glucose' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `cigarette_smoking` = '$cigarette_smoking' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `alcohol_use` = '$alcohol_use' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `exercise` = '$exercise' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `substances_used_in_12_months` = '$substances_used_in_12_months' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `sought_services` = '$sought_services' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `health_and_wellness_services` = '$health_and_wellness_services' WHERE  user_id = $user_id");
                $wpdb->query("UPDATE $table_name SET `date` = '$create_date' WHERE  user_id = $user_id");

                $wpdb->query("UPDATE $table_name SET `updated` = '$utc_updated' WHERE  user_id = $user_id");
                $response['success'] = true;
                $response['message'] = "Client Demographics saved successfully.";
                return $response;
            } else {
                $wpdb->insert(
                    $table_name,
                    array(
                        'user_id' => $user_id,
                        "gender" => $gender,
                        "sexual_orientation" => $sexual_orientation,
                        "marital_status" => $marital_status,
                        "housing_status" => $housing_status,
                        "household_income" => $household_income,
                        "number_in_household" => $number_in_household,
                        "source_of_income" => $source_of_income,
                        "health_insurance" => $health_insurance,
                        "diagnosed_or_risk_1" => $diagnosed_or_risk_1,
                        "diagnosed_or_risk_2" => $diagnosed_or_risk_2,
                        "diagnosed_or_risk_3" => $diagnosed_or_risk_3,
                        "experienced" => $experienced,
                        "current_mental_health_provider" => $current_mental_health_provider,
                        "physician_name" => $physician_name,
                        "physician_phone_number" => $physician_phone_number,
                        "essential_medications_list" => $essential_medications_list,
                        "weight" => $weight,
                        "blood_pressure" => $blood_pressure,
                        "cholesterol" => $cholesterol,
                        "height" => $height,
                        "glucose" => $glucose,
                        "cigarette_smoking" => $cigarette_smoking,
                        "alcohol_use" => $alcohol_use,
                        "exercise" => $exercise,
                        "substances_used_in_12_months" => $substances_used_in_12_months,
                        "sought_services" => $sought_services,
                        "health_and_wellness_services" => $health_and_wellness_services,
                        "date" => $create_date,
                        'created' => $utc_created,
                        'updated' => $utc_updated,
                    )
                );
                $response['success'] = true;
                $response['message'] = "Client Demographics saved successfully.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Get Demographics
add_action('rest_api_init', 'rafiki_site_client_demographic_intake_form_view');

function rafiki_site_client_demographic_intake_form_view()
{
    register_rest_route(
        'wp/v2',
        'intake-form/client-demographic',
        array(
            'methods'  => 'POST',
            'callback' => 'site_get_last_client_demographic_intake_form',
        )
    );
}
error_log('Before get client demographic intake form function');
function site_get_last_client_demographic_intake_form($request)
{
    error_log('Inside last client demographic function');
    global $wpdb;
    $user_id = $request["user_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch last client contact endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Last client contact endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name = $rafiki_prefix . "intake_form";
            $intake_last_record = $wpdb->get_row("SELECT id,coalesce(gender, '') as gender,coalesce(sexual_orientation, '') as sexual_orientation, coalesce(marital_status, '') as marital_status, coalesce(housing_status, '') as housing_status, coalesce(household_income, '') as household_income,coalesce(number_in_household, '') as number_in_household,coalesce(source_of_income, '') as source_of_income, coalesce(health_insurance, '') as health_insurance,coalesce(diagnosed_or_risk_1, '') as diagnosed_or_risk_1,coalesce(diagnosed_or_risk_2, '') as diagnosed_or_risk_2,coalesce(diagnosed_or_risk_3, '') as diagnosed_or_risk_3,coalesce(experienced, '') as experienced,coalesce(current_mental_health_provider, '') as current_mental_health_provider,coalesce(physician_name, '') as physician_name,coalesce(physician_phone_number, '') as physician_phone_number,coalesce(essential_medications_list, '') as essential_medications_list,coalesce(weight, '') as weight, coalesce(blood_pressure, '') as blood_pressure,coalesce(cholesterol, '') as cholesterol, coalesce(height, '') as height, coalesce(glucose, '') as glucose, coalesce(cigarette_smoking, '') as cigarette_smoking,coalesce(alcohol_use, '') as alcohol_use,coalesce(exercise, '') as exercise,coalesce(substances_used_in_12_months, '') as substances_used_in_12_months,coalesce(sought_services, '') as sought_services,coalesce(health_and_wellness_services, '') as health_and_wellness_services,coalesce(date, '') as date,created,updated FROM $table_name where user_id=$user_id ORDER BY id DESC limit 1");
            if (is_null($intake_last_record)) {
                $response['success'] = false;
                $response['message'] = "Client demographics record not found.";
                return $response;
            } else {
                $data = [];
                foreach ($intake_last_record as $key => $value) {
                    if ($key == "diagnosed_or_risk_1") {
                        $data[$key] = json_decode(stripslashes($value), true);
                    } else if ($key == "diagnosed_or_risk_2") {
                        $data[$key] = json_decode(stripslashes($value), true);
                    } else if ($key == "diagnosed_or_risk_3") {
                        $data[$key] = json_decode(stripslashes($value));
                    } else if ($key == "experienced") {
                        $data[$key] = json_decode(stripslashes($value));
                    } else if ($key == "substances_used_in_12_months") {
                        $data[$key] = json_decode(stripslashes($value));
                    } else if ($key == "health_and_wellness_services") {
                        $data[$key] = json_decode(stripslashes($value));
                    } else {
                        $data[$key] = $value;
                    }
                }
                $response['success'] = true;
                $response['message'] = "Client demographics.";
                $response['data'] = $data;
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}