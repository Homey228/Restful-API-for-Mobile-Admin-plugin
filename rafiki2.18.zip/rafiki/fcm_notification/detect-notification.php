<?php

use Google\Auth\CredentialsLoader;
use GuzzleHttp\Client;

function getAccessToken()
{
    $keyFilePath = __DIR__ . '/service-key.json';

    $client = new Client();
    $creds = CredentialsLoader::makeCredentials(
        ['https://www.googleapis.com/auth/firebase.messaging'],
        json_decode(file_get_contents($keyFilePath), true)
    );

    // Use fetchAuthToken() instead of refreshTokenWithAssertion()
    $auth_token = $creds->fetchAuthToken();
    return $auth_token['access_token'];
}


add_action('save_post_notification', 'send_push_notification', 10, 3);

function send_push_notification($post_ID, $post, $update) {
    // Check if it's a notification post type and status is 'sent'
    if ($post->post_type !== 'notification' || $post->post_status !== 'sent') {
        return;
    }

    // Get how to send setting (0 = immediate, 1 = scheduled)
    $how_to_send = intval(get_post_meta($post_ID, 'notification_how_to_send', true));


    error_log('Notification status: ' . $how_to_send);
    if ($how_to_send == '0') {
        // Immediate notification
        send_fcm_notification($post->post_title, $post->post_content);
        error_log('Immediate notification sent: ' . $post->post_title);
    } 
    elseif ($how_to_send === '1') {
        // Scheduled notification
        $scheduled_time = get_post_meta($post_ID, 'notification_scheduled_time', true);
        
        if (!empty($scheduled_time)) {
            // Schedule the event if it hasn't been scheduled yet
            if (!wp_next_scheduled('do_scheduled_notification', array($post_ID))) {
                wp_schedule_single_event(
                    strtotime($scheduled_time),
                    'do_scheduled_notification',
                    array($post_ID)
                );
                error_log('Notification scheduled for: ' . $scheduled_time . ' - ' . $post->post_title);
            }
        }
    }

    update_post_meta($post_ID, '_previous_status', $post->post_status);
}

// Add action for scheduled notifications
add_action('do_scheduled_notification', 'handle_scheduled_notification');

function handle_scheduled_notification($post_ID) {
    $post = get_post($post_ID);
    
    if ($post && $post->post_status === 'sent') {
        send_fcm_notification($post->post_title, $post->post_content);
        error_log('Scheduled notification sent: ' . $post->post_title);
    }
}

// Make sure WP Cron is working
if (!wp_next_scheduled('wp_scheduled_notification_check')) {
    wp_schedule_event(time(), 'hourly', 'wp_scheduled_notification_check');
}

// Add action to check for missed notifications
add_action('wp_scheduled_notification_check', 'check_missed_notifications');

function check_missed_notifications() {
    $args = array(
        'post_type' => 'notification',
        'post_status' => 'sent',
        'meta_query' => array(
            array(
                'key' => 'notification_how_to_send',
                'value' => '1',
                'compare' => '='
            )
        )
    );

    $notifications = get_posts($args);

    foreach ($notifications as $notification) {
        $scheduled_time = get_post_meta($notification->ID, 'notification_scheduled_time', true);
        
        if (!empty($scheduled_time) && 
            strtotime($scheduled_time) <= time() && 
            !get_post_meta($notification->ID, '_notification_sent', true)) {
            
            send_fcm_notification($notification->post_title, $notification->post_content);
            update_post_meta($notification->ID, '_notification_sent', true);
            error_log('Missed notification sent: ' . $notification->post_title);
        }
    }
}


function send_fcm_notification($title, $body)
{
    error_log('asdfasdfa' . $title . ' ' . $body);
    $accessToken = getAccessToken(); // Get OAuth 2.0 token
    $projectId = 'rafiki-89267'; // Replace with your Firebase project ID
    $url = "https://fcm.googleapis.com/v1/projects/$projectId/messages:send";

    $fields = [
        'message' => [
            'topic' => 'all', // Replace with actual topic or 'token' => 'device_token'
            'notification' => [
                'title' => $title,
                'body' => $body
            ]
        ]
    ];

    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    file_put_contents(__DIR__ . '/fcm_log.txt', date('Y-m-d H:i:s') . " - HTTP: $http_code - Response: $result\n", FILE_APPEND);

    return json_decode($result, true);
}



