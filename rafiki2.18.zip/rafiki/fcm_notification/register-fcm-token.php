<?php
add_action('rest_api_init', function () {
    register_rest_route('wp/v2', '/notification/register', array(
        'methods' => 'POST',
        'callback' => 'register_fcm_token',
        'permission_callback' => '__return_true'
    ));
});

function register_fcm_token(WP_REST_Request $request)
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'fcm_tokens';

    // Extract request parameters
    $user_id = intval($request->get_param('user_id'));
    $device_token = sanitize_text_field($request->get_param('device_token'));
    $device_type = strtoupper(sanitize_text_field($request->get_param('device_type')));
    $is_enable = filter_var($request->get_param('is_enable'), FILTER_VALIDATE_BOOLEAN);

    // Validate required fields
    if (!$user_id || !$device_token || !in_array($device_type, ['ANDROID', 'IOS'])) {
        return new WP_Error('invalid_request', 'Missing or invalid parameters', array('status' => 400));
    }

    // Check if the user already has a token
    $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE user_id = %d AND device_token = %s", $user_id, $device_token));

    if ($existing) {
        // Update existing record
        $wpdb->update(
            $table_name,
            ['is_enable' => $is_enable, 'device_type' => $device_type, 'device_token' => $device_token],
            ['id' => $existing]
        );
    } else {
        // Insert new record
        $wpdb->insert($table_name, [
            'user_id' => $user_id,
            'device_token' => $device_token,
            'device_type' => $device_type,
            'is_enable' => $is_enable
        ]);
    }

    return rest_ensure_response([
        'status' => true,
        'message' => 'Notification registration successful'
    ]);
}
