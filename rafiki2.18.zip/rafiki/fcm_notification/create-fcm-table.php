<?php


function create_fcm_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'fcm_tokens';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        device_token TEXT NOT NULL,
        device_type ENUM('ANDROID', 'IOS') NOT NULL,
        is_enable BOOLEAN DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}


// Include the FCM table creation file
// In create-fcm-table.php
register_activation_hook(WP_PLUGIN_DIR . '/rafiki/rafiki-backend.php', 'create_fcm_table');


