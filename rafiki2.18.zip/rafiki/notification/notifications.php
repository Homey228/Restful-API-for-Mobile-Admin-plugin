<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

add_action('rest_api_init', function () {
    register_rest_route('wp/v2', 'get/notifications', array(
        'methods' => 'POST',
        'callback' => 'get_notifications'
    ));
});

function get_notifications(WP_REST_Request $request)
{
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }

    $params = $request->get_json_params();
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        $token_user_id = $data->data->user->id;

        // Check if the user is an administrator
        $user = get_user_by('ID', $token_user_id);
        if (!$user || !in_array('administrator', $user->roles)) {
            return new WP_Error('forbidden', 'You do not have permission to access this resource.', array('status' => 403));
        }
        $user_id = $params["user_id"];

        if ($user_id == $token_user_id) {
            $args = array(
                'post_type' => 'notification',
                'post_author' => $user_id,
                'posts_per_page' => -1,
                'post_status' => array('sent', 'draft', 'scheduled'), // Get notifications with these statuses
            );

            $query = new WP_Query($args);

            error_log('Query results: ' . print_r($query, true));

            if (!$query->have_posts()) {
                $response['success'] = true;
                $response['message'] = "There is no notification.";
                return $response;
            }

            $notifications = array();

            foreach ($query->posts as $post) {
                $notifications[] = array(
                    'post_id' => $post->ID,
                    'notification_title' => $post->post_title,
                    'notification_description' => $post->post_content,
                    'notification_status' => $post->post_status,
                    'notification_send_to_all_users' => get_post_meta($post->ID, 'notification_send_to_all_users', true),
                    'notification_event_attendees' => maybe_unserialize(get_post_meta($post->ID, 'notification_event_attendees', true)),
                    'notification_tags' => maybe_unserialize(get_post_meta($post->ID, 'notification_tags', true)),
                    'notification_link' => get_post_meta($post->ID, 'notification_link', true),
                    'notification_image' => get_post_meta($post->ID, 'notification_image', true),
                    'notification_how_to_send' => get_post_meta($post->ID, 'notification_how_to_send', true),
                    'notification_geo_category' => maybe_unserialize(get_post_meta($post->ID, 'notification_geo_category', true)),
                    'notification_geo_fence_expiration_date' => get_post_meta($post->ID, 'notification_geo_fence_expiration_date', true),
                    'notification_scheduled_time' => get_post_meta($post->ID, 'notification_scheduled_time', true),
                    'notification_create_at' => get_post_meta($post->ID, 'notification_create_at', true),
                );
            }
            $response['success'] = true;
            $response['notifications'] = $notifications;
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        return new WP_Error('invalid_token', 'Invalid token.', array('status' => 401));
    } catch (ExpiredException $e) {
        return new WP_Error('expired_token', 'Token expired.', array('status' => 401));
    } catch (Exception $e) {
        return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
    }
}


add_action('rest_api_init', function () {
    register_rest_route('wp/v2', 'get/notifications/draft', array(
        'methods' => 'POST',
        'callback' => 'get_notifications_draft'
    ));
});

function get_notifications_draft(WP_REST_Request $request)
{
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }

    $params = $request->get_json_params();
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        $token_user_id = $data->data->user->id;

        // Check if the user is an administrator
        $user = get_user_by('ID', $token_user_id);
        if (!$user || !in_array('administrator', $user->roles)) {
            return new WP_Error('forbidden', 'You do not have permission to access this resource.', array('status' => 403));
        }
        $user_id = $params["user_id"];

        if ($user_id == $token_user_id) {
            $args = array(
                'post_type' => 'notification',
                'post_author' => $user_id,
                'posts_per_page' => -1,
                'post_status' => 'draft',
            );

            $query = new WP_Query($args);

            error_log('Query results: ' . print_r($query, true));

            if (!$query->have_posts()) {
                $response['success'] = true;
                $response['message'] = "There is no draft notification.";
                return $response;
            }

            $notifications = array();

            foreach ($query->posts as $post) {
                $notifications[] = array(
                    'post_id' => $post->ID,
                    'notification_title' => $post->post_title,
                    'notification_description' => $post->post_content,
                    'notification_status' => $post->post_status,
                    'notification_send_to_all_users' => get_post_meta($post->ID, 'notification_send_to_all_users', true),
                    'notification_event_attendees' => maybe_unserialize(get_post_meta($post->ID, 'notification_event_attendees', true)),
                    'notification_tags' => maybe_unserialize(get_post_meta($post->ID, 'notification_tags', true)),
                    'notification_link' => get_post_meta($post->ID, 'notification_link', true),
                    'notification_image' => get_post_meta($post->ID, 'notification_image', true),
                    'notification_how_to_send' => get_post_meta($post->ID, 'notification_how_to_send', true),
                    'notification_geo_category' => maybe_unserialize(get_post_meta($post->ID, 'notification_geo_category', true)),
                    'notification_geo_fence_expiration_date' => get_post_meta($post->ID, 'notification_geo_fence_expiration_date', true),
                    'notification_scheduled_time' => get_post_meta($post->ID, 'notification_scheduled_time', true),
                    'notification_create_at' => get_post_meta($post->ID, 'notification_create_at', true),

                );
            }
            $response['success'] = true;
            $response['notifications'] = $notifications;
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        return new WP_Error('invalid_token', 'Invalid token.', array('status' => 401));
    } catch (ExpiredException $e) {
        return new WP_Error('expired_token', 'Token expired.', array('status' => 401));
    } catch (Exception $e) {
        return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
    }
}


add_action('rest_api_init', function () {
    register_rest_route('wp/v2', 'get/notifications/sent', array(
        'methods' => 'POST',
        'callback' => 'get_notifications_sent'
    ));
});

function get_notifications_sent(WP_REST_Request $request)
{
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }

    $params = $request->get_json_params();
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        $token_user_id = $data->data->user->id;

        // Check if the user is an administrator
        $user = get_user_by('ID', $token_user_id);
        if (!$user || !in_array('administrator', $user->roles)) {
            return new WP_Error('forbidden', 'You do not have permission to access this resource.', array('status' => 403));
        }
        $user_id = $params["user_id"];

        if ($user_id == $token_user_id) {
            $args = array(
                'post_type' => 'notification',
                'post_author' => $user_id,
                'posts_per_page' => -1,
                'post_status' => 'sent',
            );

            $query = new WP_Query($args);

            error_log('Query results: ' . print_r($query, true));

            if (!$query->have_posts()) {
                $response['success'] = true;
                $response['message'] = "There is no sent notification.";
                return $response;
            }

            $notifications = array();

            foreach ($query->posts as $post) {
                $notifications[] = array(
                    'post_id' => $post->ID,
                    'notification_title' => $post->post_title,
                    'notification_description' => $post->post_content,
                    'notification_status' => $post->post_status,
                    'notification_send_to_all_users' => get_post_meta($post->ID, 'notification_send_to_all_users', true),
                    'notification_event_attendees' => maybe_unserialize(get_post_meta($post->ID, 'notification_event_attendees', true)),
                    'notification_tags' => maybe_unserialize(get_post_meta($post->ID, 'notification_tags', true)),
                    'notification_link' => get_post_meta($post->ID, 'notification_link', true),
                    'notification_image' => get_post_meta($post->ID, 'notification_image', true),
                    'notification_how_to_send' => get_post_meta($post->ID, 'notification_how_to_send', true),
                    'notification_geo_category' => maybe_unserialize(get_post_meta($post->ID, 'notification_geo_category', true)),
                    'notification_geo_fence_expiration_date' => get_post_meta($post->ID, 'notification_geo_fence_expiration_date', true),
                    'notification_create_at' => get_post_meta($post->ID, 'notification_create_at', true),
                    'notification_scheduled_time' => get_post_meta($post->ID, 'notification_scheduled_time', true),
                );
            }
            $response['success'] = true;
            $response['notifications'] = $notifications;
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        return new WP_Error('invalid_token', 'Invalid token.', array('status' => 401));
    } catch (ExpiredException $e) {
        return new WP_Error('expired_token', 'Token expired.', array('status' => 401));
    } catch (Exception $e) {
        return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
    }
}

add_action('rest_api_init', function () {
    register_rest_route('wp/v2', 'get/notifications/scheduled', array(
        'methods' => 'POST',
        'callback' => 'get_notifications_scheduled'
    ));
});

function get_notifications_scheduled(WP_REST_Request $request)
{
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $params = $request->get_json_params();
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        $token_user_id = $data->data->user->id;

        // Check if the user is an administrator
        $user = get_user_by('ID', $token_user_id);
        if (!$user || !in_array('administrator', $user->roles)) {
            return new WP_Error('forbidden', 'You do not have permission to access this resource.', array('status' => 403));
        }
        $user_id = $params["user_id"];

        if ($user_id == $token_user_id) {
            $args = array(
                'post_type' => 'notification',
                'post_author' => $user_id,
                'posts_per_page' => -1,
                'post_status' => 'scheduled',
            );

            $query = new WP_Query($args);

            error_log('Query results: ' . print_r($query, true));

            if (!$query->have_posts()) {
                $response['success'] = true;
                $response['message'] = "There is no Scheduled notification.";
                return $response;
            }

            $notifications = array();

            foreach ($query->posts as $post) {
                $notifications[] = array(
                    'post_id' => $post->ID,
                    'notification_title' => $post->post_title,
                    'notification_description' => $post->post_content,
                    'notification_status' => $post->post_status,
                    'notification_send_to_all_users' => get_post_meta($post->ID, 'notification_send_to_all_users', true),
                    'notification_event_attendees' => maybe_unserialize(get_post_meta($post->ID, 'notification_event_attendees', true)),
                    'notification_tags' => maybe_unserialize(get_post_meta($post->ID, 'notification_tags', true)),
                    'notification_link' => get_post_meta($post->ID, 'notification_link', true),
                    'notification_image' => get_post_meta($post->ID, 'notification_image', true),
                    'notification_how_to_send' => get_post_meta($post->ID, 'notification_how_to_send', true),
                    'notification_geo_category' => maybe_unserialize(get_post_meta($post->ID, 'notification_geo_category', true)),
                    'notification_geo_fence_expiration_date' => get_post_meta($post->ID, 'notification_geo_fence_expiration_date', true),
                    'notification_scheduled_time' => get_post_meta($post->ID, 'notification_scheduled_time', true),
                    'notification_create_at' => get_post_meta($post->ID, 'notification_create_at', true),
                );
            }
            $response['success'] = true;
            $response['notifications'] = $notifications;
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        return new WP_Error('invalid_token', 'Invalid token.', array('status' => 401));
    } catch (ExpiredException $e) {
        return new WP_Error('expired_token', 'Token expired.', array('status' => 401));
    } catch (Exception $e) {
        return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
    }
}
