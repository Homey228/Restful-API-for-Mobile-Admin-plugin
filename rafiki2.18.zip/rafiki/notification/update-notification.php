<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

// Register update notification endpoint
add_action('rest_api_init', function () {
    register_rest_route('wp/v2', '/update/notification', array(
        'methods' => 'POST',
        'callback' => 'update_notification'
    ));
});

function update_notification(WP_REST_Request $request)
{
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }

    $params = $request->get_json_params();
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        $token_user_id = $data->data->user->id;

        // Check if the user is an administrator
        $user = get_user_by('ID', $token_user_id);
        if (!$user || !in_array('administrator', $user->roles)) {
            return new WP_Error('forbidden', 'You do not have permission to access this resource.', array('status' => 403));
        }

        // Check if notification_id is provided
        $notification_id = isset($params["notification_id"]) ? (int) $params["notification_id"] : 0;
        if (!$notification_id) {
            return new WP_Error('missing_notification_id', 'Notification ID is required', array('status' => 400));
        }

        // Check if the notification exists
        $post = get_post($notification_id);
        if (!$post || 'notification' !== $post->post_type) {
            return new WP_Error('notification_not_found', 'Notification not found.', array('status' => 404));
        }

        // Check if the current user is the author of the notification
        if ($post->post_author != $token_user_id) {
            return new WP_Error('forbidden', 'You do not have permission to update this notification.', array('status' => 403));
        }

        // Validate and sanitize the parameters
        $required_fields = ['notification_title', 'notification_description', 'notification_status'];
        foreach ($required_fields as $field) {
            if (empty($params[$field])) {
                return new WP_Error('missing_field', "$field is required", array('status' => 400));
            }
        }

        // Validate notification status
        $valid_statuses = array('sent', 'draft', 'scheduled');
        $status = sanitize_text_field($params['notification_status']);
        if (!in_array($status, $valid_statuses)) {
            return new WP_Error('invalid_status', 'Invalid notification status. Must be one of: ' . implode(', ', $valid_statuses), array('status' => 400));
        }

        // Update the post data
        $post_data = array(
            'ID' => $notification_id,
            'post_title'   => sanitize_text_field($params['notification_title']),
            'post_content' => sanitize_textarea_field($params['notification_description']),
            'post_status'  => $status,
        );

        // Update the post
        $updated_post_id = wp_update_post($post_data);

        if (is_wp_error($updated_post_id)) {
            return $updated_post_id;
        }

        // Update metadata
        update_post_meta($updated_post_id, 'notification_send_to_all_users', !empty($params['notification_send_to_all_users']));
        update_post_meta($updated_post_id, 'notification_event_attendees', maybe_serialize($params['notification_event_attendees']));
        update_post_meta($updated_post_id, 'notification_tags', maybe_serialize($params['notification_tags']));
        update_post_meta($updated_post_id, 'notification_link', esc_url_raw($params['notification_link']));
        update_post_meta($updated_post_id, 'notification_image', sanitize_text_field($params['notification_image']));
        update_post_meta($updated_post_id, 'notification_how_to_send', intval($params['notification_how_to_send']));
        update_post_meta($updated_post_id, 'notification_geo_category', maybe_serialize($params['notification_geo_category']));
        update_post_meta($updated_post_id, 'notification_geo_fence_expiration_date', sanitize_text_field($params['notification_geo_fence_expiration_date']));
        update_post_meta($updated_post_id, 'notification_scheduled_time', sanitize_text_field($params['notification_scheduled_time']));

        $response['success'] = true;
        $response['message'] = "Notification updated successfully.";
        return $response;

    } catch (SignatureInvalidException $e) {
        return new WP_Error('invalid_token', 'Invalid token.', array('status' => 401));
    } catch (ExpiredException $e) {
        return new WP_Error('expired_token', 'Token expired.', array('status' => 401));
    } catch (Exception $e) {
        return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
    }
}
