<?php
function register_notification_statuses()
{
    register_post_status('sent', array(
        'label' => _x('Sent', 'notification'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop(
            'Sent <span class="count">(%s)</span>',
            'Sent <span class="count">(%s)</span>'
        )
    ));

    register_post_status('draft', array(
        'label' => _x('Draft', 'notification'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop(
            'Draft <span class="count">(%s)</span>',
            'Draft <span class="count">(%s)</span>'
        )
    ));

    register_post_status('scheduled', array(
        'label' => _x('Scheduled', 'notification'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop(
            'Scheduled <span class="count">(%s)</span>',
            'Scheduled <span class="count">(%s)</span>'
        )
    ));

    register_post_status('publish', array(
        'label' => _x('publish', 'tribe_events'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop(
            'publish <span class="count">(%s)</span>',
            'publish <span class="count">(%s)</span>'
        )
    ));
}
add_action('init', 'register_notification_statuses');
