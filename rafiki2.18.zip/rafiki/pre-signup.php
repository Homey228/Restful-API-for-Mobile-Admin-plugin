<?php

//Get data for dashboard
add_action('rest_api_init', 'rafiki_pre_signup');

function rafiki_pre_signup()
{
   register_rest_route(
      'wp/v2',
      'user/pre-signup',
      array(
         'methods'  => 'POST',
         'callback' => 'pre_signup_question',
      )
   );
}
function pre_signup_question($request)
{
   $get_parent_cats = array(
      'taxonomy' => 'tribe_events_cat',
      'hierarchical' => true,
      'orderby' => 'term_order',
      'hide_empty' => false,
      'parent' => '0' //get top level categories only
   );

   $all_categories = get_categories($get_parent_cats);
   $child_cats = array();
   $parent_child_array = array();
   foreach ($all_categories as $single_category) {
      $parent_cat_id = $single_category->term_id;
      $parent_cat_slug = $single_category->slug;
      $parent_cat_name = $single_category->name;
      $taxonomies = array(
         'taxonomy' => 'tribe_events_cat',
      );
      $args = array(
         'child_of'      => $parent_cat_id,
         'hide_empty' => false,
      );
      $child_cats = get_terms($taxonomies, $args);
      $child_cat_arr = array();
      $child_cat_combine_arr = array();
      foreach ($child_cats as $key => $value) {
         $child_cat_arr['slug'] = $value->slug;
         $child_cat_arr['name'] = $value->name;
         $child_cat_combine_arr[] = $child_cat_arr;
      }
      $terms['slug'] = $parent_cat_slug;
      $terms['name'] = $parent_cat_name;
      $terms['sub_category'] = $child_cat_combine_arr;
      $parent_child_array[] = $terms;
   }
   $combine_cat = json_encode($parent_child_array);
   $pre_signup = '{
        "What services can we connect you with?": ' . $combine_cat . ',
        "Are you Black/African-American?":{
            "Yes":[
               "African American",
               "North African",
               "Central African",
               "West African",
               "East African",
               "South African"
            ],
            "No":[
               "Caucasian",
               "Native American", 
               "Pacific Islander", 
               "Hispanic/Latinx",  
			      "Prefer not to say" 
            ]
         },
        "What do you do in San Francisco?": ["Live", "Work","Learn", "Play", "Pray","Other"]
    }';
   $pre_signup_data = json_decode($pre_signup, true);
   $response['success'] = true;
   $response['message'] = "Pre-signup question.";
   $response['data'] = $pre_signup_data;
   return $response;
}

