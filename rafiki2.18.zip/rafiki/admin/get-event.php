<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

// Register create notification endpoint
add_action('rest_api_init', function () {
    register_rest_route('wp/v2', '/get/event', array(
        'methods' => 'POST',
        'callback' => 'get_event_by_id'
    ));
});

// Function to fetch event by post_id
function get_event_by_id($request)
{

    $token = get_bearer_token($request);

    if (is_wp_error($token)) {
        return $token;
    }
    $params = $request->get_json_params();
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('create notification endpoints decoded: ' . print_r($data, true));
        $token_user_id = $data->data->user->id;

        // Check if the user is an administrator
        $user = get_user_by('ID', $token_user_id);
        if (!$user || !in_array('administrator', $user->roles)) {
            return new WP_Error('forbidden', 'You do not have permission to access this resource.', array('status' => 403));
        }
        $user_id = $params["user_id"];
        if ($user_id == $token_user_id) {
            $post_id = $params['post_id'];

            // Validate post ID
            if (empty($post_id) || !is_numeric($post_id)) {
                return new WP_Error('invalid_id', 'Invalid event ID', array('status' => 400));
            }

            $event = get_post($post_id);

            // Check if the post exists and is of type 'event'
            if (!$event || $event->post_type !== 'event') {
                return new WP_Error('not_found', 'Event not found', array('status' => 404));
            }

            // Prepare event data
            $event_data = [
                'post_id'         => $event->ID,
                'event_title'     => $event->post_title,
                'event_description' => $event->post_content,
                'event_status'    => $event->post_status,
            ];

            // Fetch event metadata
            $meta_keys = [
                'event_start_time',
                'event_end_time',
                'event_is_virtual',
                'event_meeting_link',
                'event_recurring',
                'event_repeat_every',
                'event_repeat_on',
                'event_date',
                'event_never',
                'event_on',
                'event_after',
                'event_members',
                'event_modify_event',
                'event_invite_others',
                'event_view_member_list',
                'event_category_slugs',
                'event_location',
                'event_organizer',
                'event_image',
                'event_featured',
                'event_popup',
                'event_questions'

            ];

            foreach ($meta_keys as $key) {
                $event_data[$key] = get_post_meta($post_id, $key, true);
            }

            $response['success'] = true;
            $response['data'] = $event_data;
            $response['message'] = "We successfully sent that event.";

            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        return new WP_Error('invalid_token', 'Invalid token.', array('status' => 401));
    } catch (ExpiredException $e) {
        return new WP_Error('expired_token', 'Token expired.', array('status' => 401));
    } catch (Exception $e) {
        return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
    }
}
