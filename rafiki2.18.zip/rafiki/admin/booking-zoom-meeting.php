<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;
use Abdulbaset\ZoomIntegration\ZoomIntegrationService;

require __DIR__ . '/../vendor/autoload.php';

add_action('rest_api_init', 'wp_admin_booking_zoom');
function wp_admin_booking_zoom($request)
{
    /**
     * Handle Register User request.
     */
    register_rest_route(
        'wp/v2',
        'admin/generate-meeting',
        array(
            'methods' => 'POST',
            'callback' => 'rafiki_generate_meeting',
        ),
    );
}
function rafiki_generate_meeting($request)
{
    $params = $request->get_json_params();
    error_log('Inside create event function');
    $user_id = $request["user_id"];
    $email = $params['email'];
    $first_name = $params['first_name'];
    $last_name = $params['last_name'];
    $token = get_bearer_token($request);

    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {

            $registrantData = [
                'email' => $email,
                'first_name' => $first_name,
                'last_name' => $last_name,
            ];


            $config = include __DIR__ . '/../config/config.php';

            $account_id = $config['accountId'];
            $client_id = $config['clientId'];
            $client_secret = $config['clientSecret'];

            $zoomService = new ZoomIntegrationService($account_id, $client_id, $client_secret);

            $meetingData = [
                'topic' => 'Team6785',
                'type' => 2,  // Scheduled meeting
                'start_time' => '2024-11-07T19:15:00Z',
                'duration' => 30,  // in minutes
                'timezone' => 'Asia/Qatar',
                'agenda' => 'Discuss project updates',

                'settings' => [
                    'approval_type' => 0
                ],
            ];

            try {
                // Create the meeting
                $createMeetingResponse = $zoomService->createMeeting($meetingData);

                // Check if the response contains the meeting ID
                if (isset($createMeetingResponse['response']['id'])) {
                    $meetingIdc = $createMeetingResponse['response']['id'];
                } else {
                }

                // Optionally, log the full response for debugging
            } catch (Exception $e) {
                // Handle any errors during the API call
                echo "Error creating meeting: " . $e->getMessage() . "<br><br><br>" . PHP_EOL;
            }


            // Example 2: Get Meeting Information
            $getMeetingResponse = $zoomService->getMeeting($meetingIdc);

            $response['success'] = true;
            $data = json_encode($getMeetingResponse);
            $response['data'] = $getMeetingResponse;
            $response['message'] = 'Zoom meeting was created successfully.';

            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
