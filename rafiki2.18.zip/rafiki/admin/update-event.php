<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

// Save Client Informations
add_action('rest_api_init', 'rafiki_update_event');
function rafiki_update_event()
{
    register_rest_route(
        'wp/v2',
        'update/event',
        array(
            'methods'  => 'POST',
            'callback' => 'site_update_event',
        )
    );
}
error_log('Before update event function');
function site_update_event($request)
{
    error_log('Inside update event function');
    $user_id = $request["user_id"];
    $post_id = $request["post_id"];
    $status = $request["event_status"];
    $event_title = $request["event_title"];
    $event_description = $request["event_description"];
    $event_start_time = $request["event_start_time"];
    $event_end_time = $request["event_end_time"];
    $is_virtual = $request["event_is_virtual"];
    $meeting_link = $request["event_meeting_link"];
    $event_recurring = $request["event_recurring"];
    $event_repeat_every = $request["event_repeat_every"];
    $event_repeat_on = $request["event_repeat_on"];
    $event_date = $request["event_date"];
    $event_never = $request["event_never"];
    $event_on = $request["event_on"];
    $event_after = $request["event_after"];
    $event_members = $request["event_members"];
    $event_modify_event = $request["event_modify_event"];
    $event_invite_others = $request["event_invite_others"];
    $event_view_member_list = $request["event_view_member_list"];
    $category_slug = $request["event_category_slugs"];
    $event_location = $request["event_location"];
    $event_featured = $request["event_featured"];
    $event_popup = $request["event_popup"];
    $event_questions = $request["event_questions"];


    $event_loc_split = explode(',', $event_location);
    $token = get_bearer_token($request);
    $params = $request->get_params();
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    error_log('Before try catch update event endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('update event endpoints decoded: ' . print_r($data, true));
        // Get State - Start
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {

            $post1_id = $request['post_id'] + 1;

            // Validate post ID
            if (empty($post1_id) || !is_numeric($post1_id)) {
                return new WP_Error('invalid_id', 'Invalid event ID', array('status' => 400));
            }

            $event = get_post($post1_id);
            if (!$event || $event->post_type !== 'event') {
                return new WP_Error('not_found', 'Event not found', array('status' => 404));
            }

            // Update event post
            $updated_post_data = array(
                'ID'           => $post1_id,
                'post_title'   => sanitize_text_field($request['event_title']),
                'post_content' => sanitize_textarea_field($request['event_description']),
                'post_status'  => sanitize_text_field($request['event_status']),
            );

            $updated_post_id = wp_update_post($updated_post_data, true);

            if (is_wp_error($updated_post_id)) {
                return new WP_Error('update_failed', 'Failed to update event.', array('status' => 500));
            }

            // Update event metadata
            update_post_meta($post1_id, 'event_start_time', sanitize_text_field($params['event_start_time']));
            update_post_meta($post1_id, 'event_end_time', sanitize_text_field($params['event_end_time']));
            update_post_meta($post1_id, 'event_is_virtual', sanitize_text_field($params['event_is_virtual']));
            update_post_meta($post1_id, 'event_meeting_link', sanitize_text_field($params['event_meeting_link']));
            update_post_meta($post1_id, 'event_recurring', sanitize_text_field($params['event_recurring']));
            update_post_meta($post1_id, 'event_repeat_every', sanitize_text_field($params['event_repeat_every']));
            update_post_meta($post1_id, 'event_repeat_on', sanitize_text_field($params['event_repeat_on']));
            update_post_meta($post1_id, 'event_date', sanitize_text_field($params['event_date']));
            update_post_meta($post1_id, 'event_never', sanitize_text_field($params['event_never']));
            update_post_meta($post1_id, 'event_on', sanitize_text_field($params['event_on']));
            update_post_meta($post1_id, 'event_after', sanitize_text_field($params['event_after']));
            update_post_meta($post1_id, 'event_members', maybe_serialize($params['event_members']));
            update_post_meta($post1_id, 'event_modify_event', sanitize_text_field($params['event_modify_event']));
            update_post_meta($post1_id, 'event_invite_others', sanitize_text_field($params['event_invite_others']));
            update_post_meta($post1_id, 'event_view_member_list', sanitize_text_field($params['event_view_member_list']));
            update_post_meta($post1_id, 'event_category_slugs', maybe_serialize($params['event_category_slugs']));
            update_post_meta($post1_id, 'event_location', sanitize_text_field($params['event_location']));
            update_post_meta($post1_id, 'event_organizer', sanitize_text_field($params['event_organizer']));
            update_post_meta($post1_id, 'event_image', sanitize_text_field($params['event_image']));
            update_post_meta($post1_id, 'event_featured', rest_sanitize_boolean($params['event_featured']));
            update_post_meta($post1_id, 'event_popup', rest_sanitize_boolean($params['event_popup']));
            update_post_meta($post1_id, 'event_questions', maybe_serialize($params['event_questions']));



            if (get_post_status($post_id)) {
                echo get_post_status($post_id);
                if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $event_date)) {
                    $event_date = $event_date;
                } else {
                    $response['success'] = false;
                    $response['message'] = "Start date format must be year-month-day, example 2012-12-30.";
                    return $response;
                }
                $my_post = array(
                    'ID'           => $post_id,
                    'post_title'   => wp_strip_all_tags($event_title),
                    'post_content' => $event_description,
                    'post_type'     => 'tribe_events',
                    'post_status'   => $status,
                );
                // Update the post into the database
                wp_update_post($my_post);
                if ($category_slug) {
                    update_post_meta($post_id, 'event_category_slugs', $category_slug);
                    $args_tags = array(
                        'taxonomy' => 'tribe_events_cat',
                        'hide_empty' => false,
                    );
                    $category_slugs = get_categories($args_tags);
                    $term_ids = [];
                    foreach ($category_slugs as  $value) {
                        $term_id = $value->term_id;
                        $slug = $value->slug;
                        if (is_array($category_slug)) {
                            $seriliaze_cat = serialize($category_slug);
                            $unseriaze_cat = unserialize($seriliaze_cat);
                            $count_ar = count($unseriaze_cat);
                            for ($i = 0; $i < $count_ar; $i++) {
                                if ($slug == trim($unseriaze_cat[$i], '"')) {
                                    $term_ids[] = $term_id;
                                }
                            }
                        } else {
                            $category_slug_decode = json_decode($category_slug, true);
                            foreach ($category_slug_decode as $key =>  $value_json) {
                                if ($slug == $value_json) {
                                    $term_ids[] = $term_id;
                                }
                            }
                        }
                    }
                    $event_cat = $term_ids;
                    $taxonomy_cat = 'tribe_events_cat';
                    wp_set_post_terms($post_id, $event_cat, $taxonomy_cat);
                }
                if ($event_start_time) {
                    update_post_meta($post_id, '_EventStartDate',  $event_date . ' ' . $event_start_time);
                }
                if ($event_end_time) {
                    update_post_meta($post_id, '_EventEndDate',  $event_date . ' ' . $event_end_time);
                }
                if ($is_virtual == 'Yes') {
                    update_post_meta($post_id, '_tribe_events_virtual_autodetect_source', 'zoom');
                    update_post_meta($post_id, '_tribe_virtual_events_type', 'virtual');
                    update_post_meta($post_id, '_tribe_events_is_virtual', 1);
                    update_post_meta($post_id, '_tribe_events_virtual_url', $meeting_link);
                    update_post_meta($post_id, '_tribe_events_virtual_linked_button_text', 'Join');
                    update_post_meta($post_id, '_tribe_events_virtual_linked_button', 'yes');
                    update_post_meta($post_id, '_tribe_events_virtual_show_embed_at', 'immediately');
                    update_post_meta($post_id, '_tribe_events_virtual_show_on_event', 'yes');
                    update_post_meta($post_id, '_tribe_events_virtual_show_on_views', 'yes');
                    update_post_meta($post_id, '_tribe_events_virtual_rsvp_email_link', 'yes');
                    update_post_meta($post_id, '_tribe_events_virtual_ticket_email_link', 'yes');
                    update_post_meta($post_id, '_EventShowMapLink', 1);
                    update_post_meta($post_id, '_EventShowMap', 1);
                }
                if ($event_recurring == 'true') {
                    update_post_meta($post_id, 'event_recurring', $event_recurring);
                    if (!empty($event_repeat_every)) {
                        update_post_meta($post_id, 'event_repeat_every', $event_repeat_every);
                    }
                    if (!empty($event_repeat_on)) {
                        update_post_meta($post_id, 'event_repeat_on', $event_repeat_on);
                    }
                    if (!empty($event_time)) {
                        update_post_meta($post_id, 'event_time', $event_time);
                    }
                    if ($event_never == 'true') {
                        update_post_meta($post_id, 'event_never', $event_never);
                    }
                    if (!empty($event_on)) {
                        update_post_meta($post_id, 'event_on', $event_on);
                    }
                    if (!empty($event_after)) {
                        update_post_meta($post_id, 'event_after', $event_after);
                    }
                }
                //Members
                if (!empty($event_members)) {
                    if (is_array($event_members)) {
                        update_post_meta($post_id, 'event_members', print_r(serialize($event_members), true));
                    } else {
                        update_post_meta($post_id, 'event_members', serialize(json_decode($event_members)));
                    }
                }
                if (!empty($event_modify_event)) {
                    update_post_meta($post_id, 'event_modify_event', $event_modify_event);
                }
                if (!empty($event_invite_others)) {
                    update_post_meta($post_id, 'event_invite_others', $event_invite_others);
                }
                if (!empty($event_view_member_list)) {
                    update_post_meta($post_id, 'event_view_member_list', $event_view_member_list);
                }
                if (!empty($event_featured)) {
                    update_post_meta($post_id, 'event_featured', $event_featured);
                }
                if (!empty($event_popup)) {
                    update_post_meta($post_id, 'event_popup', $event_popup);
                }
                if (!empty($event_questions)) {
                    update_post_meta($post_id, 'event_questions',  maybe_serialize($params['event_questions']));
                }
                function convertState($name)
                {
                    $states = array(
                        array('name' => 'Alabama', 'abbr' => 'AL'),
                        array('name' => 'Alaska', 'abbr' => 'AK'),
                        array('name' => 'Arizona', 'abbr' => 'AZ'),
                        array('name' => 'Arkansas', 'abbr' => 'AR'),
                        array('name' => 'California', 'abbr' => 'CA'),
                        array('name' => 'Colorado', 'abbr' => 'CO'),
                        array('name' => 'Connecticut', 'abbr' => 'CT'),
                        array('name' => 'District of Columbia', 'abbr' => 'DC'),
                        array('name' => 'Delaware', 'abbr' => 'DE'),
                        array('name' => 'Florida', 'abbr' => 'FL'),
                        array('name' => 'Georgia', 'abbr' => 'GA'),
                        array('name' => 'Hawaii', 'abbr' => 'HI'),
                        array('name' => 'Idaho', 'abbr' => 'ID'),
                        array('name' => 'Illinois', 'abbr' => 'IL'),
                        array('name' => 'Indiana', 'abbr' => 'IN'),
                        array('name' => 'Iowa', 'abbr' => 'IA'),
                        array('name' => 'Kansas', 'abbr' => 'KS'),
                        array('name' => 'Kentucky', 'abbr' => 'KY'),
                        array('name' => 'Louisiana', 'abbr' => 'LA'),
                        array('name' => 'Maine', 'abbr' => 'ME'),
                        array('name' => 'Maryland', 'abbr' => 'MD'),
                        array('name' => 'Massachusetts', 'abbr' => 'MA'),
                        array('name' => 'Michigan', 'abbr' => 'MI'),
                        array('name' => 'Minnesota', 'abbr' => 'MN'),
                        array('name' => 'Mississippi', 'abbr' => 'MS'),
                        array('name' => 'Missouri', 'abbr' => 'MO'),
                        array('name' => 'Montana', 'abbr' => 'MT'),
                        array('name' => 'Nebraska', 'abbr' => 'NE'),
                        array('name' => 'Nevada', 'abbr' => 'NV'),
                        array('name' => 'New Hampshire', 'abbr' => 'NH'),
                        array('name' => 'New Jersey', 'abbr' => 'NJ'),
                        array('name' => 'New Mexico', 'abbr' => 'NM'),
                        array('name' => 'New York', 'abbr' => 'NY'),
                        array('name' => 'North Carolina', 'abbr' => 'NC'),
                        array('name' => 'North Dakota', 'abbr' => 'ND'),
                        array('name' => 'Ohio', 'abbr' => 'OH'),
                        array('name' => 'Oklahoma', 'abbr' => 'OK'),
                        array('name' => 'Oregon', 'abbr' => 'OR'),
                        array('name' => 'Pennsylvania', 'abbr' => 'PA'),
                        array('name' => 'Rhode Island', 'abbr' => 'RI'),
                        array('name' => 'South Carolina', 'abbr' => 'SC'),
                        array('name' => 'South Dakota', 'abbr' => 'SD'),
                        array('name' => 'Tennessee', 'abbr' => 'TN'),
                        array('name' => 'Texas', 'abbr' => 'TX'),
                        array('name' => 'Utah', 'abbr' => 'UT'),
                        array('name' => 'Vermont', 'abbr' => 'VT'),
                        array('name' => 'Virginia', 'abbr' => 'VA'),
                        array('name' => 'Washington', 'abbr' => 'WA'),
                        array('name' => 'West Virginia', 'abbr' => 'WV'),
                        array('name' => 'Wisconsin', 'abbr' => 'WI'),
                        array('name' => 'Wyoming', 'abbr' => 'WY'),
                        array('name' => 'Virgin Islands', 'abbr' => 'V.I.'),
                        array('name' => 'Guam', 'abbr' => 'GU'),
                        array('name' => 'Puerto Rico', 'abbr' => 'PR')
                    );
                    $return = false;
                    $strlen = strlen($name);
                    foreach ($states as $state) :
                        if ($strlen < 2) {
                            return false;
                        } else if ($strlen == 2) {
                            if (strtolower($state['abbr']) == strtolower($name)) {
                                $return = $state['name'];
                                break;
                            }
                        } else {
                            if (strtolower($state['name']) == strtolower($name)) {
                                $return = strtoupper($state['abbr']);
                                break;
                            }
                        }
                    endforeach;
                    return $return;
                }
                $_eventVenueID = get_post_meta($post_id, '_EventVenueID');
                if ($event_location) {
                    $venue_post = array(
                        'ID'           => $_eventVenueID[0],
                        'post_title'    => $event_loc_split[0] . ', ' . $event_loc_split[1],
                        'post_content' => $event_description,
                        'post_type'     => 'tribe_venue',
                        'post_status'   => $status

                    );
                    $_venueProvince = $event_loc_split[2];
                    $_VenueProvince = convertState($_venueProvince);
                    $names = json_decode(file_get_contents("http://country.io/names.json"), true);
                    $country_name = $names[$event_loc_split[4]];
                    update_post_meta($_eventVenueID[0], '_EventShowMapLink', 1);
                    update_post_meta($_eventVenueID[0], '_EventShowMap', 1);
                    update_post_meta($_eventVenueID[0], '_VenueShowMapLink', 1);
                    update_post_meta($_eventVenueID[0], '_VenueShowMap', 1);
                    update_post_meta($_eventVenueID[0], '_VenueAddress', $event_location);
                    update_post_meta($_eventVenueID[0], '_VenueCity', $event_loc_split[1]);
                    update_post_meta($_eventVenueID[0], '_VenueCountry', $country_name);
                    update_post_meta($_eventVenueID[0], '_VenueProvince', $_VenueProvince);
                    update_post_meta($_eventVenueID[0], '_VenueState', $event_loc_split[2]);
                    update_post_meta($_eventVenueID[0], '_VenueZip', $event_loc_split[3]);
                    update_post_meta($_eventVenueID[0], '_VenueEventShowMap', 1);
                    update_post_meta($_eventVenueID[0], '_VenueEventShowMapLink', 1);
                    update_post_meta($_eventVenueID[0], '_VenueStateProvince', $event_loc_split[2]);
                    wp_update_post($venue_post);
                }
                if ($request['event_image']) {
                    $base64_image = $request['event_image'];
                    update_base64_image_in_wp($post_id, $base64_image);
                }
                //venu
                $response['success'] = true;
                $response['message'] = "Event updated successfully.";
                return $response;
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid post id.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

function update_base64_image_in_wp($post_id, $base64_image, $filename = 'event_image') {
    // Get the current attachment ID
    $current_attach_id = get_post_meta($post_id, 'event_image', true);

    // Extract the base64 data
    $filename = $filename . $post_id . '.png';
    $base64_image = preg_replace('#^data:image/[^;]+;base64,#', '', $base64_image);
    $image_data = base64_decode($base64_image);

    if (!$image_data) {
        return new WP_Error('invalid_base64', 'Invalid base64 image data');
    }

    // Get the upload directory
    $upload_dir = wp_upload_dir();
    $file_path = $upload_dir['path'] . '/' . $filename;

    echo $file_path;

    // Save the new image, overwriting the existing file
    file_put_contents($file_path, $image_data);

    // Prepare attachment data
    $file_type = wp_check_filetype($filename, null);
    $attachment = array(
        'ID'             => $current_attach_id,
        'post_mime_type' => $file_type['type'],
        'post_title'     => sanitize_file_name($filename),
        'post_content'   => '',
        'post_status'    => 'inherit',
    );

    // Update the attachment post
    wp_update_post($attachment);

    // Include image metadata and update attachment
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $attach_data = wp_generate_attachment_metadata($current_attach_id, $file_path);
    wp_update_attachment_metadata($current_attach_id, $attach_data);

    return $current_attach_id;
}

