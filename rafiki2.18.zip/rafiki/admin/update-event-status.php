<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

// Save Client Informations
add_action('rest_api_init', 'rafiki_update_event_status');
function rafiki_update_event_status()
{
    register_rest_route(
        'wp/v2',
        'update/event/status',
        array(
            'methods'  => 'POST',
            'callback' => 'site_update_event_status',
        )
    );
}
error_log('Before update status event function');
function site_update_event_status($request)
{
    error_log('Inside update status event function');
    $user_id = $request["user_id"];
    $post_id = $request["post_id"];
    $status = $request["event_status"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    error_log('Before try catch event status update endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('update event status endpoints decoded: ' . print_r($data, true));
        // Get State - Start
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            if (get_post_status($post_id)) {
                $my_post = array(
                    'ID'           => $post_id,
                    'post_type'     => 'tribe_events',
                    'post_status'   => $status,
                );
                $my_post1 = array(
                    'ID'           => $post_id - 1,
                    'post_type'     => 'tribe_venue',
                    'post_status'   => $status,
                );
                $my_post2 = array(
                    'ID'           => $post_id + 1,
                    'post_type'     => 'event',
                    'post_status'   => $status,
                );
                // Update the post into the database
                wp_update_post($my_post);
                wp_update_post($my_post1);
                wp_update_post($my_post2);
                $response['success'] = true;
                $response['message'] = "Event status updated successfully.";
                return $response;
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid post id.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
