<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

error_reporting(E_ALL);

// Autoload Composer dependencies
require __DIR__ . '/../vendor/autoload.php';
error_log('Composer autoload included....');
// Initialize the config first
$config = include __DIR__ . '/../config/config.php';
error_log('Config array loaded......: ' . print_r($config, true));

// Access the values from the config array
$account_id = $config['accountId'];
$client_id = $config['clientId'];
$client_secret = $config['clientSecret'];

// Ensure the config has the necessary values
if (!$account_id || !$client_id || !$client_secret) {
	 error_log('Missing required configuration values......');
    die('Missing required configuration values.');
}

error_log('Account ID: ' . $account_id);
error_log('Client ID: ' . $client_id);
error_log('Client Secret: ' . $client_secret);

use Abdulbaset\ZoomIntegration\ZoomIntegrationService;
error_log('ZoomIntegrationService class loaded');

try {
    $zoomService = new ZoomIntegrationService($account_id, $client_id, $client_secret);
    error_log('ZoomIntegrationService initialized successfully' );
} catch (Exception $e) {
    // Catch and log any errors during initialization
    error_log('Error initializing ZoomIntegrationService: ' . $e->getMessage());
    die('Error initializing ZoomIntegrationService: ' . $e->getMessage());
}


// Convert timezone - Start
function utc_time_zone($date_time, $timezone)
{
    $new_date_time = new DateTime($date_time, new DateTimeZone($timezone));
    $new_date_time->setTimezone(new DateTimeZone("UTC"));
    $date_time_utc = $new_date_time->format("Y-m-d H:i:s");
    return $date_time_utc;
}
function us_time_zone($date_time, $timezone)
{
    $new_date_time = new DateTime($date_time, new DateTimeZone($timezone));
    $new_date_time->setTimezone(new DateTimeZone("America/New_York"));
    $date_time_utc = $new_date_time->format("Y-m-d H:i:s");
    return $date_time_utc;
}

// Convert timezone - End
function isValidTimezoneId($timezoneId)
{
    $zoneList = timezone_identifiers_list(); # list of (all) valid timezones
    return in_array($timezoneId, $zoneList); # set result
}
// Book therapist
add_action('rest_api_init', 'rafiki_site_booking_therapy');

function rafiki_site_booking_therapy()
{
    register_rest_route(
        'wp/v2',
        'therapist',
        array(
            'methods'  => 'POST',
            'callback' => 'site_booking_therapy',
        )
    );
}
error_log('Before add therapy function');
function site_booking_therapy($request)
{
    error_log('Inside add therapy function');
    global $wpdb;
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true);
    $user_id = $request_data["user_id"];	
    $booking_id = $request_data["booking_id"];
    $therapist_id = $request_data["therapist_id"];
    $booking_date = $request_data["booking_date"];
    $booking_time = $request_data["booking_time"];
    $booking_timezone = $request_data["booking_timezone"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch add therapy endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Add therapy endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $check_timez = isValidTimezoneId($booking_timezone);
            $boking_table = $rafiki_prefix . "booking";
            $therapist_table = $rafiki_prefix . "therapist";
            $booking_id_db = $wpdb->get_row("SELECT id FROM $boking_table WHERE user_id = $user_id AND id=$booking_id");
            $therapist_id_db = $wpdb->get_row("SELECT id FROM $therapist_table WHERE id=$therapist_id");
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated . ' UTC';
            $date = DateTime::createFromFormat('Y-m-d', $booking_date);
            if ($date) {
                $final_date = $date->format('Y-m-d');
            } else {
                $response['success'] = false;
                $response['message'] = "booking_date format must be year-month-day, example 2012-12-30.";
                return $response;
            }
            if ($check_timez) {
                $booking_timezone = $booking_timezone;
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid timezone, example timezone America/New_York.";
                return $response;
            }
            if (is_null($therapist_id_db)) {
                $response['success'] = false;
                $response['message'] = "Therapist id not available.";
                return $response;
            } else if (is_null($booking_id_db)) {
                $response['success'] = false;
                $response['message'] = "Booking id not available.";
                return $response;
            } else {
                $dateTime = '' . $final_date . ' ' . $booking_time . '';
                $book_date_time = utc_time_zone($dateTime, $booking_timezone);
                $utc_book_date_time = $book_date_time . ' UTC';
                $wpdb->query("UPDATE $boking_table SET  `therapist_id` = $therapist_id WHERE  user_id = $user_id AND id=$booking_id");
                $wpdb->query("UPDATE $boking_table SET  `status` = 'scheduled' WHERE  user_id = $user_id AND id=$booking_id");
                $wpdb->query("UPDATE $boking_table SET  `booking_datetime` = '$utc_book_date_time' WHERE  user_id = $user_id AND id=$booking_id");
                $wpdb->query("UPDATE $boking_table SET  `type` = 'Therapist' WHERE  user_id = $user_id AND id=$booking_id");
                $wpdb->query("UPDATE $boking_table SET  `updated` = '$utc_updated' WHERE  user_id = $user_id AND id=$booking_id");
                $response['success'] = true;
                $response['message'] = "Booking therapy success.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
// Pending booking
add_action('rest_api_init', 'rafiki_site_pending_therapy');

function rafiki_site_pending_therapy()
{
    register_rest_route(
        'wp/v2',
        'booking/query',
        array(
            'methods'  => 'POST',
            'callback' => 'site_pending_therapy',
        )
    );
}
error_log('Before booking query therapy function');
function site_pending_therapy($request)
{
    error_log('Inside booking query therapy function');
    global $wpdb;
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true);
    $user_id = $request_data["user_id"];
    $full_name = $request_data["full_name"];
    $email = $request_data["email"];
    $message = $request_data["message"];
    $type = $request_data["type"];
    $status = 1;
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch booking query therapy endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Booking query therapy endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name =  $rafiki_prefix . "pending_booking";
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_created = utc_time_zone($current_time, wp_timezone_string());
            $utc_created = $date_time_utc_created . ' UTC';
            $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated . ' UTC';
            $wpdb->insert($table_name, array(
                'user_id' => $user_id,
                'full_name' => $full_name,
                'email' => $email,
                'message' => $message,
                'type' => $type,
                'status' => $status,
                'created' => $utc_created,
                'updated' => $utc_updated,
            ));
            $response['success'] = true;
            $response['message'] = "Booking query sent success.";
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
// Get therapy
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', '/therapist', [
        'methods'  => 'POST',
        'callback' => 'site_get_therapy'
    ]);
});
error_log('Before get therapy function');
function site_get_therapy($request)
{
    error_log('Inside get therapy function');
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true);
    $user_id = $request_data["user_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    error_log('Before try catch get therapy endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Get therapy endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $therapist = '[{
                "therapist_id": "1",
                "therapist_name": "Jane Johnson",
                "gender": "Female",
                "specialisation": "Mental Health,Trauma",
                "timezone":"America/New_York",
                "calendar": {
                    "2022-10-29": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-30": [
                        "10:00am",
                        "11:00am",
                        "1:00pm",
                        "3:00pm"
                    ],
                    "2022-10-31": [
                        "10:00am",
                        "11:00am",
                        "1:00pm",
                        "3:00pm"
                    ]
                }
            }, {
                "therapist_id": "2",
                "therapist_name": "Mark Johnson",
                "gender": "Male",
                "specialisation": "Mental Health,Trauma",
                "timezone":"America/New_York",
                "calendar": {
                    "2022-10-29": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-30": [
                        "10:00am",
                        "11:00am",
                        "1:00pm",
                        "5:00pm"
                    ],
                    "2022-10-31": [
                        "10:00am",
                        "11:00am",
                        "1:00pm",
                        "3:00pm"
                    ]
                }
            },
            {
                "therapist_id": "3",
                "therapist_name": "Alex Moses",
                "gender": "Male",
                "specialisation": "Trauma",
                "timezone":"America/New_York",
                "calendar": {
                    "2022-10-29": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-30": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-31": [
                        "10:00am",
                        "11:00am",
                        "1:00pm",
                        "3:00pm"
                    ]
                }
            }, {
                "therapist_id": "4",
                "therapist_name": "Mary foster",
                "gender": "Female",
                "specialisation": "Mental Health,Trauma",
                "timezone":"America/New_York",
                "calendar": {
                    "2022-10-29": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-30": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-31": [
                        "10:00am",
                        "11:00am",
                        "1:00pm",
                        "3:00pm"
                    ]
                }
            }, {
                "therapist_id": "5",
                "therapist_name": "Michale Morris",
                "gender": "Male",
                "specialisation": "Mental Health,Trauma",
                "timezone":"America/New_York",
                "calendar": {
                    "2022-10-29": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-30": [
                        "10:00am",
                        "11:00am",
                        "1:00pm"
                    ],
                    "2022-10-31": [
                        "10:00am",
                        "11:00am",
                        "1:00pm",
                        "3:00pm"
                    ]
                }
            }
        ]';
            $data = json_decode($therapist, true);
            $response['success'] = true;
            $response['message'] = "Therapist list.";
            $response['data'] = $data;
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Get navigator
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', 'navigator', [
        'methods'  => 'POST',
        'callback' => 'site_get_navigator'
    ]);
});
error_log('Before get navigator function');
function site_get_navigator($request)
{
    error_log('Inside get navigator function');
    
    $request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true);
    $user_id = $request["user_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    try {
        // Decode the JWT token
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Get therapy endpoints decoded: ' . print_r($data, true));
        
        // Get the user ID from the decoded token
        $token_user_id = $data->data->user->id;
        
        if ($user_id == $token_user_id) {
            global $wpdb;

            // Get all therapists from the database
            $therapists = $wpdb->get_results("SELECT id, first_name, last_name FROM `rafiki_backend_therapist`");

            // Prepare the calendar data for each therapist
            $calender_data = [];
            $all_available_slots_by_date = []; // Array to hold merged available slots by date

            foreach ($therapists as $therapist) {
                // Get available time slots from the wp_weekly_availability table for the therapist
                $query = "
                    SELECT `day_of_week`, `start_time`
                    FROM `wp_weekly_availability`
                    WHERE `therapist_id` = %d
                    ORDER BY FIELD(`day_of_week`, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
                ";
                $results = $wpdb->get_results($wpdb->prepare($query, $therapist->id));
                error_log('Query....: ' . $query); // Log the query itself
                error_log('Results for therapist.... ' . $therapist->id . ': ' . print_r($results, true));

                // Prepare available time slots for each day
                $time_slots = [];
                foreach ($results as $row) {
                    $time_slots[strtolower($row->day_of_week)][] = $row->start_time;
                }

                // Fetch the bookings for this therapist
                $booking_query = "
                    SELECT `booking_datetimeUp`
                    FROM `rafiki_backend_booking`
                    WHERE `therapist_id` = %d
                ";
                $bookings = $wpdb->get_results($wpdb->prepare($booking_query, $therapist->id));
                $booked_slots = [];

                foreach ($bookings as $booking) {
                    $booking_date = date('Y-m-d', strtotime($booking->booking_datetimeUp));
                    $booking_time = date('H:i:s', strtotime($booking->booking_datetimeUp));
                    $booked_slots[$booking_date][] = $booking_time;
                }

                // Generate the calendar for the next 30 days
                $period = new DatePeriod(new DateTime("now"), new DateInterval('P1D'), new DateTime('now +30 day'));
                $dates = [];
                foreach ($period as $date) {
                    $dates[] = $date->format("Y-m-d");
                }

                $single_calender_list = [];
                foreach ($dates as $value) {
                    $date_str = strtotime($value);
                    $days_name = date("l", $date_str);
                    $check_date = strtolower($days_name);

                    // Check if there are any booked slots for this date
                    $available_slots = isset($time_slots[$check_date]) ? $time_slots[$check_date] : [];
                    $available_slots = array_diff($available_slots, $booked_slots[$value] ?? []);

                    // Merge the available slots for this date into the all available slots for this day
                    if (!isset($all_available_slots_by_date[$value])) {
                        $all_available_slots_by_date[$value] = [];
                    }
                    $all_available_slots_by_date[$value] = array_merge($all_available_slots_by_date[$value], $available_slots);

                    // Add the available slots for this date
                    $single_calender_list[$value] = $available_slots;
                }

                // Add therapist data and calendar to the response
                $therapist_calendar = [
                    'therapist_id' => $therapist->id,
                    'name' => $therapist->first_name . ' ' . $therapist->last_name,
                    'calendar' => $single_calender_list,
                ];

                // Add the therapist's calendar to the main calendar data
                $calender_data[] = $therapist_calendar;
            }

            // Remove duplicates and sort the available time slots by date
            foreach ($all_available_slots_by_date as $date => $slots) {
                // Remove duplicates for each date
                $all_available_slots_by_date[$date] = array_unique($slots);
                // Sort the available slots for each date
                sort($all_available_slots_by_date[$date]);
            }

            // Return the calendar data for all therapists and merged available slots per date
            $response['success'] = true;
            $response['message'] = "Navigator Calendar for all therapists.";
            $response['data'] = [
                'timezone' => "America/New_York",
                'calendar' => $calender_data,
                'merged_available_slots_by_date' => $all_available_slots_by_date, // Merged time slots for each date
            ];
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}





// function site_get_navigator($request)
// {
//     error_log('Inside get navigator function');
// 	$request_body = file_get_contents('php://input');
//     $request_data = json_decode($request_body, true);
//     $user_id = $request["user_id"];
//     $headers = apache_request_headers();
//     $token = str_replace('Bearer ', '', $headers["authorization"]);
//     $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
//     error_log('Before try catch get navigator endpoints.');
//     try {
//         $data = JWT::decode($token, new Key($secret_key, 'HS256'));
//         error_log('Get therapy endpoints decoded: ' . print_r($data, true));
//         $token_user_id =  $data->data->user->id;
//         if ($user_id == $token_user_id) {
//             $time_slots = array("10:00am", "11:00am", "12:00pm", "1:00pm", "2:00pm", "3:00pm", "4:00pm", "5:00pm", "6:00pm");
//             function array_random($array, $amount = 1)
//             {
//                 $keys = array_rand($array, $amount);
//                 if ($amount == 1) {
//                     return $array[$keys];
//                 }
//                 $results = [];
//                 foreach ($keys as $key) {
//                     $results[] = $array[$key];
//                 }
//                 return $results;
//             }
//             $period = new DatePeriod(new DateTime("now"), new DateInterval('P1D'), new DateTime('now +30 day'));
//             foreach ($period as $date) {
//                 $dates[] = $date->format("Y-m-d");
//             }
//             $calender_list = array();
//             $single_calender_list = array();
//             foreach ($dates as $key => $value) {
//                 $random_time_slots =  array_random($time_slots, 5);
//                 $date_str = strtotime($value);
//                 $days_name = date("l", $date_str);
//                 $check_date = strtolower($days_name);
//                 if (($check_date == "saturday") || ($check_date == "sunday")) {
//                     $single_calender_list[$value] = [];
//                 } else {
//                     $single_calender_list[$value] = $random_time_slots;
//                 }
//             }
//             $calender_list[] = $single_calender_list;
//             $calender_data = array();
//             foreach ($calender_list as $key => $value) {
//                 $calender_data['timezone'] = "America/New_York";
//                 $calender_data['calendar'] = $value;
//             }
//             $response['success'] = true;
//             $response['message'] = "Navigator Calendar.";
//             $response['data'] = $calender_data;
//             return $response;
//         } else {
//             $response['success'] = false;
//             $response['message'] = "User ID is invalid.";
//             return $response;
//         }
//     } catch (SignatureInvalidException $e) {
//         $response['success'] = false;
//         $response['message'] = "Invalid token.";
//         return $response;
//     } catch (ExpiredException $e) {
//         $response['success'] = false;
//         $response['message'] = "Token expired.";
//         return $response;
//     } catch (Exception $e) {
//         if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
//             http_response_code(500);
//             echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
//             exit();
//         } else {
//             http_response_code(500);
//             echo json_encode(['success' => false, 'message' => $e->getMessage()]);
//             exit();
//         }
//     }
// }

// Get recent therapy
add_action('rest_api_init', 'rafiki_site_recent_therapy');

function rafiki_site_recent_therapy()
{
    register_rest_route(
        'wp/v2',
        'therapy/recent',
        array(
            'methods'  => 'POST',
            'callback' => 'site_get_recent_therapy',
        )
    );
}
error_log('Before get recent therapy function');
function site_get_recent_therapy($request)
{
    global $wpdb;
    error_log('Inside get recent therapy function');
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true); 
    $user_id = $request_data["user_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $recent_therapy_limit = defined('RECENT_THERAPY_LIMIT') ? RECENT_THERAPY_LIMIT : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch get recent therapy endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Get recent therapy endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name = $rafiki_prefix . "booking";
            $therapist_table = $rafiki_prefix . "therapist";
            $therapist_id = $wpdb->get_results("SELECT DISTINCT id,therapist_id  FROM $table_name WHERE user_id = $user_id ORDER BY id DESC
            LIMIT $recent_therapy_limit");
            $therapist_book_date = array();
            $therapist_list = array();
            $therapist_ar = array();
            $therapist_ars = array();
            foreach ($therapist_id as $key => $value) {
                $therapist_id = $value->therapist_id;
                $id = $value->id;
                $therapist_list[] = $wpdb->get_results("SELECT id,concat(first_name , ' ',last_name) as therapist_name,phone_number FROM $therapist_table WHERE id=$therapist_id");
                foreach ($therapist_list as $key_1 => $value_1) {
                    foreach ($value_1 as $key_2 => $value_2) {
                        $therapist_book_date =  $wpdb->get_results("SELECT booking_datetime FROM $table_name WHERE user_id=$user_id AND id= $id");
                        $therapist_ar['therapist_id'] = $value_2->id;
                        $therapist_ar['booking_datetime'] = $therapist_book_date[0]->booking_datetime;
                        $therapist_ar['therapist_name'] = $value_2->therapist_name;
                        $therapist_ar['phone_number'] = $value_2->phone_number;
                    }
                }
                $therapist_ars[] = $therapist_ar;
            }
            $response['success'] = true;
            $response['message'] = "Recent therapist list.";
            $response['data'] = $therapist_ars;
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Intake form
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', 'intake-form/intake-form', [
        'methods'  => 'POST',
        'callback' => 'site_intake_form_therapy'
    ]);
});
error_log('Before intake-form therapy function');
function site_intake_form_therapy($request)
{
    error_log('Inside intake-form therapy function');
    global $wpdb;
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true); 
    $user_id = $request_data["user_id"];
    $booking_id = $request_data["booking_id"];
    $first_name = $request_data["first_name"];
    $last_name = $request_data["last_name"];
    $birth_date = $request_data["birth_date"];
    $address = $request_data["address"];
    $city = $request_data["city"];
    $state = $request_data["state"];
    $country = $request_data["country"];
    $zip_code = $request_data["zip_code"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch intake-form therapy endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Intake-form therapy endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name = $rafiki_prefix . "booking_intake_form";
            $date = DateTime::createFromFormat('Y-m-d', $birth_date);
            if ($date) {
                $final_date = $date->format('Y-m-d');
            } else {
                $response['success'] = false;
                $response['message'] = "birth_date format must be year-month-day, example 2012-12-30.";
                return $response;
            }
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_created = utc_time_zone($current_time, wp_timezone_string());
            $utc_created = $date_time_utc_created . ' UTC';
            $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated . ' UTC';
            $wpdb->insert(
                $table_name,
                array(
                    'user_id' => $user_id,
                    'booking_id' => $booking_id,
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'birth_date' => $final_date,
                    'address' => $address,
                    'city' => $city,
                    'state' => $state,
                    'country' => $country,
                    'zip_code' => $zip_code,
                    'created' => $utc_created,
                    'updated' => $utc_updated,
                )
            );
            $response['success'] = true;
            $response['message'] = "Client contact saved successfully.";
            return $response;
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Get Recent client contact
add_action('rest_api_init', 'rafiki_site_last_client_contact');

function rafiki_site_last_client_contact()
{
    register_rest_route(
        'wp/v2',
        'intake-form/recent',
        array(
            'methods'  => 'POST',
            'callback' => 'site_get_last_client_contact',
        )
    );
}
error_log('Before get last client contact function');
function site_get_last_client_contact($request)
{
    error_log('Inside last client contact function');
    global $wpdb;
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true); 
    $user_id = $request_data["user_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch last client contact endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Last client contact endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $table_name = $rafiki_prefix . "booking_intake_form";
            $intake_last_record = $wpdb->get_row("SELECT id,first_name,last_name,birth_date,address,city,state,country,zip_code,created,updated FROM $table_name where user_id=$user_id ORDER BY id DESC limit 1");
            if (is_null($intake_last_record)) {
                $response['success'] = false;
                $response['message'] = "Client contact record not found.";
                return $response;
            } else {
                $response['success'] = true;
                $response['message'] = "Recent intake-form details.";
                $response['data'] = $intake_last_record;
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Booking rescheduled
add_action('rest_api_init', 'rafiki_site_booking_rescheduled');
function rafiki_site_booking_rescheduled()
{
    register_rest_route(
        'wp/v2',
        'booking/reschedule',
        array(
            'methods'  => 'POST',
            'callback' => 'site_booking_rescheduled',
        )
    );
}
error_log('Before booking reschedule function');
function site_booking_rescheduled($request)
{
    error_log('Inside booking reschedule function');
    global $wpdb;
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true); 
    $user_id = $request_data["user_id"];	
    $booking_id = $request_data["booking_id"];
	error_log('------- :' . $booking_id);
    $booking_date = $request_data["booking_date"];
    $booking_time = $request_data["booking_time"];
    $booking_timezone = $request_data["booking_timezone"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch booking reschedule endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Booking reschedule endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated . ' UTC';
            $booking_table = $rafiki_prefix . "booking";
            $check_timez = isValidTimezoneId($booking_timezone);
            $date = DateTime::createFromFormat('Y-m-d', $booking_date);
            if ($date) {
                $final_date = $date->format('Y-m-d');
            } else {
                $response['success'] = false;
                $response['message'] = "booking_date format must be year-month-day, example 2012-12-30.";
                return $response;
            }
            if ($check_timez) {
                $booking_timezone = $booking_timezone;
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid timezone, example timezone America/New_York.";
                return $response;
            }
            $booking_id_db = $wpdb->get_row("SELECT id FROM $booking_table WHERE user_id = $user_id AND id = $booking_id");
            if (!is_null($booking_id_db)) {
                $dateTime = '' . $final_date . ' ' . $booking_time . '';
                $book_date_time = utc_time_zone($dateTime, $booking_timezone);
                $utc_book_date_time = $book_date_time . ' UTC';
                $wpdb->query("UPDATE $booking_table SET `status` = 'Rescheduled' WHERE  user_id = $user_id AND  id=$booking_id");
                $wpdb->query("UPDATE $booking_table SET `booking_datetime` = '$utc_book_date_time' WHERE  user_id = $user_id AND  id=$booking_id");
                $wpdb->query("UPDATE $booking_table SET `updated` = '$utc_updated' WHERE  user_id = $user_id AND  id=$booking_id");
                $response['success'] = true;
                $response['message'] = "Booking rescheduled successfully.";
                return $response;
            } else {
                $response['success'] = false;
                $response['message'] = "Booking id not match.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Update booking status 
add_action('rest_api_init', 'rafiki_site_update_booking_status');
function rafiki_site_update_booking_status()
{
    register_rest_route(
        'wp/v2',
        'booking/cancel',
        array(
            'methods'  => 'POST',
            'callback' => 'site_update_booking_status',
        )
    );
}
error_log('Before booking update status function');
function site_update_booking_status($request)
{
    error_log('Inside booking update status function');
    global $wpdb;
	$request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true); 
    $user_id = $request_data["user_id"];
    $booking_id = $request_data["booking_id"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch booking update status endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Booking booking update status decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated . ' UTC';
            $booking_table = $rafiki_prefix . "booking";
            $booking_id_db = $wpdb->get_row("SELECT id FROM $booking_table WHERE user_id = $user_id AND id = $booking_id");
            if (!is_null($booking_id_db)) {
                $wpdb->query("UPDATE $booking_table SET `status` = 'Cancelled', `updated` = '$utc_updated' WHERE  id = $booking_id");
                $response['success'] = true;
                $response['message'] = "Booking cancelled.";
                return $response;
            } else {
                $response['success'] = false;
                $response['message'] = "Booking id not match.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
// booking navigator
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', 'booking', [
        'methods'  => 'POST',
        'callback' => 'site_booking_navigator'
    ]);
});
error_log('Before booking navigator function');
function site_booking_navigator($request)
{
    error_log('Inside booking navigator function');
    global $wpdb;
    $request_body = file_get_contents('php://input');
    $request_data = json_decode($request_body, true); 
    $user_id = $request_data["user_id"];
    $booking_date = $request_data["booking_date"];
	$booking_time1 = $request_data["booking_time"];
	$booking_time_cleaned = preg_replace('/[^\x20-\x7E]/', '', $booking_time1);

	if (!preg_match('/\d{1,2}:\d{2}/', $booking_time_cleaned)) {
    $response['success'] = false;
    $response['message'] = "Invalid time format. Please use 24-hour format (e.g., 14:30).";
    return $response;
}


	$booking_time = $booking_time_cleaned;
	error_log('----------' . $booking_time);
    $meeting_type = $request_data["meeting_type"];
	$username = $request_data["username"];
	$patient_first_name = $request_data["patient_first_name"];
	$patient_last_name = $request_data["patient_last_name"];
	$user_email = $request_data["email"];
    $gender = $request_data["gender"];
    $type = $request_data["type"];
    $services = $request_data["services"];
    $details = $request_data["details"];
    $booking_timezone = $request_data["booking_timezone"];
	$day_of_week = date('l', strtotime($booking_date));
    $headers = apache_request_headers();
    $token = str_replace('Bearer ', '', $headers["authorization"]);
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch booking navigator endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Booking booking navigator decoded: ' . print_r($data, true));	
        $token_user_id =  $data->data->user->id;		
        if ($user_id == $token_user_id) {	
            $check_timez = isValidTimezoneId($booking_timezone);
            $booking_table =  $rafiki_prefix . "booking";
            $therapist_table =  $rafiki_prefix . "therapist";
            $current_time = date("Y-m-d H:i:s");
            $date_time_utc_created = us_time_zone($current_time, wp_timezone_string());
            $utc_created = $date_time_utc_created;
            $date_time_utc_updated = us_time_zone($current_time, wp_timezone_string());
            $utc_updated = $date_time_utc_updated;
			
            //Insert data - Start
//             $wpdb->insert($therapist_table, array('first_name' => "Dr.Chris", 'last_name' => "", 'phone_number' => "415-555-5553", 'created' => $utc_created, 'updated' =>  $utc_updated,));
//             $wpdb->insert($therapist_table, array('first_name' => "Jane", 'last_name' => "Johnson", 'phone_number' => "415-555-5554", 'created' => $utc_created, 'updated' =>  $utc_updated,));
//             $wpdb->insert($therapist_table, array('first_name' => "Allen", 'last_name' => "Brown", 'phone_number' => "415-555-5555", 'created' => $utc_created, 'updated' =>  $utc_updated,));
//             $wpdb->insert($therapist_table, array('first_name' => "Mike", 'last_name' => "Max", 'phone_number' => "415-555-5556", 'created' => $utc_created, 'updated' =>  $utc_updated,));
//             $wpdb->insert($therapist_table, array('first_name' => "Mille", 'last_name' => "Sullen", 'phone_number' => "415-555-5557", 'created' => $utc_created, 'updated' =>  $utc_updated,));
//             $wpdb->insert($therapist_table, array('first_name' => "Maxi", 'last_name' => "Smith", 'phone_number' => "415-555-5558", 'created' => $utc_created, 'updated' =>  $utc_updated,));
            //Insert data - End
            $date = DateTime::createFromFormat('Y-m-d', $booking_date);			
			
            if ($date) {
                $final_date = $date->format('Y-m-d');	
				$dateTime = '' . $final_date . ' ' . $booking_time . '';	
				error_log('----------' . $booking_time);
				$book_date_time = us_time_zone($dateTime, $booking_timezone);
            } else {
                $response['success'] = false;
                $response['message'] = "booking_date format must be year-month-day, example 2012-12-30.";
                return $response;
            }
            if ($check_timez) {
                $booking_timezone = $booking_timezone;				
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid timezone, example timezone America/New_York.";
                return $response;
            }
	
//             $therapist_id_db = $wpdb->get_row("SELECT id FROM $therapist_table WHERE id = 1");
			 $get_therapist_id_db = $wpdb->get_var("SELECT therapist_id FROM $booking_table ORDER BY id DESC LIMIT 1");

			if ($get_therapist_id_db) {
				$therapist_id = $get_therapist_id_db;
				error_log("Therapist ID: " . $therapist_id);

				// Start by querying for the next therapist after the most recent booking
				$next_row = $wpdb->get_row("SELECT id, email FROM rafiki_backend_therapist WHERE id > $therapist_id ORDER BY id ASC LIMIT 1");
				if (!$next_row) {
					$next_row = $wpdb->get_row("SELECT id, email FROM rafiki_backend_therapist ORDER BY id ASC LIMIT 1");
				}


				$found_therapist = false; // To track if a therapist was found
				$iteration_count = 0; // Counter to track the number of iterations

				// Keep looping through the therapists in a circular fashion until we find an available one or exceed 10 iterations
				while ($next_row && $iteration_count < 6) {
					$next_therapist_id = $next_row->id;
					$host_email = $next_row->email;
					$iteration_count++;
					error_log("........................ " . $iteration_count);

					// Check if the therapist is available
					$availability = $wpdb->get_row(
						$wpdb->prepare(
							"SELECT * FROM wp_weekly_availability WHERE therapist_id = %d AND day_of_week = %s AND start_time = %s",
							$next_therapist_id, $day_of_week, $book_date_time
						)
					);

					if ($availability) {
						// If therapist is available, check if they are already booked at that time
						$booking_check = $wpdb->get_row(
							$wpdb->prepare(
								"SELECT * FROM rafiki_backend_booking WHERE therapist_id = %d AND booking_datetime = %s",
								$next_therapist_id, $book_date_time
							)
						);

						if ($booking_check) {
							// If booked, get the next therapist in the circular sequence
							error_log("Therapist " . $next_therapist_id . " is already booked at......... " . $book_date_time);

							// Get the next therapist in the circular sequence
							$next_row = $wpdb->get_row("SELECT id, email FROM rafiki_backend_therapist WHERE id > $next_therapist_id ORDER BY id ASC LIMIT 1");

							// If there's no next therapist, go back to the first one
							if (!$next_row) {
								$next_row = $wpdb->get_row("SELECT id, email FROM rafiki_backend_therapist ORDER BY id ASC LIMIT 1");
							}
							continue; // Continue to the next therapist in the sequence
						} else {
							// If the therapist is available and not booked, break the loop
							error_log("Therapist " . $next_therapist_id . " is available and not booked at ....... " . $book_date_time);
							$found_therapist = true; // Therapist found
							break; // Exit the loop as we've found an available and unbooked therapist
						}
					} else {
						// If not available, get the next therapist in the circular sequence
						error_log("Therapist " . $next_therapist_id . " is not available at " . $booking_date_time);

						// Get the next therapist in the circular sequence
						$next_row = $wpdb->get_row("SELECT id, email FROM rafiki_backend_therapist WHERE id > $next_therapist_id ORDER BY id ASC LIMIT 1");

						// If there's no next therapist, go back to the first one
						if (!$next_row) {
							$next_row = $wpdb->get_row("SELECT id, email FROM rafiki_backend_therapist ORDER BY id ASC LIMIT 1");
						}
						continue; // Continue to the next therapist in the sequence
					}

					// Increment the iteration counter
					
				}

				// If no therapist is found or exceeded max iterations, handle the case
				if (!$found_therapist) {
					error_log("No available therapists found for the requested time after $iteration_count iterations.");
					// You can return an error message or suggest a new time to the user.
				}
			} else {
				error_log("No therapist_id found for the last inserted booking.");
			}




			
			
			

            if ($meeting_type != 'Video' && $meeting_type != 'Audio' && $meeting_type != 'Personal') {
                $response['success'] = false;
                $response['message'] = "Meeting_type must be either Video/Audio/Personal.";				
                return $response;
            } else if ($type != 'Navigator' && $type != 'CAM') {
                $response['success'] = false;
                $response['message'] = "type must be either Navigator/CAM.";	
                return $response;
            } 
			else {			
                
				$book_date_time2 = new DateTime($dateTime, new DateTimeZone($booking_timezone));
				$book_date_time2->setTimezone(new DateTimeZone('America/New_York'));
				$formatted_date_time_Zoom = $book_date_time2->format('Y-m-d\TH:i:s');
                $utc_book_date_time = $book_date_time;
				error_log('----------' . $utc_book_date_time);
				
				$meeting_details = null;
				$config = include __DIR__ . '/../config/config.php';
				$account_id = $config['accountId'];
				$client_id = $config['clientId'];
				$client_secret = $config['clientSecret'];
				error_log('AccountID........:' . (isset($account_id) ? $account_id : 'Not Set'));
				if ($meeting_type == 'Video') {
					try {

						$zoomService = new ZoomIntegrationService($account_id, $client_id, $client_secret);
						$meetingData = [
							'topic' => 'Rafiki-Therapy',
							'type' => 2, 
							'start_time' => $formatted_date_time_Zoom,
							'duration' => 30,  
							'timezone' => 'America/New_York',
							'agenda' => 'Discuss project updates',
							'settings' => [
								'approval_type' => 0,
								'alternative_hosts' => $host_email
							],
						];

						$createMeetingResponse = $zoomService->createMeeting($meetingData);
						$meeting_details = $createMeetingResponse['response']['id'] ?? null;
						$meetingId = $createMeetingResponse['response']['id'];
						$registrantData = [
							'email' => $user_email,
							'first_name' => $patient_first_name,
							'last_name' => $patient_last_name,
						];
						$addRegistrantResponse = $zoomService->addMeetingRegistrant($meetingId, $registrantData);
					} catch (Exception $zoomError) {
						error_log("Zoom meeting creation error: " . $zoomError->getMessage());
					}
				}
				
                $wpdb->insert(
                    $booking_table,
                    array(
                        'user_id' => $user_id,
                        'status' => "Scheduled",
                        'therapist_id' => $next_therapist_id,
                        'full_name' => $username,
                        'gender' => $gender,
                        'meeting_type' => $meeting_type,
                        'booking_datetime' => $utc_book_date_time,
						'booking_datetimeUp' => $utc_book_date_time,
                        'type' => $type,
                        'services' => $services,
                        'details' => $details,
                        'created' =>  $utc_created,
                        'updated' =>  $utc_updated,
                    )
                );
                $get_booking_id_db = $wpdb->get_row("SELECT id FROM $booking_table WHERE id =(SELECT LAST_INSERT_ID())");
                foreach ($get_booking_id_db as $key => $value) {
                    $booking_id['booking_id']  = $value;
                }

                $response['success'] = true;
                $response['message'] = "Booking navigator success. Therapist found: " . ($found_therapist ? 'Yes' : 'No') . "|. next Therapist ID: " . $next_therapist_id . "|. Therapist ID: " . $therapist_id;;
                $response['data'] = $booking_id;
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {		
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}