<?php
//Add booking table
function booking_tb()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    $table_name = $rafiki_prefix . 'booking';
    $sql = "CREATE TABLE $table_name (
    id INTEGER NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    status TEXT NOT NULL,
    therapist_id bigint(20) UNSIGNED NULL,
    full_name TEXT NOT NULL,
    gender TEXT NOT NULL,
    meeting_type TEXT NOT NULL,
    booking_datetime TEXT NOT NULL,
    type TEXT NOT NULL,
    services TEXT NOT NULL,
    details LONGTEXT NOT NULL,
    created TEXT NOT NULL,
    updated TEXT NOT NULL,
    PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
}
add_action('init', 'booking_tb');

//Add Pending booking table
function pending_booking_tb()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    $table_name = $rafiki_prefix . 'pending_booking';
    $sql = "CREATE TABLE $table_name (
    id INTEGER NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    message LONGTEXT NOT NULL,
    type TEXT NOT NULL,
    status tinyint NULL,
    created TEXT NOT NULL,
    updated TEXT NOT NULL,
    PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
}
add_action('init', 'pending_booking_tb');

//Intake-form table
function intake_booking_form_tb()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    $table_name = $rafiki_prefix . 'booking_intake_form';
    $sql = "CREATE TABLE $table_name (
    id INTEGER NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    booking_id bigint(20) UNSIGNED NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    birth_date DATE NOT NULL,
    address TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    country TEXT NOT NULL,
    zip_code TEXT NOT NULL,
    created TEXT NOT NULL,
    updated TEXT NOT NULL,
    PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
}
add_action('init', 'intake_booking_form_tb');

//Therapist table
function therapist_tb()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    $table_name = $rafiki_prefix . 'therapist';
    $sql = "CREATE TABLE $table_name (
    id INTEGER NOT NULL AUTO_INCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    created TEXT NOT NULL,
    updated TEXT NOT NULL,
    PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
}
add_action('init', 'therapist_tb');
