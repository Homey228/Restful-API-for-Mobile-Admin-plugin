<?php
/*
Plugin Name: Custom RESTful API for Mobile App
Description: Provides custom REST API endpoints for user management and resources.
Version: 1.0
Author: Rolesh
*/

// Ensure the plugin is not directly accessed
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define('RAFIKI_PREFIX', 'rafiki_backend_'); // 
define('JWT_AUTH_SECRET_KEY', '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCyFY6ReJDDL3Fc\nTowWU9dcsZcUcI/5tBWsJOLIiIbeHiy+VKIkrspqh6AT6oZvVeSbnizgvYjvOCVd\nE5052iSSv5/VcFAmObsym9b94DGgmZVMD9qW/mgnHhKJBCa8kIlzxmeS/RNiIJ4X\nwLR509aq5pFJa/yUuNm1ae5ED68yfOhZ1pW5a8CCGXOi8fChzFZ7R9XMStW3rwYy\nX+L6/JZcsDmIi0A78Z5t1ieZUtzpisYBAGpoBqr5iE6bzK++vkHNVJ12eLl0SoVv\nFVaJ97j0IGm/PTyWzwsGCBd9OtZqqhAlLSm2/v9AxkNK7qqTMY/ug+RsFsHIaFWd\nxmc5DqgxAgMBAAECggEAAP9iKrIzVGaVAtx9SCg80/v6Mc7+HXra5rmXrCIoqECg\nxUmt1VkF0QI0vTvSeDfx1YXVsEYbiOSGgA6asj7kts48P9q21jn7UJmjIw2xFXpa\nxd/uXGttK6/tUGdtrJ9+J6AAR0hj5ggy/oTRtf9/67nqLTA9zFr7PDsNTsQMOhMK\n6OAcdYPlgnDIo+qiTlrOLJRoWygMMKORU1V66AnKsSXuFLrvtfLiKAUKfIxxd/76\n4UmU5S2oDJgvASpL2r/iMqjDsk0X9ts1DxeoHL77CKuBDvGG7tEFugtaEWQoHoAH\nhNeSwjmYTCxK2892IM7xb2dwwUGndW5FXYYKtkG7SQKBgQDdRpv7EftRdRMyw1rB\nfOmgLvOpM7OGOCFfh5m7pzz5vcMk0AKLlW8LiRAhhp/kM14cYVvZGe7P//WZJ62C\nqyr+ZuV311Nxs3LyKMP/49O/SsEy5o1ItxkpIDp+srrK+Q47HMOqm2/blhFPpvkg\ndYAoaID5KKfLlqccq07GH3oS2QKBgQDOB8vCkvghahXMoa/1MCOhBe48w4r0BUHX\n5WV+6ffCUUPpHUiB066xS1CcG0pGl1qvMJ94zhnJ4+GcMcEzJV1uxyAEBJOIHXb4\nQ0p7744IX93KidTovSM+KFdpYPZn5wB+OGADNts3s7WKMBHSy/iI1uYhmnx/Ecej\n9AOJiCS5GQKBgQC65df78g0/mU6U8vKmOVavqNjAEt5QwPpXURalrLVREFpSrqtn\nsNlxedy5JJfKzSRxfj5xGnlfEIgmS6A/nUocRVcOqT5e7D5rkckzSwDgM0kKMDgn\nshe7Z/BgcaBarpC5lysh4FZTt+Z5S8RjCTwtZU+CpDdOO7p8+aj4qT+XyQKBgAZK\nZKVHOX5Dr/C0ixvQYXYcKT7/tXFn66+82FF8sUzkkE9AzqLwJKhTJV3u02C+ZE1v\nDZ9xo4XviEbtmfmGzYiBWe/ld9+zDpvb6h1IniyRSMNTXAXTKI1QTALyq/NWMUSp\nUf0nIqBbw1I5z4GBKtB6x0IFZoG2uELAQ49iccSZAoGBANMYPqBu68vnYIIO5h3g\nSBNBPcqx6DF2o9LAT52Rmodp9bdaX3Cw3Mdyatv8Vk5NYOPm539IqvnNPzd48NXB\n4ntZlpJ67FOmNoR7jz0yKJNUM/nvLmBHpjgncGtj4xBH15fj/zYtJ9qbmu+P9a4R\nvVUoJ+3bql3FydRKCtmtRVMw\n-----END PRIVATE KEY-----\n'); // 
define('FCM_SERVER_KEY', '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCjaLIfS+WzAavN\njlp7vCADUVIASXjq4YKLA7yCjeUB1UC8bZwg3XrN4y+wTInoCG2wMw3GUkCB8ak0\nIfUChqfKMqIXHRAGBnhNn3YB43Wv99t/XnGjt5Yuc/GM1ZBmLgNc8FbK/aVKkgXG\njQpHHcnRJ18UFTs8Ou63meTz7DfyjmkmVoG4fZyMSEcY8kHGmhCq3uB0quaiKLrA\nOWsky7F6+yhaOPFknMJnbKpNP3jarozrAhSdIfEz4V8JQIJDNVKCUFoA1u+OB7Tx\nyEV8mEuOKV5to0gT5kg84SCMk6/NhbFrrD32QUFZNwWV4HHv6Uuu5cHBFmfqmQho\nyS1mlrDHAgMBAAECggEASGr5pY0JOw+eh/ZyeyugNFgxsxbck5tlMx5wyJsBxpIv\nolIhQx9kcSIh3EvPQhmaIuA9VorVM8FZb1UtM/VhHubZlsy2cTUk06G7tpKLcXSy\nvfuo+Rk/YU7Y2cU7vUzfCK0qicNnIWkdTiTrTSESc7KzHD9chRDJAm0dXkxtbvyg\nQdPF71UFeSTx2kAT1mRcpdHxHnZ033lZRfSYa3DCYGmUFZsColMWIbBSGgkEcFvj\nQl20MM0KiJpIwCG5Cpry6oE3SOrKA9GPnyMXfgzQPxYxWZABpceUBIC3CoSb1i3A\n82ubNckxWZi+tgclJYWuyo861yTVPawWHWqc5t8pwQKBgQDa0iyUBrABmtoZX8Q5\njEKwVdGprWwPBrwiUsbAo5pFLe2tk5OTrwmJAjrEcpVNH59rEYy598xKp+w29u7T\nUkZWwJ34f5M1Cm5E+WGHz6FQudf9AwMkcYto1wD5Zn1dfMssWoj8Fp+lZ3XwnGnJ\nsvhXUiV5vMhlmX04Tqs+xi/NbwKBgQC/LFLCDfBBcS4OI+upDEJEEn/F2NemuV95\nKSyW+NgsBHWNrkqc4LbdZ0DiRb9fpuOp9M8qf4dDSMA5XINQjj/rdIS1HYo3Z/Yz\n/gS9LAcbcV2cXj0KBaChT1cLBUQie4QyWBHRNzSsUG+Htgk6KQgLhh/0wSSvQ84b\n0gumDgzWKQKBgFi4lrJ986by7jMTjS/4GqH8acHuOr3s8SLJhSReMRKTiKa0C0X5\n1lfiu4kjHD3k8HIs724HdqFebHvsqvCrjzFlb6dtsnXzALqekljKapGciGJhcki4\ncNnVMuPsFjBthMM7AgeT9K7PwBYKlSnekqp0+BTf4jCvhwHpg600FfWpAoGBAJtm\nEyutGuSHdPGHn3O+BEvDYdvYpYvgWcxqfNWIGGjHgysVR494Vw1odmS4X5UIWz33\nQ0N/gNtf0umN2yxrRWhHQezbw1PAjXC8BuwjUu+q2nZWYHW6F1Wo4c+Si00gbFhk\nIK+ZmZaMl+yQO7XsTp7XeziAnCpgCrWwq0ljWGnpAoGAfu8MlcoUrkqT/KRPaDaf\nnWWeSvXsESGdUqZvpDMyUd53w6SHyiyUs5P/J/7xNRAkbalWlcrVTH/E/1HeTAJT\n+03KaCDFxleqLsggzZlE83JJYs5KfW3raYn5mnssgoTbwbOJQ0HLJ+PjExuu3INT\nya/8hN+t+DYr4GLqmE487d0=\n-----END PRIVATE KEY-----\n'); // 

// Include other files
include_once plugin_dir_path(__FILE__) . 'events/events-table.php';
include_once plugin_dir_path(__FILE__) . 'therapy/therapy-table.php';
include_once plugin_dir_path(__FILE__) . 'client/client-table.php';


// Global Rest API
include(plugin_dir_path(__FILE__) . 'vendor/autoload.php');
include(plugin_dir_path(__FILE__) . 'base-path.php');
include(plugin_dir_path(__FILE__) . 'users.php');
include(plugin_dir_path(__FILE__) . 'resources.php');
include(plugin_dir_path(__FILE__) . 'faq.php');
include(plugin_dir_path(__FILE__) . 'pre-signup.php');
include(plugin_dir_path(__FILE__) . 'help.php');

// Add additional functionality as needed

// Admin Events Rest API
include(plugin_dir_path(__FILE__) . 'admin/events.php');
include(plugin_dir_path(__FILE__) . 'admin/create-event.php');
include(plugin_dir_path(__FILE__) . 'admin/update-event-status.php');
include(plugin_dir_path(__FILE__) . 'admin/update-event.php');
include(plugin_dir_path(__FILE__) . 'admin/get-event.php');
include(plugin_dir_path(__FILE__) . 'admin/booking-zoom-meeting.php');


// Client Events Rest API
include(plugin_dir_path(__FILE__) . 'events/events.php');
include(plugin_dir_path(__FILE__) . 'events/events-detail.php');
include(plugin_dir_path(__FILE__) . 'events/events-status.php');
include(plugin_dir_path(__FILE__) . 'events/user-events.php');

// Client Dashboard Rest API
include(plugin_dir_path(__FILE__) . 'dashboard/account-settings.php');
include(plugin_dir_path(__FILE__) . 'dashboard/account.php');
include(plugin_dir_path(__FILE__) . 'dashboard/discover-activities.php');
include(plugin_dir_path(__FILE__) . 'dashboard/event.php');
include(plugin_dir_path(__FILE__) . 'dashboard/home.php');
include(plugin_dir_path(__FILE__) . 'dashboard/search.php');

// Profile Rest API
include(plugin_dir_path(__FILE__) . 'profile/change-profile-picture.php');
include(plugin_dir_path(__FILE__) . 'profile/profile.php');

// Client Rest API
include(plugin_dir_path(__FILE__) . 'client/client.php');

// Therapy Rest API
include(plugin_dir_path(__FILE__) . 'therapy/therapy.php');

//Notification Rest API
include(plugin_dir_path(__FILE__) . 'notification/register-post-type.php');
include(plugin_dir_path(__FILE__) . 'notification/create-notification.php');
include(plugin_dir_path(__FILE__) . 'notification/notifications.php');

include(plugin_dir_path(__FILE__) . 'notification/update-notification.php');

//Meeting example
// include(plugin_dir_path(__FILE__) . 'examples/MeetingExamples.php');

//notification push to apps

include(plugin_dir_path(__FILE__) . 'fcm_notification/create-fcm-table.php');
include(plugin_dir_path(__FILE__) . 'fcm_notification/detect-notification.php');
include(plugin_dir_path(__FILE__) . 'fcm_notification/register-fcm-token.php');

