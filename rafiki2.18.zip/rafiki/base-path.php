<?php
// Change Base Path
add_filter('rest_url_prefix', 'rafiq_api_slug');
function rafiq_api_slug($slug)
{
    return 'api';
}

// Remove API json
function my_site_rest_index($response)
{
    return array();
}
add_filter('rest_index', 'my_site_rest_index');
