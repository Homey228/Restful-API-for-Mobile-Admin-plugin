<?php

//Get help data
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', 'help', [
        'methods'  => 'POST',
        'callback' => 'site_help'
    ]);
});
function site_help($request)
{

    $help = '{
        "Book a consultation with a Navigator": ["Our dedicated care managers will get to know you and guide you to the best possible resources for your needs."],
        "Complete your intake form": ["You may complete the intake form in-app or during your session with the navigator. "],
        "Receive approval to services": ["Once you completes steps 1 and 2, you may be eligible to begin booking services. Please be advised there could be a waitlist."]
    }';
    $help_data = json_decode($help, true);
    $response['success'] = true;
    $response['message'] = "Help list.";
    $response['data'] = $help_data;
    return $response;
}
