<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

// Add/Update event status 
add_action('rest_api_init', 'rafiki_site_add_update_event_status');
function rafiki_site_add_update_event_status()
{
    register_rest_route(
        'wp/v2',
        'user/event/status',
        array(
            'methods'  => 'POST',
            'callback' => 'site_add_update_event_status',
        )
    );
}
error_log('Before event add/update status function');
function site_add_update_event_status($request)
{
    error_log('Inside event add/update status function');
    global $wpdb;
    $user_id = $request["user_id"];
    $event_id = $request["event_id"];
    $status = $request["status"];
    $headers = apache_request_headers();
    $token = str_replace('Bearer ', '', $headers["Authorization"]);
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    error_log('Before try catch event add/update status endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Event add/update status decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $order_event_id_ar = array($event_id);
            $check_event_ar = get_posts([
                'include' => $order_event_id_ar,
                'post_type' => 'tribe_events',
            ]);
            if ($check_event_ar) {
                if ($status != 'Going' && $status != 'Maybe' && $status != 'Not Going') {
                    $response['success'] = false;
                    $response['message'] = __("Status must be either Going/Maybe/Not Going.");
                    return $response;
                } else {
                    $current_time = date("Y-m-d H:i:s");
                    $date_time_utc_created = utc_time_zone($current_time, wp_timezone_string());
                    $utc_created = $date_time_utc_created . ' UTC';
                    $date_time_utc_updated = utc_time_zone($current_time, wp_timezone_string());
                    $utc_updated = $date_time_utc_updated . ' UTC';
                    $status_table = $rafiki_prefix . "events_user_status";
                    $status_id_db = $wpdb->get_row("SELECT id FROM $status_table WHERE user_id = $user_id AND event_id = $event_id");
                    if (!is_null($status_id_db)) {
                        $wpdb->query("UPDATE $status_table SET `status` = '$status', `updated` = '$utc_updated' WHERE  user_id = $user_id AND event_id = $event_id");
                        $status_going = $wpdb->get_results("SELECT * FROM $status_table WHERE  event_id = $event_id AND status='Going'");
                        $status_not_going = $wpdb->get_results("SELECT * FROM $status_table WHERE  event_id = $event_id AND status='Not Going'");
                        $status_maybe = $wpdb->get_results("SELECT * FROM $status_table WHERE  event_id = $event_id AND status='Maybe'");
                        $going = count($status_going);
                        $may_be = count($status_maybe);
                        $not_going = count($status_not_going);
                        $status_data = array(
                            "going" => $going,
                            "may_be" => $may_be,
                            "not_going" => $not_going,
                        );
                        $response['success'] = true;
                        $response['message'] = "Event status updated.";
                        $response['data'] =  $status_data;
                        return $response;
                    } else {
                        $wpdb->insert(
                            $status_table,
                            array(
                                'user_id' => $user_id,
                                'event_id' => $event_id,
                                'status' => $status,
                                'created' =>  $utc_created,
                                'updated' =>  $utc_updated,
                            )
                        );
                        $response['success'] = true;
                        $response['message'] = "Event status save successfully.";
                        return $response;
                    }
                }
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid event id.";
                return $response;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
