<?php
//Add events_user_status table
function events_status_tb()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    //* Create the teams table
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    $table_name = $rafiki_prefix . 'events_user_status';
    $sql = "CREATE TABLE $table_name (
    id INTEGER NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    event_id bigint(20) UNSIGNED NULL,
    status TEXT NOT NULL,
    created TEXT NOT NULL,
    updated TEXT NOT NULL,
    PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
}
add_action('init', 'events_status_tb');
