<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

//Get data for user Events
add_action('rest_api_init', 'rafiki_rafiki_site_user_events');

function rafiki_rafiki_site_user_events()
{
    register_rest_route(
        'wp/v2',
        'user/events',
        array(
            'methods'  => 'POST',
            'callback' => 'rafiki_user_events',
        )
    );
}
error_log('Before user events function');
function rafiki_user_events($request)
{
    error_log('Inside user events function');
    $user_id = $request["user_id"];
    $keyword = $request["keyword"];
    $tags = $request["tags"];
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $event_list_limit = defined('EVENT_LIST_LIMIT') ? EVENT_LIST_LIMIT : false;
    error_log('Before try catch user events endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('User events endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            // Fetch data - start
            $user_obj = get_user_by('id', $user_id);
            $user_name = $user_obj->user_login;
            $term_id_db = get_user_meta($user_id,  'question_1');
            $term_id_array_db = '';
            foreach ($term_id_db as $value) {
                $term_id_array_db = $value;
            }
            $term_array_db = explode(",", $term_id_array_db);
            $tags_array = explode(",", $tags);
            $currentDate = date('Y-m-d H:i:s');
            $args = array();
            if (empty($keyword)) {
                if ($tags) {
                    $args = array(
                        'search_tax_query' => true,
                        's' => $keyword,
                        'post_type' => 'tribe_events',
                        'numberposts' => $event_list_limit,
                        'orderby'       =>  '_EventStartDate',
                        'order'         =>  'ASC',
                        'meta_query' => array(
                            array(
                                'key' => '_EventStartDate',
                                'value' => $currentDate,
                                'compare' => '>',
                            )
                        ),
                        'tax_query' => array(
                            'relation' => 'AND',
                            array(
                                'taxonomy' => 'tribe_events_cat',
                                'field'    => 'slug',
                                'terms'    =>  $term_array_db,

                            ),
                            array(
                                'taxonomy' => 'post_tag',
                                'field'    => 'slug',
                                'terms'    =>  $tags_array,
                            ),
                        ),
                    );
                } else {
                    $args = array(
                        'post_type' => 'tribe_events',
                        'numberposts' => $event_list_limit,
                        'orderby'       =>  '_EventStartDate',
                        'order'         =>  'ASC',
                        'meta_query' => array(
                            array(
                                'key' => '_EventStartDate',
                                'value' => $currentDate,
                                'compare' => '>',
                            )
                        ),
                        'tax_query' => array(
                            'relation' => 'AND',
                            array(
                                'taxonomy' => 'tribe_events_cat',
                                'field'    => 'slug',
                                'terms'    =>  $term_array_db,

                            ),
                        ),
                    );
                }
            } else {
                $args = array(
                    'search_tax_query' => true,
                    's' => $keyword,
                    'post_type' => 'tribe_events',
                    'numberposts' => $event_list_limit,
                    'orderby'       =>  '_EventStartDate',
                    'order'         =>  'ASC',
                    'meta_query' => array(
                        array(
                            'key' => '_EventStartDate',
                            'value' => $currentDate,
                            'compare' => '>',
                        )
                    ),
                    'tax_query' => array(
                        'relation' => 'AND',
                        array(
                            'taxonomy' => 'tribe_events_cat',
                            'field'    => 'slug',
                            'terms'    =>  $term_array_db,

                        ),
                        array(
                            'taxonomy' => 'post_tag',
                            'field'    => 'slug',
                            'terms'    =>  $tags_array,
                        ),
                    ),
                );
            }
            $current_user_posts = get_posts($args);
            $user_type_events = array();
            $user_type_events_single = array();
            $user_type_events_ar = array();
            $event_venu_id = array();
            $venu_zip_id_ar = array();
            $venu_zip_id_single_ar = array();
            $venu_zip = '';
            $event_start = '';
            $event_end = '';
            $_venueAddress = '';
            $_venueCity = '';
            $_venueCountry = '';
            $_venueProvince = '';
            foreach ($current_user_posts as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    if ($skey == 'ID') {
                        $categories_list = get_the_terms($svalue, 'tribe_events_cat');
                        $cat_ar_list = [];
                        foreach ($categories_list  as $cat_value) {
                            $cat_ar_list[] = $cat_value->name;
                        }
                        $cat_list = implode(", ", $cat_ar_list);
                        $event_start = get_post_meta($svalue,  '_EventStartDate');
                        $event_start = array(date('Y-m-d h:i:s', strtotime($event_start[0])));
                        $event_end = get_post_meta($svalue,  '_EventEndDate');
                        $event_end = array(date('Y-m-d h:i:s', strtotime($event_end[0])));
                        $event_time_zone = get_post_meta($svalue,  '_EventTimezone');
                        $event_venu_id = get_post_meta($svalue,  '_EventVenueID');
                        $venu_zip = get_post_meta(implode($event_venu_id),  '_VenueZip');
                        $_venueAddress = get_post_meta(implode($event_venu_id),  '_VenueAddress');
                        $_venueCity = get_post_meta(implode($event_venu_id),  '_VenueCity');
                        $_venueCountry = get_post_meta(implode($event_venu_id),  '_VenueCountry');
                        $_venueProvince = get_post_meta(implode($event_venu_id),  '_VenueProvince');
                        $_tribe_virtual_events_type = get_post_meta($svalue,  '_tribe_virtual_events_type');
                        $venu_zip_id_single_ar[$svalue] = $venu_zip;
                    }
                    unset($user_type_events_single['post_excerpt']);
                    unset($user_type_events_single['post_status']);
                    unset($user_type_events_single['comment_status']);
                    unset($user_type_events_single['ping_status']);
                    unset($user_type_events_single['post_password']);
                    unset($user_type_events_single['post_name']);
                    unset($user_type_events_single['to_ping']);
                    unset($user_type_events_single['pinged']);
                    unset($user_type_events_single['post_content_filtered']);
                    unset($user_type_events_single['post_parent']);
                    unset($user_type_events_single['guid']);
                    unset($user_type_events_single['menu_order']);
                    unset($user_type_events_single['post_mime_type']);
                    unset($user_type_events_single['comment_count']);
                    unset($user_type_events_single['filter']);
                    $venu_zip_id_ar[] = $venu_zip_id_single_ar;
                    $user_type_events_ar['categories'] = $cat_list;
                    $user_type_events_ar['_EventStartDate'] = $event_start;
                    $user_type_events_ar['_EventEndDate'] = $event_end;
                    $user_type_events_ar['_EventTimezone'] = $event_time_zone;
                    $user_type_events_ar['_VenueAddress'] = $_venueAddress;
                    $user_type_events_ar['_VenueCity'] = $_venueCity;
                    $user_type_events_ar['_VenueProvince'] = $_venueProvince;
                    $user_type_events_ar['_VenueCountry'] = $_venueCountry;
                    $user_type_events_ar['_VenueZip'] = $venu_zip;
                    if ($_tribe_virtual_events_type) {
                        $user_type_events_ar['_tribe_virtual_events_type'] = $_tribe_virtual_events_type;
                    } else {
                        $user_type_events_ar['_tribe_virtual_events_type'] = array();
                    }
                    $user_type_events_single[$skey] = $svalue;
                }

                $user_type_events[] = array_merge($user_type_events_single, $user_type_events_ar);
            }
            $data_list = array(
                "event_list" => $user_type_events,
            );
            $total_event_list = array();
            foreach ($data_list as $key => $value) {
                foreach ($value as $skey => $svalue) {
                    $total_event_list[$skey] = $svalue;
                }
            }
            $response['success'] = true;
            $response['message'] = __("User event list.");
            $response['data'] = $total_event_list;
            return $response;
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token || str_contains($headers["authorization"], 'Bearer') || !str_contains($headers["authorization"], 'Bearer')) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
