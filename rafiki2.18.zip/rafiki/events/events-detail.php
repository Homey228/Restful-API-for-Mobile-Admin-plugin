<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

//Get data for single event
add_action('rest_api_init', 'rafiki_single_event_detail');

function rafiki_single_event_detail()
{
    register_rest_route(
        'wp/v2',
        'event/view',
        array(
            'methods'  => 'POST',
            'callback' => 'single_event_detail',
        )
    );
}

error_log('Before single event function');
function single_event_detail($request)
{
    error_log('Inside single event function');
    global $wpdb;
    $user_id = $request["user_id"];
    $event_id = $request["id"];
    $rafiki_prefix = defined('RAFIKI_PREFIX') ? RAFIKI_PREFIX : false;
    $token = get_bearer_token($request);
    
    if (is_wp_error($token)) {
        return $token;
    }
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $google_api_key = defined('GOOGLE_MAP_API_KEY') ? GOOGLE_MAP_API_KEY : false;
    error_log('Before try catch single event endpoints.');
    try {
        $data = JWT::decode($token, new Key($secret_key, 'HS256'));
        error_log('Single event endpoints decoded: ' . print_r($data, true));
        $token_user_id =  $data->data->user->id;
        if ($user_id == $token_user_id) {
            $status_table = $rafiki_prefix . "events_user_status";
            $status_going = $wpdb->get_results("SELECT * FROM $status_table WHERE  event_id = $event_id AND status='Going'");
            $status_not_going = $wpdb->get_results("SELECT * FROM $status_table WHERE  event_id = $event_id AND status='Not Going'");
            $status_maybe = $wpdb->get_results("SELECT * FROM $status_table WHERE  event_id = $event_id AND status='Maybe'");
            $going = count($status_going);
            $not_going = count($status_not_going);
            $may_be = count($status_maybe);
            $user_status = $wpdb->get_results("SELECT status FROM $status_table WHERE user_id=$user_id AND event_id = $event_id");
            $user_event = '';
            foreach ($user_status as $key => $value) {
                foreach ($value as $sub_key => $sub_value) {
                    $user_event = $sub_value;
                }
            }
            // Fetch data - start
            $order_event_id_ar = array($event_id);
            $currentDate = date('Y-m-d H:i:s');
            $args = array(
                'include' => $order_event_id_ar,
                'post_type' => 'tribe_events',
                'orderby'       =>  '_EventStartDate',
                'order'         =>  'ASC',
                'meta_query' => array(
                    array(
                        'key' => '_EventStartDate',
                        'value' => $currentDate,
                        'compare' => '>',
                    )
                ),
            );
            $single_event_ar = get_posts($args);
            $check_event_ar = get_posts([
                'include' => $order_event_id_ar,
                'post_type' => 'tribe_events',
            ]);

            if ($check_event_ar) {
                if ($single_event_ar) {
                    $event_venu_id = array();
                    $venu_zip = '';
                    foreach ($single_event_ar as $key => $value) {
                        foreach ($value as $skey => $svalue) {
                            if ($skey == 'ID') {
                                $event_venu_id = get_post_meta($svalue,  '_EventVenueID');
                                $venu_zip = get_post_meta(implode($event_venu_id),  '_VenueZip');
                            }
                        }
                    }
                    // geo location
                    $result_obj = array();
                    foreach ($venu_zip as $key => $address) {
                        $geo_location = file_get_contents("https://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$google_api_key");
                        $result = json_decode($geo_location, true);
                        $result_obj[$key] = $result;
                    }
                    $post_id_location = array();
                    foreach ($result_obj as $key => $value) {
                        foreach ($value as $skey => $svalue) {
                            foreach ($svalue as $s_key => $s_value) {
                                $post_id_location[$key] = $s_value['geometry']['location'];
                            }
                        }
                    }
                    // $user_ip = '47.29.174.114';
                    $user_ip = do_shortcode('[show_ip]');
                    $geo_location = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));

                    $lat2 = $geo_location["geoplugin_latitude"];
                    $lon2 = $geo_location["geoplugin_longitude"];
                    $lat1 = '';
                    $lon1 = '';
                    $distance = array();
                    foreach ($post_id_location as $key => $value) {

                        foreach ($value as $s_key => $s_value) {
                            if ($s_key == 'lat') {
                                $lat1 = $s_value;
                            } else {
                                $lon1 = $s_value;
                            }
                        }
                        $theta = $lon1 - $lon2;

                        $dist = sin(deg2rad((float)$lat1)) * sin(deg2rad((float)$lat2)) +
                            cos(deg2rad((float)$lat1)) * cos(deg2rad((float)$lat2)) * cos(deg2rad((float)$theta));
                        $dist = acos($dist);
                        $dist = rad2deg($dist);
                        $distance[$key] = number_format((float)$dist * 60 * 1.1515 * 1.609344 * 0.62137119, 1, '.', ''); //miles
                    }

                    //Enrolled post - Start
                    $get_completed_order_id = get_posts([
                        'author'        =>  $user_id,
                        'fields' => 'ids',
                        'post_type' => 'tec_tc_order',
                        'post_status' => 'tec-tc-completed',
                        'numberposts' => -1
                    ]);
                    $order_event_id = array();
                    foreach ($get_completed_order_id as $value) {
                        $order_event_id[] = get_post_meta($value,  '_tec_tc_order_events_in_order');
                    }
                    $order_event_id_ar = array();
                    $subscribe_status = false;
                    foreach ($order_event_id as $value) {
                        foreach ($value as $s_event_id) {
                            if ($event_id == $s_event_id) {
                                $subscribe_status = true;
                            }
                        }
                    }
                    $user_type_events_distance = array();
                    $user_type_events_single_distance = array();
                    $user_type_events_ar_distance = array();
                    $event_venu_id_distance = array();
                    $venu_zip_id_ar_distance = array();
                    $venu_zip_id_single_ar_distance = array();
                    $venu_zip_distance = '';
                    $event_start_distance = '';
                    $event_end_distance = '';
                    $_venueAddress_distance = '';
                    $_venueCity_distance = '';
                    $_venueCountry_distance = '';
                    $_venueProvince_distance = '';
                    $_Thumbnail = '';
                    $_Featured = '';
                    foreach ($single_event_ar as $key => $value) {
                        foreach ($value as $skey => $svalue) {
                            if ($skey == 'ID') {
                                $categories_list = get_the_terms($svalue, 'tribe_events_cat');
                                $cat_ar_list = [];
                                foreach ($categories_list  as $cat_value) {
                                    $cat_ar_list[] = $cat_value->name;
                                }
                                $cat_list = implode(", ", $cat_ar_list);
                                $event_start_distance = get_post_meta($svalue,  '_EventStartDate');
                                $event_start_distance = array(date('Y-m-d h:i:s', strtotime($event_start_distance[0])));
                                $event_end_distance = get_post_meta($svalue,  '_EventEndDate');
                                $event_end_distance = array(date('Y-m-d h:i:s', strtotime($event_end_distance[0])));
                                $event_time_zone_distance = get_post_meta($svalue,  '_EventTimezone');
                                $event_venu_id_distance = get_post_meta($svalue,  '_EventVenueID');
                                $venu_zip_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueZip');
                                $_venueAddress_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueAddress');
                                $_venueCity_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueCity');
                                $_venueCountry_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueCountry');
                                $_venueProvince_distance = get_post_meta(implode($event_venu_id_distance),  '_VenueProvince');
                                $image = wp_get_attachment_image_src(get_post_thumbnail_id($svalue), 'single-post-thumbnail');
                                $_tribe_virtual_events_type = get_post_meta($svalue,  '_tribe_virtual_events_type');
                                $_tribe_events_virtual_video_source = get_post_meta($svalue,  '_tribe_events_virtual_video_source');
                                //Virtual data - Start
                                $virtual_data = array();
                                if ($_tribe_virtual_events_type) {
                                    $_tribe_events_is_virtual = get_post_meta($svalue,  '_tribe_events_is_virtual');
                                    $_tribe_events_virtual_url = get_post_meta($svalue,  '_tribe_events_virtual_url');
                                    $_tribe_events_virtual_linked_button_text = get_post_meta($svalue,  '_tribe_events_virtual_linked_button_text');
                                    $_tribe_events_virtual_linked_button = get_post_meta($svalue,  '_tribe_events_virtual_linked_button');
                                    $_tribe_events_virtual_show_embed_at = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_at');
                                    $_tribe_events_virtual_show_embed_to = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_to');
                                    $_tribe_events_virtual_show_on_event = get_post_meta($svalue,  '_tribe_events_virtual_show_on_event');
                                    $_tribe_events_virtual_show_on_views = get_post_meta($svalue,  '_tribe_events_virtual_show_on_views');
                                    $_tribe_events_virtual_rsvp_email_link = get_post_meta($svalue,  '_tribe_events_virtual_rsvp_email_link');
                                    $_tribe_events_virtual_ticket_email_link = get_post_meta($svalue,  '_tribe_events_virtual_ticket_email_link');
                                    $_tribe_events_virtual_embed_video = get_post_meta($svalue,  '_tribe_events_virtual_embed_video');
                                    if ($_tribe_events_virtual_video_source[0] == 'zoom') {
                                        $_tribe_events_zoom_account_id = get_post_meta($svalue,  '_tribe_events_zoom_account_id');
                                        $_tribe_events_zoom_meeting_data = get_post_meta($svalue,  '_tribe_events_zoom_meeting_data');
                                        $_tribe_events_zoom_meeting_id = get_post_meta($svalue,  '_tribe_events_zoom_meeting_id');
                                        $_tribe_events_zoom_join_url = get_post_meta($svalue,  '_tribe_events_zoom_join_url');
                                        $_tribe_events_zoom_join_instructions = get_post_meta($svalue,  '_tribe_events_zoom_join_instructions');
                                        $_tribe_events_zoom_password_hash = get_post_meta($svalue,  '_tribe_events_zoom_password_hash');
                                        $_tribe_events_zoom_password = get_post_meta($svalue,  '_tribe_events_zoom_password');
                                        $_tribe_events_zoom_host_email = get_post_meta($svalue,  '_tribe_events_zoom_host_email');
                                        $_tribe_events_zoom_alternative_hosts = get_post_meta($svalue,  '_tribe_events_zoom_alternative_hosts');
                                        $_tribe_events_zoom_meeting_type = get_post_meta($svalue,  '_tribe_events_zoom_meeting_type');
                                        $_tribe_events_google_display_details = get_post_meta($svalue,  '_tribe_events_google_display_details');
                                        $_tribe_events_microsoft_display_details = get_post_meta($svalue,  '_tribe_events_microsoft_display_details');
                                        $_tribe_events_webex_display_details = get_post_meta($svalue,  '_tribe_events_webex_display_details');
                                        $_tribe_events_zoom_display_details = get_post_meta($svalue,  '_tribe_events_zoom_display_details');
                                        $virtual_data = array(
                                            '_tribe_virtual_events_type' => $_tribe_virtual_events_type[0],
                                            '_tribe_events_virtual_video_source' => $_tribe_events_virtual_video_source[0],
                                            '_tribe_events_zoom_account_id' => $_tribe_events_zoom_account_id[0],
                                            '_tribe_events_zoom_meeting_data' => $_tribe_events_zoom_meeting_data[0],
                                            '_tribe_events_zoom_meeting_id' => $_tribe_events_zoom_meeting_id[0],
                                            '_tribe_events_zoom_join_url' => $_tribe_events_zoom_join_url[0],
                                            '_tribe_events_zoom_join_instructions' => $_tribe_events_zoom_join_instructions[0],
                                            '_tribe_events_zoom_password_hash' => $_tribe_events_zoom_password_hash[0],
                                            '_tribe_events_zoom_password' => $_tribe_events_zoom_password[0],
                                            '_tribe_events_zoom_host_email' => $_tribe_events_zoom_host_email[0],
                                            '_tribe_events_zoom_alternative_hosts' => $_tribe_events_zoom_alternative_hosts[0],
                                            '_tribe_events_zoom_meeting_type' => $_tribe_events_zoom_meeting_type[0],
                                            '_tribe_events_is_virtual' => $_tribe_events_is_virtual[0],
                                            '_tribe_events_virtual_url' => $_tribe_events_virtual_url[0],
                                            '_tribe_events_virtual_linked_button_text' => $_tribe_events_virtual_linked_button_text[0],
                                            '_tribe_events_virtual_linked_button' => $_tribe_events_virtual_linked_button[0],
                                            '_tribe_events_virtual_show_embed_at' => $_tribe_events_virtual_show_embed_at[0],
                                            '_tribe_events_virtual_show_embed_to' => $_tribe_events_virtual_show_embed_to[0][0],
                                            '_tribe_events_virtual_show_on_event' => $_tribe_events_virtual_show_on_event[0],
                                            '_tribe_events_virtual_show_on_views' => $_tribe_events_virtual_show_on_views[0],
                                            '_tribe_events_virtual_rsvp_email_link' => $_tribe_events_virtual_rsvp_email_link[0],
                                            '_tribe_events_virtual_ticket_email_link' => $_tribe_events_virtual_ticket_email_link[0],
                                            '_tribe_events_virtual_embed_video' => $_tribe_events_virtual_embed_video[0],
                                            '_tribe_events_google_display_details' => $_tribe_events_google_display_details[0],
                                            '_tribe_events_microsoft_display_details' => $_tribe_events_microsoft_display_details[0],
                                            '_tribe_events_webex_display_details' => $_tribe_events_webex_display_details[0],
                                            '_tribe_events_zoom_display_details' => $_tribe_events_zoom_display_details[0],
                                        );
                                    } else  if ($_tribe_events_virtual_video_source[0] == 'youtube') {
                                        $_tribe_events_is_virtual = get_post_meta($svalue,  '_tribe_events_is_virtual');
                                        $_tribe_events_virtual_url = get_post_meta($svalue,  '_tribe_events_virtual_url');
                                        $_tribe_events_virtual_linked_button_text = get_post_meta($svalue,  '_tribe_events_virtual_linked_button_text');
                                        $_tribe_events_virtual_linked_button = get_post_meta($svalue,  '_tribe_events_virtual_linked_button');
                                        $_tribe_events_virtual_show_embed_at = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_at');
                                        $_tribe_events_virtual_show_embed_to = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_to');
                                        $_tribe_events_virtual_show_on_event = get_post_meta($svalue,  '_tribe_events_virtual_show_on_event');
                                        $_tribe_events_virtual_show_on_views = get_post_meta($svalue,  '_tribe_events_virtual_show_on_views');
                                        $_tribe_events_virtual_rsvp_email_link = get_post_meta($svalue,  '_tribe_events_virtual_rsvp_email_link');
                                        $_tribe_events_virtual_ticket_email_link = get_post_meta($svalue,  '_tribe_events_virtual_ticket_email_link');
                                        $_tribe_events_virtual_embed_video = get_post_meta($svalue,  '_tribe_events_virtual_embed_video');
                                        $_tribe_events_youtube_channel_id = get_post_meta($svalue,  '_tribe_events_youtube_channel_id');
                                        $virtual_data = array(
                                            '_tribe_virtual_events_type' => $_tribe_virtual_events_type[0],
                                            '_tribe_events_virtual_video_source' => $_tribe_events_virtual_video_source[0],
                                            '_tribe_events_is_virtual' => $_tribe_events_is_virtual[0],
                                            '_tribe_events_virtual_url' => $_tribe_events_virtual_url[0],
                                            '_tribe_events_virtual_linked_button_text' => $_tribe_events_virtual_linked_button_text[0],
                                            '_tribe_events_virtual_linked_button' => $_tribe_events_virtual_linked_button[0],
                                            '_tribe_events_virtual_show_embed_at' => $_tribe_events_virtual_show_embed_at[0],
                                            '_tribe_events_virtual_show_embed_to' => $_tribe_events_virtual_show_embed_to[0][0],
                                            '_tribe_events_virtual_show_on_event' => $_tribe_events_virtual_show_on_event[0],
                                            '_tribe_events_virtual_show_on_views' => $_tribe_events_virtual_show_on_views[0],
                                            '_tribe_events_virtual_rsvp_email_link' => $_tribe_events_virtual_rsvp_email_link[0],
                                            '_tribe_events_virtual_ticket_email_link' => $_tribe_events_virtual_ticket_email_link[0],
                                            '_tribe_events_virtual_embed_video' => $_tribe_events_virtual_embed_video[0],
                                            '_tribe_events_youtube_channel_id' => $_tribe_events_youtube_channel_id[0],
                                        );
                                    } else  if ($_tribe_events_virtual_video_source[0] == 'google') {
                                        $_tribe_events_is_virtual = get_post_meta($svalue,  '_tribe_events_is_virtual');
                                        $_tribe_events_virtual_url = get_post_meta($svalue,  '_tribe_events_virtual_url');
                                        $_tribe_events_google_account_id = get_post_meta($svalue,  '_tribe_events_google_account_id');
                                        $_tribe_events_google_meeting_data = get_post_meta($svalue,  '_tribe_events_google_meeting_data');
                                        $_tribe_events_google_meeting_id = get_post_meta($svalue,  '_tribe_events_google_meeting_id');
                                        $_tribe_events_google_join_url = get_post_meta($svalue,  '_tribe_events_google_join_url');
                                        $_tribe_events_google_host_email = get_post_meta($svalue,  '_tribe_events_google_host_email');
                                        $_tribe_events_google_entry_points = get_post_meta($svalue,  '_tribe_events_google_entry_points');
                                        $_tribe_events_google_conference_id = get_post_meta($svalue,  '_tribe_events_google_conference_id');
                                        $_tribe_events_google_meeting_type = get_post_meta($svalue,  '_tribe_events_google_meeting_type');
                                        $_tribe_events_virtual_linked_button_text = get_post_meta($svalue,  '_tribe_events_virtual_linked_button_text');
                                        $_tribe_events_virtual_linked_button = get_post_meta($svalue,  '_tribe_events_virtual_linked_button');
                                        $_tribe_events_virtual_show_embed_at = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_at');
                                        $_tribe_events_virtual_show_embed_to = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_to');
                                        $_tribe_events_virtual_show_on_event = get_post_meta($svalue,  '_tribe_events_virtual_show_on_event');
                                        $_tribe_events_virtual_show_on_views = get_post_meta($svalue,  '_tribe_events_virtual_show_on_views');
                                        $_tribe_events_virtual_rsvp_email_link = get_post_meta($svalue,  '_tribe_events_virtual_rsvp_email_link');
                                        $_tribe_events_virtual_ticket_email_link = get_post_meta($svalue,  '_tribe_events_virtual_ticket_email_link');
                                        $_tribe_events_virtual_embed_video = get_post_meta($svalue,  '_tribe_events_virtual_embed_video');
                                        $_tribe_events_google_display_details = get_post_meta($svalue,  '_tribe_events_google_display_details');
                                        $_tribe_events_microsoft_display_details = get_post_meta($svalue,  '_tribe_events_microsoft_display_details');
                                        $_tribe_events_webex_display_details = get_post_meta($svalue,  '_tribe_events_webex_display_details');
                                        $_tribe_events_zoom_display_details = get_post_meta($svalue,  '_tribe_events_zoom_display_details');
                                        $virtual_data = array(
                                            '_tribe_virtual_events_type' => $_tribe_virtual_events_type[0],
                                            '_tribe_events_virtual_video_source' => $_tribe_events_virtual_video_source[0],
                                            '_tribe_events_google_account_id' => $_tribe_events_google_account_id[0],
                                            '_tribe_events_google_meeting_data' => $_tribe_events_google_meeting_data[0],
                                            '_tribe_events_google_meeting_id' => $_tribe_events_google_meeting_id[0],
                                            '_tribe_events_google_join_url' => $_tribe_events_google_join_url[0],
                                            '_tribe_events_google_host_email' => $_tribe_events_google_host_email[0],
                                            '_tribe_events_google_entry_points' => $_tribe_events_google_entry_points[0],
                                            '_tribe_events_google_conference_id' => $_tribe_events_google_conference_id[0],
                                            '_tribe_events_google_meeting_type' => $_tribe_events_google_meeting_type[0],
                                            '_tribe_events_is_virtual' => $_tribe_events_is_virtual[0],
                                            '_tribe_events_virtual_url' => $_tribe_events_virtual_url[0],
                                            '_tribe_events_virtual_linked_button_text' => $_tribe_events_virtual_linked_button_text[0],
                                            '_tribe_events_virtual_linked_button' => $_tribe_events_virtual_linked_button[0],
                                            '_tribe_events_virtual_show_embed_at' => $_tribe_events_virtual_show_embed_at[0],
                                            '_tribe_events_virtual_show_embed_to' => $_tribe_events_virtual_show_embed_to[0][0],
                                            '_tribe_events_virtual_show_on_event' => $_tribe_events_virtual_show_on_event[0],
                                            '_tribe_events_virtual_show_on_views' => $_tribe_events_virtual_show_on_views[0],
                                            '_tribe_events_virtual_rsvp_email_link' => $_tribe_events_virtual_rsvp_email_link[0],
                                            '_tribe_events_virtual_ticket_email_link' => $_tribe_events_virtual_ticket_email_link[0],
                                            '_tribe_events_virtual_embed_video' => $_tribe_events_virtual_embed_video[0],
                                            '_tribe_events_google_display_details' => $_tribe_events_google_display_details[0],
                                            '_tribe_events_microsoft_display_details' => $_tribe_events_microsoft_display_details[0],
                                            '_tribe_events_webex_display_details' => $_tribe_events_webex_display_details[0],
                                            '_tribe_events_zoom_display_details' => $_tribe_events_zoom_display_details[0],
                                        );
                                    } else  if ($_tribe_events_virtual_video_source[0] == 'microsoft') {
                                        $_tribe_events_microsoft_account_id = get_post_meta($svalue,  '_tribe_events_microsoft_account_id');
                                        $_tribe_events_microsoft_meeting_data = get_post_meta($svalue,  '_tribe_events_microsoft_meeting_data');
                                        $_tribe_events_microsoft_meeting_id = get_post_meta($svalue,  '_tribe_events_microsoft_meeting_id');
                                        $_tribe_events_microsoft_join_url = get_post_meta($svalue,  '_tribe_events_microsoft_join_url');
                                        $_tribe_events_microsoft_host_email = get_post_meta($svalue,  '_tribe_events_microsoft_host_email');
                                        $_tribe_events_microsoft_provider = get_post_meta($svalue,  '_tribe_events_microsoft_provider');
                                        $_tribe_events_microsoft_conference_id = get_post_meta($svalue,  '_tribe_events_microsoft_conference_id');
                                        $_tribe_events_microsoft_meeting_type = get_post_meta($svalue,  '_tribe_events_microsoft_meeting_type');
                                        $_tribe_events_is_virtual = get_post_meta($svalue,  '_tribe_events_is_virtual');
                                        $_tribe_events_virtual_url = get_post_meta($svalue,  '_tribe_events_virtual_url');
                                        $_tribe_events_virtual_linked_button_text = get_post_meta($svalue,  '_tribe_events_virtual_linked_button_text');
                                        $_tribe_events_virtual_linked_button = get_post_meta($svalue,  '_tribe_events_virtual_linked_button');
                                        $_tribe_events_virtual_show_embed_at = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_at');
                                        $_tribe_events_virtual_show_embed_to = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_to');
                                        $_tribe_events_virtual_show_on_event = get_post_meta($svalue,  '_tribe_events_virtual_show_on_event');
                                        $_tribe_events_virtual_show_on_views = get_post_meta($svalue,  '_tribe_events_virtual_show_on_views');
                                        $_tribe_events_virtual_rsvp_email_link = get_post_meta($svalue,  '_tribe_events_virtual_rsvp_email_link');
                                        $_tribe_events_virtual_ticket_email_link = get_post_meta($svalue,  '_tribe_events_virtual_ticket_email_link');
                                        $_tribe_events_virtual_embed_video = get_post_meta($svalue,  '_tribe_events_virtual_embed_video');
                                        $_tribe_events_google_display_details = get_post_meta($svalue,  '_tribe_events_google_display_details');
                                        $_tribe_events_microsoft_display_details = get_post_meta($svalue,  '_tribe_events_microsoft_display_details');
                                        $_tribe_events_webex_display_details = get_post_meta($svalue,  '_tribe_events_webex_display_details');
                                        $_tribe_events_zoom_display_details = get_post_meta($svalue,  '_tribe_events_zoom_display_details');
                                        $virtual_data = array(
                                            '_tribe_virtual_events_type' => $_tribe_virtual_events_type[0],
                                            '_tribe_events_virtual_video_source' => $_tribe_events_virtual_video_source[0],
                                            '_tribe_events_microsoft_account_id' => $_tribe_events_microsoft_account_id[0],
                                            '_tribe_events_microsoft_meeting_data' => $_tribe_events_microsoft_meeting_data[0],
                                            '_tribe_events_microsoft_meeting_id' => $_tribe_events_microsoft_meeting_id[0],
                                            '_tribe_events_microsoft_join_url' => $_tribe_events_microsoft_join_url[0],
                                            '_tribe_events_microsoft_host_email' => $_tribe_events_microsoft_host_email[0],
                                            '_tribe_events_microsoft_provider' => $_tribe_events_microsoft_provider[0],
                                            '_tribe_events_microsoft_conference_id' => $_tribe_events_microsoft_conference_id[0],
                                            '_tribe_events_microsoft_meeting_type' => $_tribe_events_microsoft_meeting_type[0],
                                            '_tribe_events_is_virtual' => $_tribe_events_is_virtual[0],
                                            '_tribe_events_virtual_url' => $_tribe_events_virtual_url[0],
                                            '_tribe_events_virtual_linked_button_text' => $_tribe_events_virtual_linked_button_text[0],
                                            '_tribe_events_virtual_linked_button' => $_tribe_events_virtual_linked_button[0],
                                            '_tribe_events_virtual_show_embed_at' => $_tribe_events_virtual_show_embed_at[0],
                                            '_tribe_events_virtual_show_embed_to' => $_tribe_events_virtual_show_embed_to[0][0],
                                            '_tribe_events_virtual_show_on_event' => $_tribe_events_virtual_show_on_event[0],
                                            '_tribe_events_virtual_show_on_views' => $_tribe_events_virtual_show_on_views[0],
                                            '_tribe_events_virtual_rsvp_email_link' => $_tribe_events_virtual_rsvp_email_link[0],
                                            '_tribe_events_virtual_ticket_email_link' => $_tribe_events_virtual_ticket_email_link[0],
                                            '_tribe_events_virtual_embed_video' => $_tribe_events_virtual_embed_video[0],
                                            '_tribe_events_google_display_details' => $_tribe_events_google_display_details[0],
                                            '_tribe_events_microsoft_display_details' => $_tribe_events_microsoft_display_details[0],
                                            '_tribe_events_webex_display_details' => $_tribe_events_webex_display_details[0],
                                            '_tribe_events_zoom_display_details' => $_tribe_events_zoom_display_details[0],
                                        );
                                    } else  if ($_tribe_events_virtual_video_source[0] == 'webex') {
                                        $_tribe_events_google_account_id = get_post_meta($svalue,  '_tribe_events_google_account_id');
                                        $_tribe_events_webex_account_id = get_post_meta($svalue,  '_tribe_events_webex_account_id');
                                        $_tribe_events_webex_meeting_data = get_post_meta($svalue,  '_tribe_events_webex_meeting_data');
                                        $_tribe_events_webex_meeting_id = get_post_meta($svalue,  '_tribe_events_webex_meeting_id');
                                        $_tribe_events_webex_join_url = get_post_meta($svalue,  '_tribe_events_webex_join_url');
                                        $_tribe_events_webex_password = get_post_meta($svalue,  '_tribe_events_webex_password');
                                        $_tribe_events_webex_host_email = get_post_meta($svalue,  '_tribe_events_webex_host_email');
                                        $_tribe_events_webex_meeting_type = get_post_meta($svalue,  '_tribe_events_webex_meeting_type');
                                        $_tribe_events_is_virtual = get_post_meta($svalue,  '_tribe_events_is_virtual');
                                        $_tribe_events_virtual_url = get_post_meta($svalue,  '_tribe_events_virtual_url');
                                        $_tribe_events_virtual_linked_button_text = get_post_meta($svalue,  '_tribe_events_virtual_linked_button_text');
                                        $_tribe_events_virtual_linked_button = get_post_meta($svalue,  '_tribe_events_virtual_linked_button');
                                        $_tribe_events_virtual_show_embed_at = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_at');
                                        $_tribe_events_virtual_show_embed_to = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_to');
                                        $_tribe_events_virtual_show_on_event = get_post_meta($svalue,  '_tribe_events_virtual_show_on_event');
                                        $_tribe_events_virtual_show_on_views = get_post_meta($svalue,  '_tribe_events_virtual_show_on_views');
                                        $_tribe_events_virtual_rsvp_email_link = get_post_meta($svalue,  '_tribe_events_virtual_rsvp_email_link');
                                        $_tribe_events_virtual_ticket_email_link = get_post_meta($svalue,  '_tribe_events_virtual_ticket_email_link');
                                        $_tribe_events_virtual_embed_video = get_post_meta($svalue,  '_tribe_events_virtual_embed_video');
                                        $_tribe_events_google_display_details = get_post_meta($svalue,  '_tribe_events_google_display_details');
                                        $_tribe_events_microsoft_display_details = get_post_meta($svalue,  '_tribe_events_microsoft_display_details');
                                        $_tribe_events_webex_display_details = get_post_meta($svalue,  '_tribe_events_webex_display_details');
                                        $_tribe_events_zoom_display_details = get_post_meta($svalue,  '_tribe_events_zoom_display_details');
                                        $virtual_data = array(
                                            '_tribe_virtual_events_type' => $_tribe_virtual_events_type[0],
                                            '_tribe_events_virtual_video_source' => $_tribe_events_virtual_video_source[0],
                                            '_tribe_events_google_account_id' => $_tribe_events_google_account_id[0],
                                            '_tribe_events_webex_account_id' => $_tribe_events_webex_account_id[0],
                                            '_tribe_events_webex_meeting_data' => $_tribe_events_webex_meeting_data[0],
                                            '_tribe_events_webex_meeting_id' => $_tribe_events_webex_meeting_id[0],
                                            '_tribe_events_webex_join_url' => $_tribe_events_webex_join_url[0],
                                            '_tribe_events_webex_password' => $_tribe_events_webex_password[0],
                                            '_tribe_events_webex_host_email' => $_tribe_events_webex_host_email[0],
                                            '_tribe_events_webex_meeting_type' => $_tribe_events_webex_meeting_type[0],
                                            '_tribe_events_is_virtual' => $_tribe_events_is_virtual[0],
                                            '_tribe_events_virtual_url' => $_tribe_events_virtual_url[0],
                                            '_tribe_events_virtual_linked_button_text' => $_tribe_events_virtual_linked_button_text[0],
                                            '_tribe_events_virtual_linked_button' => $_tribe_events_virtual_linked_button[0],
                                            '_tribe_events_virtual_show_embed_at' => $_tribe_events_virtual_show_embed_at[0],
                                            '_tribe_events_virtual_show_embed_to' => $_tribe_events_virtual_show_embed_to[0][0],
                                            '_tribe_events_virtual_show_on_event' => $_tribe_events_virtual_show_on_event[0],
                                            '_tribe_events_virtual_show_on_views' => $_tribe_events_virtual_show_on_views[0],
                                            '_tribe_events_virtual_rsvp_email_link' => $_tribe_events_virtual_rsvp_email_link[0],
                                            '_tribe_events_virtual_ticket_email_link' => $_tribe_events_virtual_ticket_email_link[0],
                                            '_tribe_events_virtual_embed_video' => $_tribe_events_virtual_embed_video[0],
                                            '_tribe_events_google_display_details' => $_tribe_events_google_display_details[0],
                                            '_tribe_events_microsoft_display_details' => $_tribe_events_microsoft_display_details[0],
                                            '_tribe_events_webex_display_details' => $_tribe_events_webex_display_details[0],
                                            '_tribe_events_zoom_display_details' => $_tribe_events_zoom_display_details[0],
                                        );
                                    } else  if ($_tribe_events_virtual_video_source[0] == 'facebook') {
                                        $_tribe_events_is_virtual = get_post_meta($svalue,  '_tribe_events_is_virtual');
                                        $_tribe_events_virtual_url = get_post_meta($svalue,  '_tribe_events_virtual_url');
                                        $_tribe_events_virtual_linked_button_text = get_post_meta($svalue,  '_tribe_events_virtual_linked_button_text');
                                        $_tribe_events_virtual_linked_button = get_post_meta($svalue,  '_tribe_events_virtual_linked_button');
                                        $_tribe_events_virtual_show_embed_at = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_at');
                                        $_tribe_events_virtual_show_embed_to = get_post_meta($svalue,  '_tribe_events_virtual_show_embed_to');
                                        $_tribe_events_virtual_show_on_event = get_post_meta($svalue,  '_tribe_events_virtual_show_on_event');
                                        $_tribe_events_virtual_show_on_views = get_post_meta($svalue,  '_tribe_events_virtual_show_on_views');
                                        $_tribe_events_virtual_rsvp_email_link = get_post_meta($svalue,  '_tribe_events_virtual_rsvp_email_link');
                                        $_tribe_events_virtual_ticket_email_link = get_post_meta($svalue,  '_tribe_events_virtual_ticket_email_link');
                                        $_tribe_events_virtual_embed_video = get_post_meta($svalue,  '_tribe_events_virtual_embed_video');
                                        $_tribe_events_google_display_details = get_post_meta($svalue,  '_tribe_events_google_display_details');
                                        $_tribe_events_microsoft_display_details = get_post_meta($svalue,  '_tribe_events_microsoft_display_details');
                                        $_tribe_events_webex_display_details = get_post_meta($svalue,  '_tribe_events_webex_display_details');
                                        $_tribe_events_zoom_display_details = get_post_meta($svalue,  '_tribe_events_zoom_display_details');
                                        $_tribe_events_facebook_local_id = get_post_meta($svalue,  '_tribe_events_facebook_local_id');
                                        $virtual_data = array(
                                            '_tribe_virtual_events_type' => $_tribe_virtual_events_type[0],
                                            '_tribe_events_virtual_video_source' => $_tribe_events_virtual_video_source[0],
                                            '_tribe_events_is_virtual' => $_tribe_events_is_virtual[0],
                                            '_tribe_events_virtual_url' => $_tribe_events_virtual_url[0],
                                            '_tribe_events_virtual_linked_button_text' => $_tribe_events_virtual_linked_button_text[0],
                                            '_tribe_events_virtual_linked_button' => $_tribe_events_virtual_linked_button[0],
                                            '_tribe_events_virtual_show_embed_at' => $_tribe_events_virtual_show_embed_at[0],
                                            '_tribe_events_virtual_show_embed_to' => $_tribe_events_virtual_show_embed_to[0][0],
                                            '_tribe_events_virtual_show_on_event' => $_tribe_events_virtual_show_on_event[0],
                                            '_tribe_events_virtual_show_on_views' => $_tribe_events_virtual_show_on_views[0],
                                            '_tribe_events_virtual_rsvp_email_link' => $_tribe_events_virtual_rsvp_email_link[0],
                                            '_tribe_events_virtual_ticket_email_link' => $_tribe_events_virtual_ticket_email_link[0],
                                            '_tribe_events_virtual_embed_video' => $_tribe_events_virtual_embed_video[0],
                                            '_tribe_events_facebook_local_id' => $_tribe_events_facebook_local_id[0],
                                        );
                                    }
                                }
                                //Virtual data - End
                                $_Thumbnail = $image[0];
                                $featured_event = get_post_meta($svalue,  '_tribe_featured');
                                if ($featured_event) {
                                    $_Featured = true;
                                } else {
                                    $_Featured = false;
                                }
                                $venu_zip_id_single_ar_distance[$svalue] = $venu_zip_distance;
                            }
                            unset($user_type_events_single_distance['post_excerpt']);
                            unset($user_type_events_single_distance['post_status']);
                            unset($user_type_events_single_distance['comment_status']);
                            unset($user_type_events_single_distance['ping_status']);
                            unset($user_type_events_single_distance['post_password']);
                            unset($user_type_events_single_distance['post_name']);
                            unset($user_type_events_single_distance['to_ping']);
                            unset($user_type_events_single_distance['pinged']);
                            unset($user_type_events_single_distance['post_content_filtered']);
                            unset($user_type_events_single_distance['post_parent']);
                            unset($user_type_events_single_distance['guid']);
                            unset($user_type_events_single_distance['menu_order']);
                            unset($user_type_events_single_distance['post_mime_type']);
                            unset($user_type_events_single_distance['comment_count']);
                            unset($user_type_events_single_distance['filter']);
                            $venu_zip_id_ar_distance[] = $venu_zip_id_single_ar_distance;
                            $user_type_events_ar_distance['categories'] = $cat_list;
                            $user_type_events_ar_distance['_EventStartDate'] = $event_start_distance;
                            $user_type_events_ar_distance['_EventEndDate'] = $event_end_distance;
                            $user_type_events_ar_distance['_EventTimezone'] = $event_time_zone_distance;
                            $user_type_events_ar_distance['_VenueAddress'] = $_venueAddress_distance;
                            $user_type_events_ar_distance['_VenueCity'] = $_venueCity_distance;
                            $user_type_events_ar_distance['_VenueProvince'] = $_venueProvince_distance;
                            $user_type_events_ar_distance['_VenueCountry'] = $_venueCountry_distance;
                            $user_type_events_ar_distance['_VenueZip'] = $venu_zip_distance;
                            $user_type_events_ar_distance['_Distance'] = $distance;
                            $user_type_events_ar_distance['_Subscribe'] = $subscribe_status;
                            $user_type_events_ar_distance['_Attachment'] = $_Thumbnail;
                            $user_type_events_ar_distance['_Featured'] = $_Featured;
                            $user_type_events_ar_distance['going'] = $going;
                            $user_type_events_ar_distance['may_be'] = $may_be;
                            $user_type_events_ar_distance['not_going'] = $not_going;
                            $user_type_events_ar_distance['user_event_status'] = $user_event;
                            //Virtual - Start
                            if ($_tribe_virtual_events_type) {
                                $user_type_events_ar_distance['virtual'] = $virtual_data;
                            } else {
                                $empty_json = json_encode(array(), JSON_FORCE_OBJECT);
                                $empty_json =  json_decode($empty_json);
                                $user_type_events_ar_distance['virtual'] = $empty_json;
                            }
                            // Virtual - End
                            $user_type_events_single_distance[$skey] = $svalue;
                        }

                        $user_type_events_distance[] = array_merge($user_type_events_single_distance, $user_type_events_ar_distance);
                    }

                    $single_event_detail = array();
                    foreach ($user_type_events_distance as $key => $value) {
                        $single_event_detail = $value;
                    }
                    $response['success'] = true;
                    $response['message'] = __("Event details.");
                    $response['data'] = $single_event_detail;
                    return $response;
                } else {
                    $response['success'] = false;
                    $response['message'] = "Event id of event already started.";
                    return $response;
                }
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid event id.";
                return $response;
            }
            // Fetch data - end
        } else {
            $response['success'] = false;
            $response['message'] = "User ID is invalid.";
            return $response;
        }
    } catch (SignatureInvalidException $e) {
        $response['success'] = false;
        $response['message'] = "Invalid token.";
        return $response;
    } catch (ExpiredException $e) {
        $response['success'] = false;
        $response['message'] = "Token expired.";
        return $response;
    } catch (Exception $e) {
        if (!$token) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Bearer token is missing, please provide bearer token.']);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}
