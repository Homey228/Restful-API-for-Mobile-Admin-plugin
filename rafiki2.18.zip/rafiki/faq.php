<?php












//Single faq
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', 'faq-single', [
        'methods'  => 'POST',
        'callback' => 'single_faq'
    ]);
});
function single_faq($request)
{

    $faq = '{
        "How do I add an event to my personal events calendar?": ["There are quite a few ways to add an event to your calendar in the app. After you’ve discovered what event you wish to attend tap the event and select “Add to My Calendar.” "]
    }';
    $faq_data = json_decode($faq, true);
    $response['success'] = true;
    $response['message'] = "Faq.";
    $response['data'] = $faq_data;
    return $response;
}

// Wellness faq
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', '/faq-wellness', [
        'methods'  => 'POST',
        'callback' => 'site_faq_wellness'
    ]);
});

function site_faq_wellness($request)
{

    $faq = '{
        "How do I add an event to my personal events calendar?": ["There are quite a few ways to add an event to your calendar in the app. After you’ve discov..."],
        "How to do I get notified for events happening near me?": ["In your Account, you will see a section titled “Settings’. In order for us to notify you for... "],
        "How to do I get notified for events happening near me? ": ["In your Account, you will see a section titled “Settings’. In order for us to notify you for..."]
    }';
    $faq_data = json_decode($faq, true);
    $response['success'] = true;
    $response['message'] = "Faq wellness.";
    $response['data'] = $faq_data;
    return $response;
}

//Account faq
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', '/faq-account', [
        'methods'  => 'POST',
        'callback' => 'site_faq_account'
    ]);
});
function site_faq_account($request)
{

    $faq = '{
        "How do I add an event to my personal events calendar?": ["There are quite a few ways to add an event to your calendar in the app. After you’ve discovered what event you wish to attend tap the event and select “Add to My Calendar.”"],
        "What Time Does The Stock Market Open?": ["In your Account, you will see a section titled “Settings’. In order for us to notify you for... "],
        "Is The Stock Market Open On Weekends?": ["In your Account, you will see a section titled “Settings’. In order for us to notify you for..."]
    }';
    $faq_data = json_decode($faq, true);
    $response['success'] = true;
    $response['message'] = "Faq account.";
    $response['data'] = $faq_data;
    return $response;
}
