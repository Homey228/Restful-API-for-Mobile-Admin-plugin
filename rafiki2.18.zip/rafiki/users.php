<?php

use Firebase\JWT\JWT;
//register

function extend_jwt_expiration_time($expire) {
    return time() + (15 * DAY_IN_SECONDS); // 15 days in seconds
}
add_filter('jwt_auth_expire', 'extend_jwt_expiration_time');


add_action('rest_api_init', 'wp_rest_user_endpoints');
/**
 * Register a new user
 *
 * @param  WP_REST_Request $request Full details about the request.
 * @return array $args.
 **/
function wp_rest_user_endpoints($request)
{
    /**
     * Handle Register User request.
     */
    register_rest_route(
        'wp/v2',
        'user/register',
        array(
            'methods' => 'POST',
            'callback' => 'wc_rest_user_endpoint_handler',
        ),
    );
}
function wc_rest_user_endpoint_handler($request = null)
{
    $response = array();
    $username = $request["username"];
    $email = $request["email"];
    $password = $request["password"];
    $type = $request["type"];
    $social_id = $request["social_id"];
    $pre_signup = $request['pre_signup'];
    $question_1 = '';
    $question_2 = '';
    $question_3 = '';
    foreach ($pre_signup as $key => $value) {
        if ($key == 'question_1') {
            $question_1 = $value;
        }
        if ($key == 'question_2') {
            $question_2 = $value;
        }
        if ($key == 'question_3') {
            $question_3 = $value;
        }
    }
    $error = new WP_Error();
    if (empty($username)) {
        $response['success'] = false;
        $response['message'] = __("The username field is empty.");
        return $response;
    }
    if (empty($email)) {
        $response['success'] = false;
        $response['message'] = __("The email field is empty.");
        return $response;
    }
    if (empty($type)) {
        $response['success'] = false;
        $response['message'] = __("The type field is empty.");
        return $response;
    }
    if ($type == 'email' && empty($password)) {
        $response['success'] = false;
        $response['message'] = __("The password field is empty.");
        return $response;
    } else {
        if ($type != 'email' && empty($social_id)) {
            $response['success'] = false;
            $response['message'] = __("The social id field is empty.");
            return $response;
        }
        if ($type != 'google' && $type != 'linkedin' && $type != 'facebook' && $type != 'email') {
            $response['success'] = false;
            $response['message'] = __("Type must be either email/google/linkedin/facebook.");
            return $response;
        }
    }

    $user_id = username_exists($username);
    if (!$user_id && email_exists($email) == false) {
        $user_id = wp_create_user($username, $password, $email);
        if (!is_wp_error($user_id)) {
            // Ger User Meta Data (Sensitive, Password included. DO NOT pass to front end.)
            $user = get_user_by('id', $user_id);
            // $user->set_role($role);
            $user->set_role('subscriber');
            // WooCommerce specific code
            if (class_exists('WooCommerce')) {
                $user->set_role('customer');
            }
            add_user_meta($user_id, 'question_1', $question_1);
            add_user_meta($user_id, 'question_2', $question_2);
            add_user_meta($user_id, 'question_3', $question_3);
            add_user_meta($user_id, 'type', $type);
            add_user_meta($user_id, 'social_id', $social_id);

            // Ger User Data (Non-Sensitive, Pass to front end.)
            $response['success'] = true;
            $response['message'] = __("User '" . $username . "' registration was successful.", "wp-rest-user");
        } else {
            return $user_id;
        }
    } else {
        $response['success'] = false;
        $response['message'] = __("Email already exists.");
        return $response;
    }
    return new WP_REST_Response($response, 123);
}

//login
add_action('rest_api_init', 'login_api_hooks');

function login_api_hooks()
{
    register_rest_route(
        'wp/v2',
        'user/login',
        array(
            'methods'  => 'POST',
            'callback' => 'login',
        )
    );
}
function login($request)
{
    $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;
    $expiry = defined('TOKEN_EXPIRATION_TIME') ? TOKEN_EXPIRATION_TIME : false;
    $username = $request["username"];
    $password =  $request["password"];
    $type =  $request["type"];
    $social_id =  $request["social_id"];
    $creds = array();
    $creds['user_login'] = $request["username"];
    $creds['user_password'] =  $request["password"];
    $creds['remember'] = true;
    $user_by_email = get_user_by('email', $username);
    $user_by_username = get_user_by('login', $username);
    if ($user_by_email) {
        $user_obj =  $user_by_email;
    } else {
        $user_obj =  $user_by_username;
    }
    $type_db = get_user_meta($user_obj->ID,  'type', true);
    $social_id_db = get_user_meta($user_obj->ID,  'social_id', true);
    if (!empty($type)) {
        if ($type != 'email') {
            if ($user_obj === false) {
                if (str_contains($username, '@')) {
                    $response['success'] = false;
                    $response['message'] = "Unknown email address. Check again or try your username.";
                    return $response;
                } else {
                    $response['success'] = false;
                    $response['message'] = "The username $username is not registered on this site. If you are unsure of your username, try your email address instead.";
                    return $response;
                }
            } else if (empty($social_id)) {
                $response['success'] = false;
                $response['message'] = "The social id field is empty.";
                return $response;
            } else if ($type != $type_db) {
                $response['success'] = false;
                $response['message'] = "Type not matched.";
                return $response;
            } else if ($social_id != $social_id_db) {
                $response['success'] = false;
                $response['message'] = "Social id not matched.";
                return $response;
            } else {
                $user = $user_obj;
                $data_ar = array();
                $combine_ar = array();
                foreach ($user as $key => $value) {
                    if ($key == 'data') {
                        foreach ($value as $subkey => $val) {
                            if ($subkey == 'user_pass') {
                                unset($data_ar[$subkey]);
                            } else {
                                $data_ar[$subkey] = $val;
                            }
                        }
                    }
                    $combine_ar['data'] = $data_ar;
                    unset($combine_ar['caps']);
                    unset($combine_ar['cap_key']);
                    unset($combine_ar['allcaps']);
                    $combine_ar[$key] = $value;
                }
                $remove_null_data = array_filter($combine_ar);

                // Get token - Start
                if (!$secret_key) {
                    return new WP_Error(
                        'jwt_auth_bad_config',
                        __('JWT is not configured properly, please contact the admin', 'wp-api-jwt-auth'),
                        array(
                            'status' => 403,
                        )
                    );
                }
                /** Try to authenticate the user with the passed credentials*/
                // $user_auth = wp_authenticate($username, $password);

                /** If the authentication fails return an error*/
                if (is_wp_error($user_obj)) {
                    $error_code = $user_obj->get_error_code();
                    return new WP_Error(
                        '[jwt_auth] ' . $error_code,
                        $user_obj->get_error_message($error_code),
                        array(
                            'status' => 403,
                        )
                    );
                }

                /** Valid credentials, the user exists create the according Token */
                $issuedAt = time();
                $notBefore = apply_filters('jwt_auth_not_before', $issuedAt, $issuedAt);
                $expire = apply_filters('jwt_auth_expire', $issuedAt + (1209600), $issuedAt);
                $token = array(
                    'iss' => get_bloginfo('url'),
                    'iat' => $issuedAt,
                    'nbf' => $notBefore,
                    'exp' => $expire,
                    'data' => array(
                        'user' => array(
                            'id' => $user_obj->data->ID,
                        ),
                    ),
                );

                /** Let the user modify the token data before the sign. */
                $token = JWT::encode(
                    apply_filters('jwt_auth_token_before_sign', $token, $user_obj),
                    $secret_key,
                    apply_filters('jwt_auth_algorithm', 'HS256')
                );
                $response['success'] = true;
                $response['message'] = "User details.";
                $response['token'] = $token;
                $response['user'] = $remove_null_data;
                return $response;
            }
        } else {
            $user = wp_signon($creds, false);
            if (is_wp_error($user)) {

                $error_message = strip_tags($user->get_error_message());
                $remove_error_text = str_replace('Error: ', '', $error_message);
                $response['success'] = false;
                $response['message'] = __($remove_error_text);
                return $response;
            } else {
                $data_ar = array();
                $combine_ar = array();
                foreach ($user as $key => $value) {
                    if ($key == 'data') {
                        foreach ($value as $subkey => $val) {
                            if ($subkey == 'user_pass') {
                                unset($data_ar[$subkey]);
                            } else {
                                $data_ar[$subkey] = $val;
                            }
                        }
                    }
                    $combine_ar['data'] = $data_ar;
                    unset($combine_ar['caps']);
                    unset($combine_ar['cap_key']);
                    unset($combine_ar['allcaps']);
                    $combine_ar[$key] = $value;
                }
                $remove_null_data = array_filter($combine_ar);

                // Get token - Start
                if (!$secret_key) {
                    return new WP_Error(
                        'jwt_auth_bad_config',
                        __('JWT is not configured properly, please contact the admin', 'wp-api-jwt-auth'),
                        array(
                            'status' => 403,
                        )
                    );
                }
                /** Try to authenticate the user with the passed credentials*/
                $user_auth = wp_authenticate($username, $password);

                /** If the authentication fails return an error*/
                if (is_wp_error($user_auth)) {
                    $error_code = $user_auth->get_error_code();
                    return new WP_Error(
                        '[jwt_auth] ' . $error_code,
                        $user_auth->get_error_message($error_code),
                        array(
                            'status' => 403,
                        )
                    );
                }

                /** Valid credentials, the user exists create the according Token */
                $issuedAt = time();
                $notBefore = apply_filters('jwt_auth_not_before', $issuedAt, $issuedAt);
                $expire = apply_filters('jwt_auth_expire', $issuedAt + 36000, $issuedAt);
                $token = array(
                    'iss' => get_bloginfo('url'),
                    'iat' => $issuedAt,
                    'nbf' => $notBefore,
                    'exp' => $expire,
                    'data' => array(
                        'user' => array(
                            'id' => $user_auth->data->ID,
                        ),
                    ),
                );
                /** Let the user modify the token data before the sign. */
                $token = JWT::encode(
                    apply_filters('jwt_auth_token_before_sign', $token, $user_auth),
                    $secret_key,
                    apply_filters('jwt_auth_algorithm', 'HS256')
                );
                $response['success'] = true;
                $response['message'] = "User details.";
                $response['token'] = $token;
                $response['user'] = $remove_null_data;
                return $response;
            }
        }
    } else {
        $response['success'] = false;
        $response['message'] = "The type field is empty.";
        return $response;
    }
}

//username status
add_action('rest_api_init', 'username_status_api_hooks');

function username_status_api_hooks()
{
    register_rest_route(
        'wp/v2',
        'user/username_status',
        array(
            'methods'  => 'POST',
            'callback' => 'username_status',
            'args' => prefix_get_endpoint_username_status_args(),
        )
    );
}
function prefix_get_endpoint_username_status_args()
{
    $args = array();

    // Here we add our PHP representation of JSON Schema.
    $args['username'] = array(
        'description'       => esc_html__('Enter username.', 'username-field'),
        'type'              => 'string',
        'required'          => true,
    );

    return $args;
}
function username_status($request)
{
    $pre_serve = apply_filters('cwp_user_exists_pre_check', null,  $request['username'], $request);
    if (is_wp_error($pre_serve)) {
        return rest_ensure_response($pre_serve);
    }
    //generate Auto suggestion - Start
    $user_suggest = array();
    do {
        $number =  random_int(100, 900);
        $username = $request['username'] . $number;
        if (!username_exists($username)) {
            $user_array[] = $username;
        }
        $user_suggest = array_unique($user_array);
    } while (count($user_suggest) < 3);
    $user_suggest_value = array();
    foreach ($user_suggest as $value) {
        $user_suggest_value[] = $value;
    }
    //generate Auto suggestion - End
    if (username_exists($request['username'])) {
        $response['success'] = true;
        $response['message'] = 'Username exists.';
        $response['data'] = $user_suggest_value;
        return $response;
    }

    /**
     * Fires when user exist check fails
     *
     * @param string$email Email address
     * @param WP_REST_Request $request  Current request
     */


    do_action('cwp_user_exits_failed', $request['username'], $request);
    $response['success'] = false;
    $response['message'] = "Username doesn’t exists.";
    return $response;
}
