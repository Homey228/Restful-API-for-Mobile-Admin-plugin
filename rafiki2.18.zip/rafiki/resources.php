<?php

//Get resources
add_action('rest_api_init', function ($rest) {
    register_rest_route('wp/v2', 'resources', [
        'methods'  => 'POST',
        'callback' => 'site_resources'
    ]);
});
function site_resources($request)
{

    $resources = '{
        "You Might Like": ["Resource Title", "Resource Title"],
        "HIV/AIDS": ["Resource Title", "Resource Title"],
        "Cancer": ["Resource Title", "Resource Title"]
    }';
    $resources_data = json_decode($resources, true);
    $response['success'] = true;
    $response['message'] = "Rresources list.";
    $response['data'] = $resources_data;
    return $response;
}

//Get resources search result
add_action('rest_api_init', 'rafiki_site_resources_search');

function rafiki_site_resources_search()
{
    register_rest_route(
        'wp/v2',
        'resources/search',
        array(
            'methods'  => 'POST',
            'callback' => 'site_resources_search',
        )
    );
}
function site_resources_search($request)
{
    $resources = '[{
                "title": "Resource Title",
                "type":"Article snippet",
                "category": "HIV/AIDS"
            },
            {
                "title": "Resource Title",
                "type":"Article snippet",
                "category": "COVID-19"
            },
            {
                "title": "Resource Title",
                "type":"Article snippet",
                "category": "Cancer"
            },
            {
                "title": "Resource Title",
                "type":"Article snippet",
                "category": "Diabetes"
            }
        ]
    ';

    $search = $request["search"];

    $resources_data = json_decode($resources, true);
    $result_search_data_title = array_filter($resources_data, function ($el) use ($search) {
        return (strpos($el['title'], $search) !== false);
    });
    $result_search_data_type = array_filter($resources_data, function ($el) use ($search) {
        return (strpos($el['type'], $search) !== false);
    });
    $result_search_data_cat = array_filter($resources_data, function ($el) use ($search) {
        return (strpos($el['category'], $search) !== false);
    });
    $result_search_data = array();
    if ($result_search_data_title) {
        $result_search_data = $result_search_data_title;
    } else if ($result_search_data_type) {
        $result_search_data = $result_search_data_type;
    } else if ($result_search_data_cat) {
        $result_search_data = $result_search_data_cat;
    }

    $formatted_search_result = array();
    foreach ($result_search_data as $key => $value) {
        $formatted_search_result[] = $value;
    }
    $result_data = array([
        'total_count' =>  count($result_search_data),
        'search_list' => $formatted_search_result
    ]);
    $total_search_list = array();
    foreach ($result_data as $key => $value) {
        $total_search_list = $value;
    }
    $data_list = array([
        "total_count" => count($resources_data),
        "search_list" => $resources_data,
    ]);
    $total_resources_list = array();
    foreach ($data_list as $key => $value) {
        $total_resources_list = $value;
    }
    $search_data = array();
    if ($result_search_data) {
        $search_data = $total_search_list;
    } else {
        $search_data =  $total_resources_list;
    }
    $response['success'] = true;
    $response['message'] = "Rresources search result.";
    $response['data'] = $search_data;
    return $response;
}
